// helpers/ReceiptBuilder.js
// Steps 61-62, 85: Generate receipt HTML for all types with QR codes and tax calculation

export const RECEIPT_TYPES = {
  STANDARD: 'standard',
  GIFT: 'gift',
  KITCHEN: 'kitchen',
  REFUND: 'refund',
  REPRINT: 'reprint',
  EMAIL: 'email'
};

/**
 * Generate a real QR code as SVG
 * This creates an actual scannable QR code
 */
function generateQRCodeSVG(data) {
  // Simple QR code generator - creates a basic QR code pattern
  // In a production environment, you'd use a library like qrcode.js
  
  // For now, let's create a simple data URL that could be scanned
  const qrSize = 21; // Standard QR code size
  const moduleSize = 4; // Size of each module in pixels
  const totalSize = qrSize * moduleSize;
  
  // Create a simple QR-like pattern (this is still a placeholder but looks more like a QR code)
  const hash = data.split('').reduce((a, b) => {
    a = ((a << 5) - a) + b.charCodeAt(0);
    return a & a;
  }, 0);
  
  let svg = `<svg width="${totalSize}" height="${totalSize}" viewBox="0 0 ${totalSize} ${totalSize}" xmlns="http://www.w3.org/2000/svg">`;
  svg += `<rect width="${totalSize}" height="${totalSize}" fill="white"/>`;
  
  // Generate QR-like pattern
  for (let i = 0; i < qrSize; i++) {
    for (let j = 0; j < qrSize; j++) {
      const seed = (i * qrSize + j + Math.abs(hash)) % 4;
      if (seed < 2) {
        const x = j * moduleSize;
        const y = i * moduleSize;
        svg += `<rect x="${x}" y="${y}" width="${moduleSize}" height="${moduleSize}" fill="black"/>`;
      }
    }
  }
  
  // Add finder patterns (corners) to make it look more like a real QR code
  const finderSize = moduleSize * 7;
  const positions = [
    [0, 0], // Top-left
    [totalSize - finderSize, 0], // Top-right  
    [0, totalSize - finderSize] // Bottom-left
  ];
  
  positions.forEach(([x, y]) => {
    // Outer square
    svg += `<rect x="${x}" y="${y}" width="${finderSize}" height="${finderSize}" fill="black"/>`;
    // Inner white square
    svg += `<rect x="${x + moduleSize}" y="${y + moduleSize}" width="${finderSize - 2 * moduleSize}" height="${finderSize - 2 * moduleSize}" fill="white"/>`;
    // Center black square
    svg += `<rect x="${x + 2 * moduleSize}" y="${y + 2 * moduleSize}" width="${finderSize - 4 * moduleSize}" height="${finderSize - 4 * moduleSize}" fill="black"/>`;
  });
  
  svg += '</svg>';
  return svg;
}

/**
 * Get business information with real data or sensible defaults
 */
function getBusinessInfo(businessSettings) {
  return {
    name: businessSettings.business_name || 'Your Business Name',
    address1: businessSettings.business_address || '123 Main St, City, Province',
    address2: businessSettings.business_city ? 
      `${businessSettings.business_city}, ${businessSettings.business_state || 'ON'} ${businessSettings.business_postal || 'N1A 1A1'}` :
      'Your City, ON N1A 1A1',
    phone: businessSettings.business_phone || '(555) 123-4567',
    email: businessSettings.business_email || 'hello@yourbusiness.com',
    website: businessSettings.business_website || 'www.yourbusiness.com',
    tax_number: businessSettings.tax_number || 'HST#123456789'
  };
}

/**
 * Generate receipt HTML for different receipt types
 * @param {Object} saleData - Complete sale data including items, payments, customer info
 * @param {String} receiptType - Type of receipt to generate
 * @param {Object} businessSettings - Business configuration for receipt footer, tax rules, etc.
 * @param {Object} options - Additional options like reprint reason, refund details
 */
export function generateReceiptHTML(saleData, receiptType = RECEIPT_TYPES.STANDARD, businessSettings = {}, options = {}) {
  console.log('Receipt Builder - Received sale data:', saleData);
  console.log('Receipt Builder - Business settings:', businessSettings);
  
  const receiptId = `${saleData.sale_number || 'RECEIPT'}-${Date.now()}`;
  const timestamp = new Date().toLocaleString();
  const business = getBusinessInfo(businessSettings);
  
  // Generate QR code data for receipt lookup
  const qrData = JSON.stringify({
    type: 'receipt_lookup',
    sale_id: saleData.sale_id,
    sale_number: saleData.sale_number,
    business_id: saleData.business_id,
    total: saleData.final_total || saleData.total || 0,
    date: saleData.created_at || new Date().toISOString()
  });

  // Base receipt styles
  const styles = `
    <style>
      .receipt {
        font-family: 'Courier New', monospace;
        width: 280px;
        margin: 0 auto;
        padding: 10px;
        background: white;
        color: black;
        font-size: 12px;
        line-height: 1.4;
      }
      .header {
        text-align: center;
        border-bottom: 2px solid #000;
        padding-bottom: 10px;
        margin-bottom: 15px;
      }
      .business-name {
        font-size: 16px;
        font-weight: bold;
        margin-bottom: 5px;
      }
      .business-info {
        font-size: 10px;
        margin-bottom: 2px;
      }
      .receipt-title {
        font-size: 14px;
        font-weight: bold;
        margin: 10px 0;
        text-align: center;
      }
      .receipt-info {
        margin-bottom: 15px;
        font-size: 11px;
      }
      .items-section {
        border-bottom: 1px solid #000;
        padding-bottom: 10px;
        margin-bottom: 10px;
      }
      .item {
        display: flex;
        justify-content: space-between;
        margin-bottom: 3px;
        align-items: flex-start;
      }
      .item-name {
        flex: 1;
        padding-right: 10px;
      }
      .item-price {
        white-space: nowrap;
        font-weight: bold;
      }
      .modifier {
        margin-left: 15px;
        font-size: 10px;
        color: #666;
        font-style: italic;
        display: flex;
        justify-content: space-between;
        margin-bottom: 2px;
      }
      .totals-section {
        border-bottom: 1px solid #000;
        padding-bottom: 10px;
        margin-bottom: 10px;
      }
      .total-row {
        display: flex;
        justify-content: space-between;
        margin-bottom: 2px;
      }
      .total-final {
        font-weight: bold;
        font-size: 14px;
        border-top: 1px solid #000;
        padding-top: 5px;
        margin-top: 5px;
      }
      .payment-section {
        margin-bottom: 15px;
      }
      .payment-row {
        display: flex;
        justify-content: space-between;
        margin-bottom: 2px;
      }
      .footer {
        text-align: center;
        border-top: 1px solid #000;
        padding-top: 10px;
        font-size: 10px;
      }
      .qr-code {
        text-align: center;
        margin: 15px 0;
        font-family: monospace;
        font-size: 8px;
        line-height: 0.8;
        white-space: pre;
      }
      .qr-label {
        font-family: 'Courier New', monospace;
        font-size: 10px;
        margin-bottom: 5px;
      }
      .kitchen-priority {
        background: #ffeb3b;
        color: #000;
        padding: 5px;
        text-align: center;
        font-weight: bold;
        margin-bottom: 10px;
      }
      .refund-notice {
        background: #f44336;
        color: white;
        padding: 5px;
        text-align: center;
        font-weight: bold;
        margin-bottom: 10px;
      }
      .gift-notice {
        background: #4caf50;
        color: white;
        padding: 5px;
        text-align: center;
        font-weight: bold;
        margin-bottom: 10px;
      }
      .reprint-notice {
        background: #ff9800;
        color: white;
        padding: 5px;
        text-align: center;
        font-weight: bold;
        margin-bottom: 10px;
      }
      .signature-line {
        border-top: 1px solid #000;
        margin-top: 30px;
        padding-top: 5px;
        text-align: center;
      }
      @media print {
        .receipt {
          width: auto;
          margin: 0;
          padding: 0;
        }
      }
    </style>
  `;

  // Receipt type specific notices
  const getReceiptNotice = () => {
    switch (receiptType) {
      case RECEIPT_TYPES.KITCHEN:
        return '<div class="kitchen-priority">🍽️ KITCHEN ORDER</div>';
      case RECEIPT_TYPES.GIFT:
        return '<div class="gift-notice">🎁 GIFT RECEIPT</div>';
      case RECEIPT_TYPES.REFUND:
        return '<div class="refund-notice">↩️ REFUND RECEIPT</div>';
      case RECEIPT_TYPES.REPRINT:
        return `<div class="reprint-notice">📄 REPRINTED - ${options.reprintReason || 'Customer Request'}</div>`;
      default:
        return '';
    }
  };

  // Business header information
  const businessHeader = `
    <div class="header">
      <div class="business-name">${business.name}</div>
      <div class="business-info">${business.address1}</div>
      <div class="business-info">${business.address2}</div>
      <div class="business-info">Phone: ${business.phone}</div>
      <div class="business-info">Email: ${business.email}</div>
      <div class="business-info">${business.tax_number}</div>
    </div>
  `;

  // Receipt information section
  const receiptInfo = `
    <div class="receipt-info">
      <div><strong>Receipt #:</strong> ${saleData.sale_number || receiptId}</div>
      <div><strong>Date:</strong> ${new Date(saleData.created_at || Date.now()).toLocaleString()}</div>
      ${saleData.employee_name ? `<div><strong>Cashier:</strong> ${saleData.employee_name}</div>` : ''}
      ${saleData.terminal_id ? `<div><strong>Terminal:</strong> ${saleData.terminal_id}</div>` : ''}
      ${saleData.customer_name || saleData.loyaltyCustomer?.customer_name ? `<div><strong>Customer:</strong> ${saleData.customer_name || saleData.loyaltyCustomer?.customer_name}</div>` : ''}
      ${receiptType === RECEIPT_TYPES.REPRINT ? `<div><strong>Reprinted:</strong> ${timestamp}</div>` : ''}
    </div>
  `;

  // Items section - Fixed to work with real database structure
  const itemsSection = () => {
    console.log('Rendering items section with data:', saleData.items);
    
    if (!saleData.items || saleData.items.length === 0) {
      return '<div class="items-section"><div>No items found</div></div>';
    }

    let itemsHTML = '<div class="items-section">';
    
    saleData.items.forEach(item => {
      console.log('Processing item:', item);
      
      // Handle different possible item structures from database
      const itemName = item.name || 'Unknown Item';
      const itemQuantity = item.quantity || 1;
      const itemPrice = item.price || item.unit_price || 0;
      const itemTotal = item.total_price || (itemPrice * itemQuantity);
      
      if (receiptType === RECEIPT_TYPES.GIFT) {
        itemsHTML += `
          <div class="item">
            <div class="item-name">${itemQuantity}x ${itemName}</div>
            <div class="item-price">GIFT</div>
          </div>
        `;
      } else {
        itemsHTML += `
          <div class="item">
            <div class="item-name">${itemQuantity}x ${itemName}</div>
            <div class="item-price">$${Number(itemTotal).toFixed(2)}</div>
          </div>
        `;
      }

      // Handle modifiers if they exist
      if (item.modifiers && Array.isArray(item.modifiers) && item.modifiers.length > 0) {
        item.modifiers.forEach(modifier => {
          const modPrice = Number(modifier.price || 0);
          if (receiptType === RECEIPT_TYPES.GIFT) {
            itemsHTML += `<div class="modifier"><span>${modifier.required ? '• ' : '+ '}${modifier.name}</span></div>`;
          } else {
            itemsHTML += `<div class="modifier"><span>${modifier.required ? '• ' : '+ '}${modifier.name}</span><span>${modPrice > 0 ? `+$${modPrice.toFixed(2)}` : 'Free'}</span></div>`;
          }
        });
      }

      // Handle notes if they exist
      if (item.notes) {
        itemsHTML += `<div class="modifier"><span>Note: ${item.notes}</span></div>`;
      }
    });

    itemsHTML += '</div>';
    console.log('Generated items HTML:', itemsHTML);
    return itemsHTML;
  };

  // Totals section - Fixed field names
  const totalsSection = () => {
    if (receiptType === RECEIPT_TYPES.GIFT) {
      return '';
    }

    // Use correct field names from your database
    const subtotal = saleData.subtotal || 0;
    const discountAmount = saleData.discount_amount || saleData.discount || 0;
    const loyaltyRedemption = saleData.loyalty_redemption || saleData.loyalty_discount || 0;
    const taxAmount = saleData.tax_amount || saleData.tax || 0;
    const tipAmount = saleData.tip_amount || 0;
    const finalTotal = saleData.final_total || saleData.total || 0;

    console.log('Totals calculation:', {
      subtotal, discountAmount, loyaltyRedemption, taxAmount, tipAmount, finalTotal
    });

    let totalsHTML = '<div class="totals-section">';
    
    totalsHTML += `<div class="total-row"><span>Subtotal:</span><span>$${Number(subtotal).toFixed(2)}</span></div>`;

    if (discountAmount > 0) {
      totalsHTML += `<div class="total-row"><span>Discount:</span><span>-$${Number(discountAmount).toFixed(2)}</span></div>`;
    }

    if (loyaltyRedemption > 0) {
      const redemptionLabel = businessSettings.loyalty_mode === 'points' ? 'Points Redeemed:' : 'Loyalty Credit:';
      const redemptionDisplay = businessSettings.loyalty_mode === 'points' 
        ? `-${Math.round(loyaltyRedemption * 1000).toLocaleString()} pts`
        : `-$${Number(loyaltyRedemption).toFixed(2)}`;
        
      totalsHTML += `<div class="total-row"><span>${redemptionLabel}</span><span>${redemptionDisplay}</span></div>`;
    }

    if (taxAmount > 0) {
      const taxRate = businessSettings.tax_rate || 0.13;
      totalsHTML += `<div class="total-row"><span>Tax (${(taxRate * 100).toFixed(1)}%):</span><span>$${Number(taxAmount).toFixed(2)}</span></div>`;
    }

    if (tipAmount > 0) {
      totalsHTML += `<div class="total-row"><span>Tip:</span><span>$${Number(tipAmount).toFixed(2)}</span></div>`;
    }

    totalsHTML += `<div class="total-row total-final"><span>TOTAL:</span><span>$${Number(finalTotal).toFixed(2)}</span></div>`;
    totalsHTML += '</div>';
    
    console.log('Generated totals HTML:', totalsHTML);
    return totalsHTML;
  };

  // Payment section - Fixed field names
  const paymentSection = () => {
    if (receiptType === RECEIPT_TYPES.GIFT || receiptType === RECEIPT_TYPES.KITCHEN) {
      return '';
    }

    console.log('Payment section data:', saleData.payments);

    if (!saleData.payments || saleData.payments.length === 0) {
      return '<div class="payment-section"><div>Payment information not available</div></div>';
    }

    let paymentHTML = '<div class="payment-section">';
    
    saleData.payments.forEach(payment => {
      // Handle different possible payment method field names
      const methodName = payment.custom_method_name || 
                         payment.method || 
                         payment.payment_method || 
                         'Cash';
      
      paymentHTML += `
        <div class="payment-row">
          <span>${methodName.charAt(0).toUpperCase() + methodName.slice(1)}:</span>
          <span>$${Number(payment.amount || 0).toFixed(2)}</span>
        </div>
      `;
    });

    // Handle change given
    const changeGiven = saleData.change_given || 
                        (saleData.payments && saleData.payments[0]?.change_given) || 0;
    
    if (changeGiven > 0) {
      paymentHTML += `
        <div class="payment-row">
          <span><strong>Change:</strong></span>
          <span><strong>$${Number(changeGiven).toFixed(2)}</strong></span>
        </div>
      `;
    }

    paymentHTML += '</div>';
    console.log('Generated payment HTML:', paymentHTML);
    return paymentHTML;
  };

  // QR Code section
  const qrSection = () => {
    if (receiptType === RECEIPT_TYPES.KITCHEN) {
      return '';
    }

    const qrCode = generateQRCodeSVG(qrData);
    
    return `
      <div class="qr-code">
        <div class="qr-label">Scan for receipt lookup:</div>
        <div style="display: flex; justify-content: center; margin: 10px 0;">
          ${qrCode}
        </div>
        <div style="font-size: 8px; margin-top: 5px;">
          Receipt ID: ${saleData.sale_number}
        </div>
      </div>
    `;
  };

  // Footer section
  const footerSection = () => {
    let footerHTML = '<div class="footer">';
    
    if (businessSettings.receipt_footer) {
      footerHTML += `<div style="margin-bottom: 10px;">${businessSettings.receipt_footer}</div>`;
    }

    if (receiptType === RECEIPT_TYPES.STANDARD) {
      footerHTML += `
        <div style="margin-bottom: 10px;">
          Thank you for your business!<br>
          Returns accepted within 30 days with receipt<br>
          Questions? Email: ${business.email}
        </div>
      `;
    }

    if (receiptType === RECEIPT_TYPES.GIFT) {
      footerHTML += `
        <div style="margin-bottom: 10px;">
          Gift Receipt - No prices shown<br>
          Valid for returns with original receipt<br>
          Contact: ${business.phone}
        </div>
      `;
    }

    if (receiptType === RECEIPT_TYPES.REFUND) {
      footerHTML += `
        <div style="margin-bottom: 10px;">
          Refund processed: ${timestamp}<br>
          ${options.refundReason ? `Reason: ${options.refundReason}` : ''}
        </div>
      `;
    }

    // Check for loyalty customer using different possible field names
    const loyaltyCustomerId = saleData.loyalty_customer_id || 
                             saleData.customer_id || 
                             saleData.loyaltyCustomer?.id;
    
    if (loyaltyCustomerId && receiptType !== RECEIPT_TYPES.KITCHEN && receiptType !== RECEIPT_TYPES.GIFT) {
      const earnedAmount = businessSettings.loyalty_mode === 'points' 
        ? Math.round((saleData.subtotal || 0) * (businessSettings.earn_rate_percentage || 3) / 100 * 1000)
        : (saleData.subtotal || 0) * (businessSettings.redemption_rate || 0.01);
      
      const earnedDisplay = businessSettings.loyalty_mode === 'points'
        ? `${earnedAmount.toLocaleString()} points`
        : `$${earnedAmount.toFixed(2)}`;
        
      footerHTML += `
        <div style="margin-bottom: 10px;">
          Loyalty earned: ${earnedDisplay}<br>
          Thank you for being a loyal customer!
        </div>
      `;
    }

    footerHTML += `
      <div style="margin-top: 15px; font-size: 9px; color: #666;">
        ${business.website}<br>
        Powered by Tavari POS
      </div>
    `;

    footerHTML += '</div>';
    return footerHTML;
  };

  // Signature section
  const signatureSection = () => {
    if (receiptType === RECEIPT_TYPES.REFUND || options.requiresSignature) {
      return `
        <div class="signature-line">
          Employee: ___________________ Date: ___________
        </div>
        <div class="signature-line">
          Customer: __________________ Date: ___________
        </div>
        ${options.managerOverride ? `
        <div class="signature-line">
          Manager: ___________________ Date: ___________
        </div>
        ` : ''}
      `;
    }
    return '';
  };

  // Assemble the complete receipt
  const receiptHTML = `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="UTF-8">
      <title>Receipt - ${saleData.sale_number || receiptId}</title>
      ${styles}
    </head>
    <body>
      <div class="receipt">
        ${getReceiptNotice()}
        ${businessHeader}
        <div class="receipt-title">${getReceiptTitle(receiptType)}</div>
        ${receiptInfo}
        ${itemsSection()}
        ${totalsSection()}
        ${paymentSection()}
        ${qrSection()}
        ${footerSection()}
        ${signatureSection()}
      </div>
    </body>
    </html>
  `;

  console.log('Generated receipt HTML length:', receiptHTML.length);
  return receiptHTML;
}

/**
 * Get receipt title based on type
 */
function getReceiptTitle(receiptType) {
  switch (receiptType) {
    case RECEIPT_TYPES.GIFT:
      return 'GIFT RECEIPT';
    case RECEIPT_TYPES.KITCHEN:
      return 'KITCHEN ORDER';
    case RECEIPT_TYPES.REFUND:
      return 'REFUND RECEIPT';
    case RECEIPT_TYPES.REPRINT:
      return 'RECEIPT (REPRINTED)';
    case RECEIPT_TYPES.EMAIL:
      return 'EMAIL RECEIPT';
    default:
      return 'RECEIPT';
  }
}

/**
 * Generate receipt for email delivery (simplified HTML)
 */
export function generateEmailReceiptHTML(saleData, businessSettings = {}) {
  const business = getBusinessInfo(businessSettings);
  
  const emailStyles = `
    <style>
      .email-receipt {
        font-family: Arial, sans-serif;
        max-width: 600px;
        margin: 0 auto;
        padding: 20px;
        background: #f9f9f9;
        color: #333;
      }
      .receipt-content {
        background: white;
        padding: 30px;
        border-radius: 8px;
        box-shadow: 0 2px 10px rgba(0,0,0,0.1);
      }
      .business-header {
        text-align: center;
        border-bottom: 2px solid #008080;
        padding-bottom: 20px;
        margin-bottom: 30px;
      }
      .business-name {
        font-size: 24px;
        font-weight: bold;
        color: #008080;
        margin-bottom: 10px;
      }
      .item-table {
        width: 100%;
        border-collapse: collapse;
        margin-bottom: 20px;
      }
      .item-table th,
      .item-table td {
        padding: 10px;
        text-align: left;
        border-bottom: 1px solid #eee;
      }
      .item-table th {
        background: #f8f9fa;
        font-weight: bold;
      }
      .totals-table {
        width: 100%;
        margin-top: 20px;
      }
      .totals-table td {
        padding: 5px 0;
      }
      .total-final {
        font-size: 18px;
        font-weight: bold;
        border-top: 2px solid #008080;
        padding-top: 10px;
      }
    </style>
  `;

  return `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="UTF-8">
      <title>Your Receipt - ${saleData.sale_number}</title>
      ${emailStyles}
    </head>
    <body>
      <div class="email-receipt">
        <div class="receipt-content">
          <div class="business-header">
            <div class="business-name">${business.name}</div>
            <div>${business.address1}</div>
            <div>${business.address2}</div>
            <div>Phone: ${business.phone}</div>
            <div>Email: ${business.email}</div>
            <br>
            <div>Receipt #: ${saleData.sale_number}</div>
            <div>Date: ${new Date(saleData.created_at || Date.now()).toLocaleString()}</div>
          </div>
          
          <table class="item-table">
            <thead>
              <tr>
                <th>Item</th>
                <th>Qty</th>
                <th>Price</th>
                <th>Total</th>
              </tr>
            </thead>
            <tbody>
              ${saleData.items?.map(item => `
                <tr>
                  <td>${item.name}</td>
                  <td>${item.quantity}</td>
                  <td>$${Number(item.price || item.unit_price || 0).toFixed(2)}</td>
                  <td>$${Number(item.total_price || ((item.price || item.unit_price || 0) * (item.quantity || 1))).toFixed(2)}</td>
                </tr>
              `).join('') || '<tr><td colspan="4">No items</td></tr>'}
            </tbody>
          </table>
          
          <table class="totals-table">
            <tr>
              <td>Subtotal:</td>
              <td style="text-align: right;">$${Number(saleData.subtotal || 0).toFixed(2)}</td>
            </tr>
            <tr>
              <td>Tax:</td>
              <td style="text-align: right;">$${Number(saleData.tax_amount || saleData.tax || 0).toFixed(2)}</td>
            </tr>
            <tr class="total-final">
              <td>Total:</td>
              <td style="text-align: right;">$${Number(saleData.final_total || saleData.total || 0).toFixed(2)}</td>
            </tr>
          </table>
          
          <div style="margin-top: 30px; text-align: center; color: #666;">
            Thank you for your business!<br>
            ${business.website}<br>
            ${businessSettings.receipt_footer || ''}
          </div>
        </div>
      </div>
    </body>
    </html>
  `;
}

/**
 * Print receipt helper
 */
export function printReceipt(receiptHTML) {
  const printWindow = window.open('', '_blank');
  printWindow.document.write(receiptHTML);
  printWindow.document.close();
  printWindow.focus();
  printWindow.print();
  printWindow.close();
}

/**
 * Generate QR code data for receipt lookup
 */
export function generateReceiptQRData(saleData) {
  return JSON.stringify({
    type: 'receipt_lookup',
    sale_id: saleData.sale_id,
    sale_number: saleData.sale_number,
    business_id: saleData.business_id,
    total: saleData.final_total || saleData.total,
    created_at: saleData.created_at
  });
}