// screens/POS/POSRegister.jsx
import React, { useEffect, useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import POSProductGrid from "../../components/POS/POSProductGrid";
import POSCartPanel from "../../components/POS/POSCartPanel";
import SessionLockModal from "../../components/POS/SessionLockModal";
import BarcodeScanHandler from "../../components/POS/BarcodeScanHandler";
import { useSessionLock } from "../../hooks/useSessionLock";
import { logAction } from "../../helpers/posAudit";
import dayjs from "dayjs";

// Import supabase client
import { supabase } from "../../supabaseClient";

const POSRegister = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const {
    isLocked,
    warningSeconds,
    pinAttempts,
    lockedUntil,
    unlockWithPin,
    managerOverride,
    isOverrideActive,
  } = useSessionLock();

  // Authentication state - STANDARDIZED to match TabScreen
  const [authUser, setAuthUser] = useState(null);
  const [selectedBusinessId, setSelectedBusinessId] = useState(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [authError, setAuthError] = useState(null);

  // App state
  const [businessName, setBusinessName] = useState("");
  const [employeeName, setEmployeeName] = useState("");
  const [categories, setCategories] = useState([]);
  const [products, setProducts] = useState([]);
  const [activeCategory, setActiveCategory] = useState(null);
  const [cartItems, setCartItems] = useState([]);
  const [discount, setDiscount] = useState(0);
  const [time, setTime] = useState(dayjs().format("hh:mm A"));
  const [currentCustomer, setCurrentCustomer] = useState(null);
  const [showCustomerScanner, setShowCustomerScanner] = useState(false);
  const [manualCustomerId, setManualCustomerId] = useState('');

  // Tab-specific state
  const [activeTab, setActiveTab] = useState(null);
  const [isTabMode, setIsTabMode] = useState(false);
  const [tabItems, setTabItems] = useState([]);

  // Authentication and business context setup - STANDARDIZED to match TabScreen
  useEffect(() => {
    const initializeAuth = async () => {
      try {
        console.log('POSRegister: Initializing authentication...');
        
        const { data: { session }, error } = await supabase.auth.getSession();
        console.log('POSRegister: Session check result:', { session: !!session, error });

        if (error || !session?.user) {
          console.error('POSRegister: No valid session, redirecting to login');
          navigate('/login');
          return;
        }

        setAuthUser(session.user);
        console.log('POSRegister: Authenticated as:', session.user.email);

        const currentBusinessId = localStorage.getItem('currentBusinessId');
        console.log('POSRegister: Business ID from localStorage:', currentBusinessId);

        if (!currentBusinessId) {
          setAuthError('No business selected');
          return;
        }

        setSelectedBusinessId(currentBusinessId);

        // Verify user has access to this business
        const { data: userRole, error: roleError } = await supabase
          .from('user_roles')
          .select('*')
          .eq('user_id', session.user.id)
          .eq('business_id', currentBusinessId)
          .eq('active', true)
          .single();

        if (roleError || !userRole) {
          console.error('POSRegister: User not authorized for this business:', roleError);
          setAuthError('Not authorized for this business');
          return;
        }

        console.log('POSRegister: User role verified:', userRole.role);
        setAuthLoading(false);

      } catch (err) {
        console.error('POSRegister: Authentication error:', err);
        setAuthError(err.message);
        setAuthLoading(false);
      }
    };

    initializeAuth();
  }, [navigate]);

  // Check for tab data from navigation
  useEffect(() => {
    if (location.state?.activeTab) {
      const tab = location.state.activeTab;
      console.log('Tab mode activated with tab:', tab);
      
      setActiveTab(tab);
      setIsTabMode(true);
      
      // Set customer if tab has loyalty customer
      if (tab.loyalty_customer_id) {
        loadTabCustomer(tab.loyalty_customer_id);
      } else if (tab.customer_name) {
        setCurrentCustomer({
          customer_name: tab.customer_name,
          customer_phone: tab.customer_phone,
          customer_email: tab.customer_email,
          id: null
        });
      }

      // Load existing tab items if any
      loadTabItems(tab.id);
    }
  }, [location.state]);

  const loadTabCustomer = async (loyaltyCustomerId) => {
    if (!selectedBusinessId) return;
    
    try {
      const { data, error } = await supabase
        .from('pos_loyalty_accounts')
        .select('*')
        .eq('id', loyaltyCustomerId)
        .eq('business_id', selectedBusinessId)
        .single();

      if (data && !error) {
        setCurrentCustomer(data);
        console.log('Loaded tab customer:', data);
      }
    } catch (err) {
      console.error('Error loading tab customer:', err);
    }
  };

  const loadTabItems = async (tabId) => {
    try {
      const { data, error } = await supabase
        .from('pos_tab_items')
        .select('*')
        .eq('tab_id', tabId)
        .order('created_at', { ascending: true });

      if (data && !error) {
        const convertedItems = data.map(item => ({
          id: item.product_id || item.id,
          name: item.name,
          price: item.unit_price,
          quantity: item.quantity,
          modifiers: item.modifiers || [],
          notes: item.notes,
          tab_item_id: item.id
        }));
        
        setTabItems(convertedItems);
        setCartItems(convertedItems);
        console.log('Loaded tab items:', convertedItems);
      }
    } catch (err) {
      console.error('Error loading tab items:', err);
    }
  };

  // Clock updater
  useEffect(() => {
    const interval = setInterval(() => {
      setTime(dayjs().format("hh:mm A"));
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  // Fetch user and business info - only runs after auth is complete
  useEffect(() => {
    const fetchUserInfo = async () => {
      if (!authUser || !selectedBusinessId) return;

      try {
        // Get user profile
        const { data: userProfile } = await supabase
          .from("users")
          .select("full_name, email")
          .eq("id", authUser.id)
          .single();

        if (userProfile) {
          setEmployeeName(userProfile.full_name || userProfile.email || "Unknown User");
        } else {
          setEmployeeName(authUser.email || "Unknown User");
        }

        // Get business name
        const { data: businessData } = await supabase
          .from("businesses")
          .select("name")
          .eq("id", selectedBusinessId)
          .single();

        if (businessData) {
          setBusinessName(businessData.name);
        } else {
          setBusinessName("Test Business");
        }
      } catch (err) {
        console.error('Error fetching user info:', err);
      }
    };
    
    fetchUserInfo();
  }, [authUser, selectedBusinessId]);

  // Fetch categories - only runs after auth is complete
  useEffect(() => {
    if (!selectedBusinessId) return;

    const fetchCategories = async () => {
      try {
        const { data, error } = await supabase
          .from("pos_categories")
          .select("id, name, color, emoji, sort_order")
          .eq("business_id", selectedBusinessId)
          .order("sort_order", { ascending: true });

        if (error) {
          console.error("Error fetching categories:", error);
        } else {
          setCategories(data || []);
        }
      } catch (err) {
        console.error("Categories fetch error:", err);
      }
    };

    fetchCategories();

    const catSubscription = supabase
      .channel(`pos_categories_${selectedBusinessId}`)
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "pos_categories", filter: `business_id=eq.${selectedBusinessId}` },
        fetchCategories
      )
      .subscribe();

    return () => {
      supabase.removeChannel(catSubscription);
    };
  }, [selectedBusinessId]);

  // Fetch products - only runs after auth is complete
  useEffect(() => {
    if (!selectedBusinessId) return;

    const fetchProducts = async () => {
      try {
        const { data, error } = await supabase
          .from("pos_inventory")
          .select("id, name, price, cost, sku, barcode, category_id, track_stock, stock_quantity, low_stock_threshold, station_ids, image_url")
          .eq("business_id", selectedBusinessId)
          .order("name", { ascending: true });

        if (error) {
          console.error("Error fetching products:", error);
        } else {
          setProducts(data || []);
        }
      } catch (err) {
        console.error("Products fetch error:", err);
      }
    };

    fetchProducts();

    const prodSubscription = supabase
      .channel(`pos_inventory_${selectedBusinessId}`)
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "pos_inventory", filter: `business_id=eq.${selectedBusinessId}` },
        fetchProducts
      )
      .subscribe();

    return () => {
      supabase.removeChannel(prodSubscription);
    };
  }, [selectedBusinessId]);

  // Filter products by active category
  const filteredProducts = activeCategory
    ? products.filter((p) => p.category_id === activeCategory)
    : products;

  const handleAddToCart = async (product) => {
    if (isLocked) return;
    
    if (isTabMode && activeTab) {
      await addItemToTab(product);
    } else {
      setCartItems((prev) => {
        const existing = prev.find((item) => item.id === product.id);
        if (existing) {
          return prev.map((item) =>
            item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item
          );
        }
        return [...prev, { ...product, quantity: 1 }];
      });
    }
  };

  const addItemToTab = async (product) => {
    if (!authUser || !activeTab) {
      showToast('System error: cannot add items to tab', 'error');
      return;
    }

    try {
      // Check if item already exists in tab
      const existingTabItem = tabItems.find(item => item.id === product.id);
      
      if (existingTabItem) {
        // Update quantity in database
        const newQuantity = existingTabItem.quantity + 1;
        const newTotalPrice = newQuantity * product.price;
        
        const { error } = await supabase
          .from('pos_tab_items')
          .update({ 
            quantity: newQuantity,
            total_price: newTotalPrice
          })
          .eq('id', existingTabItem.tab_item_id);

        if (error) throw error;

        // Update local state
        setCartItems(prev => 
          prev.map(item => 
            item.id === product.id 
              ? { ...item, quantity: newQuantity }
              : item
          )
        );
        setTabItems(prev => 
          prev.map(item => 
            item.id === product.id 
              ? { ...item, quantity: newQuantity }
              : item
          )
        );
      } else {
        // Add new item to tab
        const tabItemData = {
          business_id: selectedBusinessId,
          tab_id: activeTab.id,
          inventory_id: product.id,
          product_id: product.id,
          name: product.name,
          quantity: 1,
          unit_price: product.price,
          total_price: product.price,
          modifiers: [],
          notes: null,
          added_by: authUser.id
        };

        const { data: newTabItem, error } = await supabase
          .from('pos_tab_items')
          .insert(tabItemData)
          .select()
          .single();

        if (error) throw error;

        // Add to local state
        const cartItem = {
          ...product,
          quantity: 1,
          tab_item_id: newTabItem.id
        };

        setCartItems(prev => [...prev, cartItem]);
        setTabItems(prev => [...prev, cartItem]);
      }

      // Update tab totals
      await updateTabTotals();

      showToast(`Added ${product.name} to tab`, 'success');
    } catch (err) {
      console.error('Error adding item to tab:', err);
      showToast('Error adding item to tab: ' + err.message, 'error');
    }
  };

  const updateTabTotals = async () => {
    if (!activeTab) return;

    try {
      const subtotal = cartItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);
      const taxRate = 0.13;
      const taxAmount = subtotal * taxRate;
      const total = subtotal + taxAmount;

      const { error } = await supabase
        .from('pos_tabs')
        .update({
          subtotal: subtotal.toFixed(2),
          tax_amount: taxAmount.toFixed(2),
          total_amount: total.toFixed(2),
          balance_remaining: (total - (activeTab.amount_paid || 0)).toFixed(2),
          updated_at: new Date().toISOString()
        })
        .eq('id', activeTab.id);

      if (error) throw error;

      setActiveTab(prev => ({
        ...prev,
        subtotal,
        tax_amount: taxAmount,
        total_amount: total,
        balance_remaining: total - (prev.amount_paid || 0)
      }));

    } catch (err) {
      console.error('Error updating tab totals:', err);
    }
  };

  const handleRemoveFromCart = async (productId) => {
    if (isLocked) return;
    
    if (isTabMode && activeTab) {
      await removeItemFromTab(productId);
    } else {
      setCartItems((prev) => prev.filter((item) => item.id !== productId));
    }
  };

  const removeItemFromTab = async (productId) => {
    try {
      const tabItem = tabItems.find(item => item.id === productId);
      if (tabItem && tabItem.tab_item_id) {
        const { error } = await supabase
          .from('pos_tab_items')
          .delete()
          .eq('id', tabItem.tab_item_id);

        if (error) throw error;

        setCartItems(prev => prev.filter(item => item.id !== productId));
        setTabItems(prev => prev.filter(item => item.id !== productId));
        
        await updateTabTotals();
        showToast('Item removed from tab', 'info');
      }
    } catch (err) {
      console.error('Error removing item from tab:', err);
      showToast('Error removing item from tab', 'error');
    }
  };

  const handleUpdateQty = async (productId, qty) => {
    if (isLocked) return;
    if (qty <= 0) return handleRemoveFromCart(productId);
    
    if (isTabMode && activeTab) {
      await updateTabItemQty(productId, qty);
    } else {
      setCartItems((prev) =>
        prev.map((item) => (item.id === productId ? { ...item, quantity: qty } : item))
      );
    }
  };

  const updateTabItemQty = async (productId, qty) => {
    try {
      const tabItem = tabItems.find(item => item.id === productId);
      if (tabItem && tabItem.tab_item_id) {
        const newTotalPrice = qty * tabItem.price;

        const { error } = await supabase
          .from('pos_tab_items')
          .update({
            quantity: qty,
            total_price: newTotalPrice
          })
          .eq('id', tabItem.tab_item_id);

        if (error) throw error;

        setCartItems(prev =>
          prev.map(item =>
            item.id === productId ? { ...item, quantity: qty } : item
          )
        );
        setTabItems(prev =>
          prev.map(item =>
            item.id === productId ? { ...item, quantity: qty } : item
          )
        );

        await updateTabTotals();
      }
    } catch (err) {
      console.error('Error updating tab item quantity:', err);
      showToast('Error updating quantity', 'error');
    }
  };

  const handleBarcodeScan = (code) => {
    if (isLocked) return;
    
    const foundProduct = products.find(
      (p) => 
        (p.sku && p.sku.trim() === code.trim()) ||
        (p.barcode && p.barcode.trim() === code.trim())
    );
    
    if (foundProduct) {
      handleAddToCart(foundProduct);
      return;
    }

    handleCustomerScan(code);
  };

  const handleCustomerScan = async (customerId) => {
    if (isLocked || !selectedBusinessId) return;
    
    try {
      const { data, error } = await supabase
        .from('pos_loyalty_accounts')
        .select('*')
        .eq('id', customerId)
        .eq('business_id', selectedBusinessId)
        .eq('is_active', true)
        .single();

      if (error || !data) {
        showToast('Customer not found or inactive', 'error');
        return;
      }

      setCurrentCustomer(data);
      showToast(`Customer: ${data.customer_name} (${data.points || 0} pts, $${(data.balance || 0).toFixed(2)})`, 'success');

    } catch (err) {
      console.error('Customer scan error:', err);
      showToast('Error scanning customer QR code', 'error');
    }
  };

  const showToast = (message, type = 'info') => {
    const toast = document.createElement('div');
    toast.style.cssText = `
      position: fixed;
      top: 120px;
      right: 20px;
      padding: 12px 20px;
      border-radius: 6px;
      color: white;
      font-weight: bold;
      z-index: 1000;
      background-color: ${type === 'error' ? '#dc2626' : type === 'success' ? '#059669' : '#008080'};
    `;
    toast.textContent = message;
    document.body.appendChild(toast);
    
    setTimeout(() => {
      if (document.body.contains(toast)) {
        document.body.removeChild(toast);
      }
    }, 3000);
  };

  const handleDetachCustomer = () => {
    if (isLocked) return;
    
    const customerName = currentCustomer?.customer_name;
    setCurrentCustomer(null);
    showToast(`Detached customer: ${customerName}`, 'info');
  };

  const handleManualCustomerEntry = async () => {
    if (!manualCustomerId.trim()) {
      showToast('Please enter a customer ID', 'error');
      return;
    }
    
    await handleCustomerScan(manualCustomerId.trim());
    setManualCustomerId('');
    setShowCustomerScanner(false);
  };

  const handleCheckout = (checkoutData) => {
    if (isLocked) return;
    
    if (isTabMode && activeTab) {
      navigate('/dashboard/pos/payment', {
        state: {
          saleData: {
            ...checkoutData,
            items: cartItems,
            business_id: selectedBusinessId,
            loyalty_customer_id: currentCustomer?.id || null,
            loyaltyCustomer: currentCustomer,
            activeTab: activeTab,
            tab_mode: true
          }
        }
      });
    } else {
      navigate('/dashboard/pos/sale-review', {
        state: { 
          checkoutData: {
            ...checkoutData,
            items: cartItems,
            business_id: selectedBusinessId,
            loyalty_customer_id: currentCustomer?.id || null,
            loyaltyCustomer: currentCustomer
          }
        }
      });
    }
  };

  const handleStartTab = () => {
    if (isLocked) return;
    navigate('/dashboard/pos/tabs', { state: { action: 'create' } });
  };

  const handleViewTabs = () => {
    if (isLocked) return;
    navigate('/dashboard/pos/tabs');
  };

  const handleExitTabMode = () => {
    setIsTabMode(false);
    setActiveTab(null);
    setCartItems([]);
    setTabItems([]);
    setCurrentCustomer(null);
    navigate('/dashboard/pos/register', { replace: true });
    showToast('Exited tab mode', 'info');
  };

  // Loading and error states - STANDARDIZED to match TabScreen
  if (authLoading) {
    return (
      <div style={{...styles.container, justifyContent: 'center', alignItems: 'center'}}>
        <h3>Loading POS Register...</h3>
        <p>Authenticating user and loading business data...</p>
      </div>
    );
  }

  if (authError) {
    return (
      <div style={{...styles.container, justifyContent: 'center', alignItems: 'center'}}>
        <h3>Authentication Error</h3>
        <p>{authError}</p>
        <button 
          style={styles.button}
          onClick={() => navigate('/login')}
        >
          Return to Login
        </button>
      </div>
    );
  }

  return (
    <div style={styles.container}>
      {!!warningSeconds && !isLocked && (
        <div style={styles.warning}>
          Auto-lock in <b>{warningSeconds}s</b>
        </div>
      )}

      <div style={styles.header}>
        <div>
          <h2 style={{ margin: 0 }}>{businessName}</h2>
          <p style={{ margin: 0 }}>Logged in as: {employeeName}</p>
        </div>
        <div style={styles.headerActions}>
          {isTabMode && activeTab ? (
            <>
              <div style={styles.tabInfo}>
                <div style={styles.tabNumber}>Tab: {activeTab.tab_number}</div>
                <div style={styles.tabCustomer}>
                  Customer: {activeTab.customer_name}
                </div>
                <div style={styles.tabTotal}>
                  Total: ${(activeTab.total_amount || 0).toFixed(2)}
                </div>
              </div>
              <button
                style={styles.exitTabButton}
                onClick={handleExitTabMode}
                disabled={isLocked}
                title="Exit tab mode"
              >
                Exit Tab
              </button>
            </>
          ) : (
            <>
              <button
                style={styles.tabButton}
                onClick={handleStartTab}
                disabled={isLocked}
                title="Start a new customer tab"
              >
                📋 Start Tab
              </button>
              <button
                style={styles.viewTabsButton}
                onClick={handleViewTabs}
                disabled={isLocked}
                title="View all active tabs"
              >
                📋 View Tabs
              </button>
            </>
          )}
          <div style={styles.clock}>{time}</div>
        </div>
      </div>

      <div style={styles.mainContent}>
        <div style={styles.productsSection}>
          <div style={styles.categories}>
            <button
              style={{
                ...styles.categoryButton,
                backgroundColor: activeCategory === null ? "#008080" : "#fff",
                color: activeCategory === null ? "#fff" : "#333",
              }}
              onClick={() => setActiveCategory(null)}
            >
              All
            </button>
            {categories.map((cat) => {
              const isActive = activeCategory === cat.id;
              return (
                <button
                  key={cat.id}
                  style={{
                    ...styles.categoryButton,
                    backgroundColor: isActive ? (cat.color || "#008080") : "#fff",
                    color: isActive ? "#fff" : "#333",
                    borderColor: cat.color || "#008080",
                  }}
                  onClick={() => setActiveCategory(cat.id)}
                >
                  {cat.emoji && <span style={{ marginRight: "6px" }}>{cat.emoji}</span>}
                  {cat.name}
                </button>
              );
            })}
          </div>

          <POSProductGrid products={filteredProducts} onAddToCart={handleAddToCart} />
        </div>

        <div style={styles.cartSection}>
          {!isTabMode && (
            <div style={styles.customerSection}>
              {currentCustomer ? (
                <div style={styles.customerAttached}>
                  <div style={styles.customerInfo}>
                    <div style={styles.customerName}>
                      👤 {currentCustomer.customer_name}
                    </div>
                    <div style={styles.customerDetails}>
                      {currentCustomer.points > 0 && (
                        <span style={styles.customerPoints}>
                          ⭐ {currentCustomer.points} pts
                        </span>
                      )}
                      {currentCustomer.balance > 0 && (
                        <span style={styles.customerBalance}>
                          💰 ${(currentCustomer.balance).toFixed(2)}
                        </span>
                      )}
                    </div>
                  </div>
                  <button
                    style={styles.detachButton}
                    onClick={handleDetachCustomer}
                    disabled={isLocked}
                    title="Detach customer from this sale"
                  >
                    ✕
                  </button>
                </div>
              ) : (
                <div style={styles.noCustomer}>
                  {!showCustomerScanner ? (
                    <>
                      <div style={styles.scanCustomerText}>
                        📱 Scan customer QR to attach
                      </div>
                      <div style={styles.scanSubtext}>
                        Use barcode scanner or manual entry
                      </div>
                      <button
                        style={styles.manualEntryButton}
                        onClick={() => setShowCustomerScanner(true)}
                        disabled={isLocked}
                      >
                        Manual Entry
                      </button>
                    </>
                  ) : (
                    <div style={styles.manualEntryForm}>
                      <div style={styles.manualEntryTitle}>Enter Customer ID:</div>
                      <input
                        type="text"
                        value={manualCustomerId}
                        onChange={(e) => setManualCustomerId(e.target.value)}
                        placeholder="550e8400-e29b-41d4-a716-446655440001"
                        style={styles.customerInputInline}
                        autoFocus
                        onKeyPress={(e) => {
                          if (e.key === 'Enter') {
                            handleManualCustomerEntry();
                          }
                        }}
                      />
                      <div style={styles.inlineActions}>
                        <button
                          style={styles.inlineCancelButton}
                          onClick={() => {
                            setShowCustomerScanner(false);
                            setManualCustomerId('');
                          }}
                        >
                          Cancel
                        </button>
                        <button
                          style={styles.inlineConfirmButton}
                          onClick={handleManualCustomerEntry}
                          disabled={!manualCustomerId.trim()}
                        >
                          Attach
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          )}

          <POSCartPanel
            cartItems={cartItems}
            onRemoveItem={handleRemoveFromCart}
            onUpdateQty={handleUpdateQty}
            onCheckout={handleCheckout}
            sessionLocked={isLocked}
            attachedCustomer={currentCustomer}
            tabMode={isTabMode}
            activeTab={activeTab}
          />
        </div>
      </div>

      <BarcodeScanHandler onScan={handleBarcodeScan} />
      {isLocked && (
        <SessionLockModal
          visible={isLocked}
          onSubmitPin={unlockWithPin}
          onManagerOverride={managerOverride}
          pinAttempts={pinAttempts}
          lockedUntil={lockedUntil}
          warningSeconds={warningSeconds}
          overrideActive={isOverrideActive()}
        />
      )}
    </div>
  );
};

const styles = {
  container: { 
    display: "flex", 
    flexDirection: "column", 
    height: "100vh",
    paddingTop: "80px",
    paddingLeft: "20px",
    paddingRight: "20px", 
    paddingBottom: "20px",
    boxSizing: "border-box"
  },
  button: {
    padding: "12px 24px",
    backgroundColor: "#008080",
    color: "white",
    border: "none",
    borderRadius: "6px",
    cursor: "pointer",
    fontSize: "16px",
    fontWeight: "bold"
  },
  warning: { 
    background: "#fff8e1", 
    padding: "8px", 
    borderRadius: 8, 
    marginBottom: "10px" 
  },
  header: { 
    display: "flex", 
    justifyContent: "space-between", 
    alignItems: "center", 
    marginBottom: "20px",
    backgroundColor: "white",
    padding: "12px 0",
    borderBottom: "1px solid #e5e7eb",
    position: "relative",
    zIndex: 10
  },
  headerActions: {
    display: "flex",
    alignItems: "center",
    gap: "15px"
  },
  tabInfo: {
    display: "flex",
    flexDirection: "column",
    alignItems: "flex-end",
    fontSize: "12px",
    backgroundColor: "#f0fdfa",
    padding: "8px 12px",
    borderRadius: "6px",
    border: "2px solid #008080"
  },
  tabNumber: {
    fontWeight: "bold",
    color: "#008080"
  },
  tabCustomer: {
    color: "#374151"
  },
  tabTotal: {
    fontWeight: "bold",
    color: "#059669"
  },
  tabButton: {
    padding: "10px 16px",
    backgroundColor: "white",
    color: "#008080",
    border: "2px solid #008080",
    borderRadius: "6px",
    cursor: "pointer",
    fontSize: "14px",
    fontWeight: "bold",
    transition: "all 0.2s ease",
    whiteSpace: "nowrap"
  },
  viewTabsButton: {
    padding: "10px 16px",
    backgroundColor: "#008080",
    color: "white",
    border: "2px solid #008080",
    borderRadius: "6px",
    cursor: "pointer",
    fontSize: "14px",
    fontWeight: "bold",
    transition: "all 0.2s ease",
    whiteSpace: "nowrap"
  },
  exitTabButton: {
    padding: "10px 16px",
    backgroundColor: "#ef4444",
    color: "white",
    border: "2px solid #ef4444",
    borderRadius: "6px",
    cursor: "pointer",
    fontSize: "14px",
    fontWeight: "bold",
    transition: "all 0.2s ease",
    whiteSpace: "nowrap"
  },
  clock: { 
    fontSize: "18px", 
    fontWeight: "bold" 
  },
  mainContent: { 
    display: "flex", 
    flex: 1, 
    gap: "20px",
    minHeight: 0 
  },
  productsSection: { 
    flex: 3, 
    display: "flex", 
    flexDirection: "column",
    minHeight: 0
  },
  cartSection: {
    flex: 1,
    display: "flex",
    flexDirection: "column",
    minHeight: 0
  },
  categories: { 
    display: "grid", 
    gridTemplateColumns: "repeat(auto-fit, minmax(120px, 1fr))", 
    gap: "12px", 
    marginBottom: "20px",
    maxHeight: "120px",
    overflowY: "auto"
  },
  categoryButton: { 
    padding: "12px 16px", 
    border: "2px solid #008080", 
    borderRadius: "6px", 
    cursor: "pointer",
    fontWeight: "bold",
    fontSize: "14px",
    minHeight: "48px",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    textAlign: "center",
    transition: "all 0.2s ease",
    backgroundColor: "#fff"
  },
  customerSection: {
    backgroundColor: "white",
    border: "2px solid #008080",
    borderRadius: "8px",
    marginBottom: "15px",
    minHeight: "80px",
    display: "flex",
    alignItems: "center"
  },
  customerAttached: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    width: "100%",
    padding: "12px 15px"
  },
  customerInfo: {
    flex: 1
  },
  customerName: {
    fontSize: "16px",
    fontWeight: "bold",
    color: "#1f2937",
    marginBottom: "4px"
  },
  customerDetails: {
    display: "flex",
    gap: "10px",
    fontSize: "12px"
  },
  customerPoints: {
    color: "#f59e0b",
    fontWeight: "bold"
  },
  customerBalance: {
    color: "#059669",
    fontWeight: "bold"
  },
  detachButton: {
    backgroundColor: "#ef4444",
    color: "white",
    border: "none",
    borderRadius: "4px",
    width: "28px",
    height: "28px",
    cursor: "pointer",
    fontSize: "14px",
    fontWeight: "bold",
    display: "flex",
    alignItems: "center",
    justifyContent: "center"
  },
  noCustomer: {
    width: "100%",
    padding: "15px",
    textAlign: "center",
    color: "#6b7280"
  },
  scanCustomerText: {
    fontSize: "14px",
    fontWeight: "bold",
    marginBottom: "4px"
  },
  scanSubtext: {
    fontSize: "12px",
    fontStyle: "italic"
  },
  manualEntryButton: {
    marginTop: "8px",
    padding: "6px 12px",
    backgroundColor: "#008080",
    color: "white",
    border: "none",
    borderRadius: "4px",
    cursor: "pointer",
    fontSize: "12px",
    fontWeight: "bold"
  },
  manualEntryForm: {
    width: "100%",
    display: "flex",
    flexDirection: "column",
    gap: "8px"
  },
  manualEntryTitle: {
    fontSize: "12px",
    fontWeight: "bold",
    marginBottom: "4px"
  },
  customerInputInline: {
    padding: "6px 8px",
    border: "1px solid #d1d5db",
    borderRadius: "4px",
    fontSize: "12px"
  },
  inlineActions: {
    display: "flex",
    gap: "6px",
    justifyContent: "center"
  },
  inlineCancelButton: {
    padding: "4px 8px",
    backgroundColor: "#6b7280",
    color: "white",
    border: "none",
    borderRadius: "4px",
    cursor: "pointer",
    fontSize: "11px"
  },
  inlineConfirmButton: {
    padding: "4px 8px",
    backgroundColor: "#008080",
    color: "white",
    border: "none",
    borderRadius: "4px",
    cursor: "pointer",
    fontSize: "11px"
  }
};

export default POSRegister;