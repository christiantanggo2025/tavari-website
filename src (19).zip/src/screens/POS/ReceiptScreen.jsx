// screens/POS/ReceiptScreen.jsx
import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { supabase } from '../../supabaseClient';
import { 
  generateReceiptHTML, 
  generateEmailReceiptHTML, 
  printReceipt, 
  RECEIPT_TYPES 
} from '../../helpers/ReceiptBuilder';
import { logAction } from '../../helpers/posAudit';

const ReceiptScreen = () => {
  const navigate = useNavigate();
  const location = useLocation();
  
  // Authentication state
  const [authUser, setAuthUser] = useState(null);
  const [selectedBusinessId, setSelectedBusinessId] = useState(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [authError, setAuthError] = useState(null);
  
  const [saleData, setSaleData] = useState(null);
  const [businessSettings, setBusinessSettings] = useState({});
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [emailAddress, setEmailAddress] = useState('');
  const [showEmailModal, setShowEmailModal] = useState(false);
  const [emailSending, setEmailSending] = useState(false);
  const [receiptGenerated, setReceiptGenerated] = useState(false);
  const [saveInProgress, setSaveInProgress] = useState(false);

  // Get sale data from navigation state
  const receivedSaleData = location.state?.saleData;

  // Authentication and business context setup
  useEffect(() => {
    const initializeAuth = async () => {
      try {
        console.log('ReceiptScreen: Initializing authentication...');
        
        const { data: { session }, error } = await supabase.auth.getSession();
        console.log('ReceiptScreen: Session check result:', { session: !!session, error });

        if (error || !session?.user) {
          console.error('ReceiptScreen: No valid session, redirecting to login');
          navigate('/login');
          return;
        }

        setAuthUser(session.user);
        console.log('ReceiptScreen: Authenticated as:', session.user.email);

        const currentBusinessId = localStorage.getItem('currentBusinessId');
        console.log('ReceiptScreen: Business ID from localStorage:', currentBusinessId);

        if (!currentBusinessId) {
          setAuthError('No business selected');
          return;
        }

        setSelectedBusinessId(currentBusinessId);

        // Verify user has access to this business
        const { data: userRole, error: roleError } = await supabase
          .from('user_roles')
          .select('*')
          .eq('user_id', session.user.id)
          .eq('business_id', currentBusinessId)
          .eq('active', true)
          .single();

        if (roleError || !userRole) {
          console.error('ReceiptScreen: User not authorized for this business:', roleError);
          setAuthError('Not authorized for this business');
          return;
        }

        console.log('ReceiptScreen: User role verified:', userRole.role);
        setAuthLoading(false);

      } catch (err) {
        console.error('ReceiptScreen: Authentication error:', err);
        setAuthError(err.message);
        setAuthLoading(false);
      }
    };

    initializeAuth();
  }, [navigate]);

  useEffect(() => {
    if (!selectedBusinessId) {
      setError('No business selected');
      return;
    }

    if (!receivedSaleData) {
      setError('No sale data provided');
      return;
    }

    // Prevent duplicate loads during React StrictMode development
    const loadKey = `receipt_loaded_${receivedSaleData.sale_number || Date.now()}`;
    if (sessionStorage.getItem(loadKey)) {
      console.log('Receipt already loaded for this sale, skipping...');
      return;
    }
    sessionStorage.setItem(loadKey, 'true');

    loadReceiptData();
  }, [selectedBusinessId, receivedSaleData]);

  const generateTransactionNumber = async (businessId) => {
    try {
      console.log('Generating transaction number for business:', businessId);
      
      const today = new Date();
      const dateStr = today.getFullYear() + 
                     String(today.getMonth() + 1).padStart(2, '0') + 
                     String(today.getDate()).padStart(2, '0');

      console.log('Date string:', dateStr);

      // Call the database function
      const { data, error } = await supabase.rpc('get_next_transaction_number', {
        p_business_id: businessId,
        p_date: today.toISOString().split('T')[0]
      });

      console.log('Database function response:', { data, error });

      if (error) {
        console.error('Error getting transaction number:', error);
        // Fallback to timestamp-based number
        return `${businessId.slice(-8)}-${dateStr}-001`;
      }

      const transactionNumber = data || 1;
      const finalNumber = `${businessId.slice(-8)}-${dateStr}-${String(transactionNumber).padStart(3, '0')}`;
      
      console.log('Generated transaction number:', finalNumber);
      
      return finalNumber;
    } catch (err) {
      console.error('Transaction number generation failed:', err);
      // Fallback
      const dateStr = new Date().toISOString().slice(0, 10).replace(/-/g, '');
      return `${businessId.slice(-8)}-${dateStr}-001`;
    }
  };

  const loadReceiptData = async () => {
    if (saveInProgress) {
      console.log('Save already in progress, skipping...');
      return;
    }

    try {
      setLoading(true);
      setSaveInProgress(true);

      // Fetch business settings for receipt generation
      const { data: settings, error: settingsError } = await supabase
        .from('pos_settings')
        .select('*')
        .eq('business_id', selectedBusinessId)
        .single();

      if (settingsError) throw settingsError;

      // Fetch actual business information from businesses table
      const { data: businessInfo, error: businessError } = await supabase
        .from('businesses')
        .select('*')
        .eq('id', selectedBusinessId)
        .single();

      if (businessError) {
        console.error('Error fetching business info:', businessError);
      }

      // Fetch loyalty settings separately from pos_loyalty_settings
      const { data: loyaltySettings, error: loyaltyError } = await supabase
        .from('pos_loyalty_settings')
        .select('*')
        .eq('business_id', selectedBusinessId)
        .single();

      // Enhanced business settings for receipt with REAL business data
      const enhancedSettings = {
        ...settings,
        // Real business information from businesses table - using exact column names
        business_name: businessInfo?.name || 'Your Business Name',
        business_address: businessInfo?.business_address || '123 Main St',
        business_city: businessInfo?.business_city || 'Your City',
        business_state: businessInfo?.business_state || 'ON', 
        business_postal: businessInfo?.business_postal || 'N1A 1A1',
        business_phone: businessInfo?.business_phone || '(555) 123-4567',
        business_email: businessInfo?.business_email || 'hello@yourbusiness.com',
        business_website: businessInfo?.business_website || 'www.yourbusiness.com',
        tax_number: businessInfo?.tax_number || 'HST#123456789',
        // Loyalty settings from pos_loyalty_settings table
        loyalty_mode: loyaltySettings?.loyalty_mode || 'dollars',
        earn_rate_percentage: loyaltySettings?.earn_rate_percentage || 3,
        redemption_rate: loyaltySettings?.redemption_rate || 0.01,
        min_redemption: loyaltySettings?.min_redemption || 5,
        ...loyaltySettings
      };

      setBusinessSettings(enhancedSettings);
      console.log('Receipt Screen - Loyalty settings loaded:', loyaltySettings);
      console.log('Receipt Screen - Enhanced settings:', enhancedSettings);

      // Generate the new transaction number from the database
      const newTransactionNumber = await generateTransactionNumber(selectedBusinessId);
      console.log('New transaction number generated:', newTransactionNumber);
      
      // Map the received sale data to match database field names
      const mappedSaleData = {
        ...receivedSaleData,
        sale_number: newTransactionNumber,
        // Map field names to match database schema
        final_total: receivedSaleData.total || receivedSaleData.final_total || 0,
        subtotal: receivedSaleData.subtotal || 0,
        tax_amount: receivedSaleData.tax || receivedSaleData.tax_amount || 0,
        discount_amount: receivedSaleData.discount || receivedSaleData.discount_amount || 0,
        loyalty_redemption: receivedSaleData.loyalty_discount || receivedSaleData.loyalty_redemption || 0,
        tip_amount: receivedSaleData.tip_amount || 0
      };

      console.log('Mapped sale data:', mappedSaleData);

      // Save the sale to database and get the complete sale data
      const completeSaleData = await saveSaleToDatabase(mappedSaleData, enhancedSettings);

      setSaleData(completeSaleData);

      // Pre-fill email if loyalty customer
      if (completeSaleData.loyaltyCustomer?.customer_email) {
        setEmailAddress(completeSaleData.loyaltyCustomer.customer_email);
      }

      // Auto-print if enabled in settings
      if (enhancedSettings.auto_print_receipt) {
        handlePrintReceipt();
      }

      // Auto-email if enabled and email available
      if (enhancedSettings.auto_email_receipt && completeSaleData.loyaltyCustomer?.customer_email) {
        handleEmailReceipt(completeSaleData.loyaltyCustomer.customer_email);
      }

      await logAction({
        action: 'receipt_screen_opened',
        context: 'ReceiptScreen',
        metadata: {
          sale_id: completeSaleData.sale_id,
          sale_number: completeSaleData.sale_number,
          total_amount: completeSaleData.final_total
        }
      }).catch(err => {
        console.error('Audit logging failed:', err);
        // Don't throw - receipt should still work even if audit logging fails
      });

    } catch (err) {
      console.error('Error loading receipt data:', err);
      setError(err.message);
    } finally {
      setLoading(false);
      setSaveInProgress(false);
    }
  };

  const saveSaleToDatabase = async (saleData, businessSettings) => {
    try {
      console.log('Saving sale to database:', saleData.sale_number);
      
      // First check if sale already exists
      const { data: existingSale, error: checkError } = await supabase
        .from('pos_sales')
        .select('id, sale_number')
        .eq('business_id', selectedBusinessId)
        .eq('sale_number', saleData.sale_number)
        .maybeSingle();

      if (checkError && checkError.code !== 'PGRST116') {
        console.error('Error checking existing sale:', checkError);
        throw checkError;
      }

      let saleRecord;

      if (existingSale) {
        console.log('Sale already exists, using existing record:', existingSale);
        saleRecord = existingSale;
      } else {
        // Save to pos_sales table with correct field names
        const { data: newSale, error: saleError } = await supabase
          .from('pos_sales')
          .insert({
            business_id: selectedBusinessId,
            sale_number: saleData.sale_number,
            user_id: saleData.user_id || null,
            customer_name: saleData.loyaltyCustomer?.customer_name || null,
            customer_phone: saleData.loyaltyCustomer?.customer_phone || null,
            subtotal: saleData.subtotal || 0,
            tax: saleData.tax_amount || 0,
            fees: saleData.fees || 0,
            discount: saleData.discount_amount || 0,
            loyalty_discount: saleData.loyalty_redemption || 0,
            total: saleData.final_total || 0,
            payment_status: 'completed',
            payment_method: saleData.payments?.[0]?.payment_method || 'cash',
            notes: saleData.notes || null,
            loyalty_customer_id: saleData.loyaltyCustomer?.id || null,
            customer_id: saleData.loyaltyCustomer?.id || null,
            item_count: saleData.items?.length || 0,
            created_at: new Date().toISOString()
          })
          .select()
          .single();

        if (saleError) {
          console.error('Error saving sale:', saleError);
          throw saleError;
        }

        saleRecord = newSale;
        console.log('Sale saved successfully:', saleRecord);
      }

      console.log('Sale saved successfully:', saleRecord);

      // Save sale items to pos_sale_items table
      if (saleData.items && saleData.items.length > 0) {
        const saleItems = saleData.items.map(item => ({
          business_id: selectedBusinessId,
          sale_id: saleRecord.id,
          inventory_id: item.inventory_id || null,
          name: item.name,
          sku: item.sku || null,
          quantity: item.quantity || 1,
          unit_price: item.price || 0,
          total_price: (item.price || 0) * (item.quantity || 1),
          modifiers: item.modifiers || null,
          notes: item.notes || null,
          station_id: item.station_id || null,
          created_at: new Date().toISOString()
        }));

        const { error: itemsError } = await supabase
          .from('pos_sale_items')
          .insert(saleItems);

        if (itemsError) {
          console.error('Error saving sale items:', itemsError);
          // Don't throw here, sale is already saved
        } else {
          console.log('Sale items saved successfully');
        }
      }

      // Save payments to pos_payments table
      if (saleData.payments && saleData.payments.length > 0) {
        const payments = saleData.payments.map(payment => ({
          business_id: selectedBusinessId,
          sale_id: saleRecord.id,
          payment_method: payment.method || payment.payment_method,
          amount: payment.amount || 0,
          custom_method_name: payment.custom_method_name || null,
          reference_number: payment.reference_number || null,
          processed_by: saleData.user_id || null,
          change_given: payment.change_given || 0,
          tip_amount: payment.tip_amount || 0,
          notes: payment.notes || null,
          processed_at: new Date().toISOString(),
          created_at: new Date().toISOString()
        }));

        const { error: paymentsError } = await supabase
          .from('pos_payments')
          .insert(payments);

        if (paymentsError) {
          console.error('Error saving payments:', paymentsError);
          // Don't throw here, sale is already saved
        } else {
          console.log('Payments saved successfully');
        }
      }

      // Handle loyalty transactions if customer present
      if (saleData.loyaltyCustomer) {
        await handleLoyaltyTransactions(saleRecord, saleData, businessSettings);
      }

      // Return complete sale data with correct field mappings
      const completeSaleData = {
        ...saleData,
        sale_id: saleRecord.id,
        // Map database fields back to expected receipt format
        final_total: saleRecord.total,
        tax_amount: saleRecord.tax,
        discount_amount: saleRecord.discount,
        loyalty_redemption: saleRecord.loyalty_discount,
        change_given: saleData.payments?.[0]?.change_given || 0
      };

      return completeSaleData;

    } catch (err) {
      console.error('Error saving sale to database:', err);
      throw err;
    }
  };

  const handleLoyaltyTransactions = async (saleRecord, saleData, businessSettings) => {
    try {
      const pointsEarned = businessSettings.loyalty_mode === 'points'
        ? Math.round((saleData.subtotal || 0) * (businessSettings.earn_rate_percentage || 3) / 100 * 1000)
        : (saleData.subtotal || 0) * (businessSettings.redemption_rate || 0.01);

      console.log('Loyalty customer found, points earned:', pointsEarned);

      // Get current customer balance for before/after calculations
      const currentBalance = saleData.loyaltyCustomer.balance || 0;
      const currentPoints = saleData.loyaltyCustomer.points || 0;

      // Record points earned
      if (pointsEarned > 0) {
        const earnAmount = businessSettings.loyalty_mode === 'points' 
          ? pointsEarned / 1000  // Store as dollars
          : pointsEarned;

        const { error: earnError } = await supabase
          .from('pos_loyalty_transactions')
          .insert({
            business_id: selectedBusinessId,
            loyalty_account_id: saleData.loyaltyCustomer.id,  // Correct field name
            transaction_id: saleRecord.id,  // Link to sale
            transaction_type: 'earn',
            amount: earnAmount,
            points: businessSettings.loyalty_mode === 'points' ? pointsEarned : null,
            balance_before: currentBalance,
            balance_after: currentBalance + earnAmount,
            points_before: businessSettings.loyalty_mode === 'points' ? currentPoints : null,
            points_after: businessSettings.loyalty_mode === 'points' ? currentPoints + pointsEarned : null,
            description: `Earned from sale ${saleData.sale_number}`,
            processed_by: saleData.user_id || null,
            processed_at: new Date().toISOString(),
            created_at: new Date().toISOString()
          });

        if (earnError) {
          console.error('Error saving loyalty earn transaction:', earnError);
        } else {
          console.log('Loyalty earn transaction saved successfully');
        }
      }

      // Record points redeemed
      if (saleData.loyalty_redemption > 0) {
        const redeemAmount = saleData.loyalty_redemption;
        const redeemPoints = businessSettings.loyalty_mode === 'points' 
          ? Math.round(saleData.loyalty_redemption * 1000) 
          : null;

        const { error: redeemError } = await supabase
          .from('pos_loyalty_transactions')
          .insert({
            business_id: selectedBusinessId,
            loyalty_account_id: saleData.loyaltyCustomer.id,  // Correct field name
            transaction_id: saleRecord.id,  // Link to sale
            transaction_type: 'redeem',
            amount: -redeemAmount, // Negative for redemption
            points: redeemPoints ? -redeemPoints : null,
            balance_before: currentBalance,
            balance_after: currentBalance - redeemAmount,
            points_before: businessSettings.loyalty_mode === 'points' ? currentPoints : null,
            points_after: businessSettings.loyalty_mode === 'points' ? currentPoints - redeemPoints : null,
            description: `Redeemed on sale ${saleData.sale_number}`,
            processed_by: saleData.user_id || null,
            processed_at: new Date().toISOString(),
            created_at: new Date().toISOString()
          });

        if (redeemError) {
          console.error('Error saving loyalty redeem transaction:', redeemError);
        } else {
          console.log('Loyalty redeem transaction saved successfully');
        }
      }

      // Update customer balance
      const earnAmount = businessSettings.loyalty_mode === 'points' 
        ? pointsEarned / 1000 
        : pointsEarned;
      const newBalance = currentBalance + earnAmount - (saleData.loyalty_redemption || 0);
      const newPoints = businessSettings.loyalty_mode === 'points' 
        ? currentPoints + pointsEarned - (Math.round((saleData.loyalty_redemption || 0) * 1000))
        : null;

      const { error: balanceError } = await supabase
        .from('pos_loyalty_accounts')
        .update({ 
          balance: newBalance,
          points: newPoints,
          updated_at: new Date().toISOString()
        })
        .eq('id', saleData.loyaltyCustomer.id);

      if (balanceError) {
        console.error('Error updating customer balance:', balanceError);
      } else {
        console.log('Customer balance updated successfully:', { newBalance, newPoints });
      }

      // Update the loyalty customer data with new balance for display
      saleData.loyaltyCustomer.balance = newBalance;
      if (businessSettings.loyalty_mode === 'points') {
        saleData.loyaltyCustomer.points = newPoints;
      }

    } catch (err) {
      console.error('Error handling loyalty transactions:', err);
    }
  };

  // Helper function to log receipt events
  const logReceiptEvent = async (receiptType, additionalData = {}) => {
    try {
      // Get current user ID
      const { data: { user } } = await supabase.auth.getUser();
      const currentUserId = user?.id;

      const logData = {
        business_id: selectedBusinessId,
        sale_id: saleData.sale_id,
        receipt_type: receiptType,
        printed_by: currentUserId,
        print_method: 'browser',
        ...additionalData
      };

      const { error } = await supabase
        .from('pos_receipt_logs')
        .insert(logData);

      if (error) {
        console.error('Receipt log error:', error);
      }
    } catch (err) {
      console.error('Failed to log receipt event:', err);
    }
  };

  const handlePrintReceipt = async (receiptType = RECEIPT_TYPES.STANDARD) => {
    try {
      const receiptHTML = generateReceiptHTML(saleData, receiptType, businessSettings);
      printReceipt(receiptHTML);
      setReceiptGenerated(true);

      // Log the receipt printing
      await logReceiptEvent(receiptType);

      await logAction({
        action: 'receipt_printed',
        context: 'ReceiptScreen',
        metadata: {
          sale_id: saleData.sale_id,
          receipt_type: receiptType,
          print_method: 'browser'
        }
      });

    } catch (err) {
      console.error('Print receipt error:', err);
      setError('Failed to print receipt');
    }
  };

  const handleEmailReceipt = async (email = emailAddress) => {
    if (!email || !email.includes('@')) {
      setError('Please enter a valid email address');
      return;
    }

    setEmailSending(true);
    setError(null);

    try {
      const emailHTML = generateEmailReceiptHTML(saleData, businessSettings);
      
      // Here you would integrate with your email service (SendGrid, etc.)
      // For now, we'll simulate the email sending
      await new Promise(resolve => setTimeout(resolve, 2000));

      // Log the email receipt
      await logReceiptEvent('email', {
        email_address: email,
        print_method: 'email'
      });

      // Log the email in database
      const { error: emailLogError } = await supabase
        .from('pos_receipts')
        .insert({
          business_id: selectedBusinessId,
          sale_id: saleData.sale_id,
          total: saleData.final_total,
          items: saleData.items || [],
          email_sent_to: email,
          receipt_type: 'email',
          created_at: new Date().toISOString()
        });

      if (emailLogError) console.warn('Email log error:', emailLogError);

      await logAction({
        action: 'receipt_emailed',
        context: 'ReceiptScreen',
        metadata: {
          sale_id: saleData.sale_id,
          email_address: email,
          receipt_type: 'email'
        }
      });

      setShowEmailModal(false);
      setEmailAddress('');
      alert('Receipt emailed successfully!');

    } catch (err) {
      console.error('Email receipt error:', err);
      setError('Failed to send email receipt');
    } finally {
      setEmailSending(false);
    }
  };

  const handleNewSale = () => {
    navigate('/dashboard/pos/register');
  };

  const handleReprintReceipt = async (reason = 'Customer Request') => {
    try {
      const receiptHTML = generateReceiptHTML(
        saleData, 
        RECEIPT_TYPES.REPRINT, 
        businessSettings,
        { reprintReason: reason }
      );
      printReceipt(receiptHTML);

      // Log the reprint with reason
      await logReceiptEvent('reprint', {
        reprint_reason: reason
      });

      // Log the reprint
      await logAction({
        action: 'receipt_reprinted',
        context: 'ReceiptScreen',
        metadata: {
          sale_id: saleData.sale_id,
          reprint_reason: reason,
          original_receipt_date: saleData.created_at
        }
      });

    } catch (err) {
      console.error('Reprint receipt error:', err);
      setError('Failed to reprint receipt');
    }
  };

  const renderLoyaltyInfo = () => {
    if (!saleData.loyaltyCustomer) return null;

    const isPointsMode = businessSettings.loyalty_mode === 'points';
    const dollarBalance = saleData.loyaltyCustomer.balance || 0;
    const pointsPerDollar = 1000;

    // Calculate points earned
    const subtotal = saleData.subtotal || 0;
    const earnPercentage = businessSettings.earn_rate_percentage || 3;
    const dollarEarned = subtotal * (earnPercentage / 100);
    const pointsEarned = Math.round(dollarEarned * pointsPerDollar);

    // Calculate current balance in points
    const currentPointsBalance = Math.round(dollarBalance * pointsPerDollar);

    console.log('Rendering loyalty info:', {
      isPointsMode,
      dollarBalance,
      pointsEarned,
      currentPointsBalance
    });

    return (
      <>
        <div style={styles.loyaltyEarned}>
          {isPointsMode 
            ? `🏆 Points Earned: ${pointsEarned.toLocaleString()}`
            : `💰 Earned: $${dollarEarned.toFixed(2)}`
          }
        </div>
        <div style={styles.loyaltyBalance}>
          {isPointsMode 
            ? `💳 Balance: ${currentPointsBalance.toLocaleString()} points`
            : `💳 Balance: $${dollarBalance.toFixed(2)}`
          }
        </div>
      </>
    );
  };

  // Loading and error states
  if (authLoading) {
    return (
      <div style={{...styles.container, justifyContent: 'center', alignItems: 'center'}}>
        <h3>Loading Receipt System...</h3>
        <p>Authenticating user and loading business data...</p>
      </div>
    );
  }

  if (authError) {
    return (
      <div style={{...styles.container, justifyContent: 'center', alignItems: 'center'}}>
        <h3>Authentication Error</h3>
        <p>{authError}</p>
        <button 
          style={styles.button}
          onClick={() => navigate('/login')}
        >
          Return to Login
        </button>
      </div>
    );
  }

  if (loading) {
    return (
      <div style={styles.container}>
        <div style={styles.loading}>Loading receipt...</div>
      </div>
    );
  }

  if (error) {
    return (
      <div style={styles.container}>
        <div style={styles.error}>
          <h3>Error</h3>
          <p>{error}</p>
          <button style={styles.button} onClick={handleNewSale}>
            Start New Sale
          </button>
        </div>
      </div>
    );
  }

  if (!saleData) {
    return (
      <div style={styles.container}>
        <div style={styles.error}>
          <h3>No Receipt Data</h3>
          <p>Sale information not found</p>
          <button style={styles.button} onClick={handleNewSale}>
            Start New Sale
          </button>
        </div>
      </div>
    );
  }

  return (
    <div style={styles.container}>
      <div style={styles.header}>
        <h2>🎉 Sale Complete!</h2>
        <p>Sale #{saleData.sale_number} - ${(saleData.final_total || 0).toFixed(2)}</p>
      </div>

      <div style={styles.content}>
        {/* Sale Summary */}
        <div style={styles.section}>
          <h3 style={styles.sectionTitle}>Transaction Summary</h3>
          <div style={styles.summaryGrid}>
            <div style={styles.summaryRow}>
              <span>Items:</span>
              <span>{saleData.item_count || saleData.items?.length || 0}</span>
            </div>
            <div style={styles.summaryRow}>
              <span>Subtotal:</span>
              <span>${(saleData.subtotal || 0).toFixed(2)}</span>
            </div>
            {saleData.discount_amount > 0 && (
              <div style={styles.summaryRow}>
                <span>Discount:</span>
                <span>-${saleData.discount_amount.toFixed(2)}</span>
              </div>
            )}
            {saleData.loyalty_redemption > 0 && (
              <div style={styles.summaryRow}>
                <span>Loyalty Credit:</span>
                <span>-${saleData.loyalty_redemption.toFixed(2)}</span>
              </div>
            )}
            <div style={styles.summaryRow}>
              <span>Tax:</span>
              <span>${(saleData.tax_amount || 0).toFixed(2)}</span>
            </div>
            {saleData.tip_amount > 0 && (
              <div style={styles.summaryRow}>
                <span>Tip:</span>
                <span>${saleData.tip_amount.toFixed(2)}</span>
              </div>
            )}
            <div style={styles.summaryRowTotal}>
              <span>Total:</span>
              <span>${(saleData.final_total || 0).toFixed(2)}</span>
            </div>
          </div>
        </div>

        {/* Payment Summary */}
        {saleData.payments && saleData.payments.length > 0 && (
          <div style={styles.section}>
            <h3 style={styles.sectionTitle}>Payment Methods</h3>
            <div style={styles.paymentsList}>
              {saleData.payments.map((payment, index) => (
                <div key={index} style={styles.paymentRow}>
                  <span style={styles.paymentMethod}>
                    {payment.custom_method_name || payment.method || payment.payment_method}
                  </span>
                  <span style={styles.paymentAmount}>
                    ${payment.amount.toFixed(2)}
                  </span>
                </div>
              ))}
              
              {/* Add loyalty points/redemption if used */}
              {saleData.loyalty_redemption > 0 && (
                <div style={styles.paymentRow}>
                  <span style={styles.paymentMethod}>
                    {businessSettings.loyalty_mode === 'points' ? 'Loyalty Points' : 'Loyalty Credit'}
                  </span>
                  <span style={styles.paymentAmount}>
                    {businessSettings.loyalty_mode === 'points' 
                      ? `-${Math.round(saleData.loyalty_redemption * 1000).toLocaleString()} pts`
                      : `-$${saleData.loyalty_redemption.toFixed(2)}`
                    }
                  </span>
                </div>
              )}
              
              {saleData.change_given > 0 && (
                <div style={styles.paymentRow}>
                  <span style={styles.changeLabel}>Change Given:</span>
                  <span style={styles.changeAmount}>
                    ${saleData.change_given.toFixed(2)}
                  </span>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Receipt Options */}
        <div style={styles.section}>
          <h3 style={styles.sectionTitle}>Receipt Options</h3>
          <div style={styles.receiptOptions}>
            <button
              style={styles.receiptButton}
              onClick={() => handlePrintReceipt(RECEIPT_TYPES.STANDARD)}
            >
              🖨️ Print Receipt
            </button>
            
            <button
              style={styles.receiptButton}
              onClick={() => handlePrintReceipt(RECEIPT_TYPES.GIFT)}
            >
              🎁 Print Gift Receipt
            </button>
            
            <button
              style={styles.receiptButton}
              onClick={() => handlePrintReceipt(RECEIPT_TYPES.KITCHEN)}
            >
              🍽️ Print Kitchen Receipt
            </button>
            
            <button
              style={styles.receiptButton}
              onClick={() => setShowEmailModal(true)}
            >
              📧 Email Receipt
            </button>
            
            <button
              style={styles.receiptButton}
              onClick={() => handleReprintReceipt()}
            >
              📄 Reprint Receipt
            </button>
            
            <button
              style={styles.receiptButtonSecondary}
              onClick={handleNewSale}
            >
              ❌ No Receipt
            </button>
          </div>
        </div>

        {/* Customer Information */}
        {saleData.loyaltyCustomer && (
          <div style={styles.section}>
            <h3 style={styles.sectionTitle}>Customer Information</h3>
            <div style={styles.customerInfo}>
              <div style={styles.customerName}>
                {saleData.loyaltyCustomer.customer_name}
              </div>
              {saleData.loyaltyCustomer.customer_email && (
                <div style={styles.customerDetail}>
                  📧 {saleData.loyaltyCustomer.customer_email}
                </div>
              )}
              {saleData.loyaltyCustomer.customer_phone && (
                <div style={styles.customerDetail}>
                  📞 {saleData.loyaltyCustomer.customer_phone}
                </div>
              )}
              {renderLoyaltyInfo()}
            </div>
          </div>
        )}
      </div>

      {/* Email Modal */}
      {showEmailModal && (
        <div style={styles.modal}>
          <div style={styles.modalContent}>
            <h3>Email Receipt</h3>
            <p>Enter email address to send receipt:</p>
            <input
              type="email"
              value={emailAddress}
              onChange={(e) => setEmailAddress(e.target.value)}
              placeholder="customer@example.com"
              style={styles.emailInput}
              autoFocus
            />
            {error && (
              <div style={styles.modalError}>{error}</div>
            )}
            <div style={styles.modalActions}>
              <button
                style={styles.cancelButton}
                onClick={() => {
                  setShowEmailModal(false);
                  setError(null);
                }}
                disabled={emailSending}
              >
                Cancel
              </button>
              <button
                style={styles.sendButton}
                onClick={() => handleEmailReceipt()}
                disabled={emailSending || !emailAddress}
              >
                {emailSending ? 'Sending...' : 'Send Email'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Action Buttons */}
      <div style={styles.actions}>
        <button
          style={styles.newSaleButton}
          onClick={handleNewSale}
        >
          Start New Sale
        </button>
      </div>
    </div>
  );
};

const styles = {
  container: {
    display: 'flex',
    flexDirection: 'column',
    height: '100vh',
    backgroundColor: '#f8f9fa',
    padding: '20px',
    paddingTop: '100px',
    boxSizing: 'border-box'
  },
  header: {
    marginBottom: '30px',
    textAlign: 'center',
    backgroundColor: '#008080',
    color: 'white',
    padding: '20px',
    borderRadius: '8px'
  },
  content: {
    flex: 1,
    overflowY: 'auto',
    marginBottom: '20px'
  },
  section: {
    backgroundColor: 'white',
    borderRadius: '8px',
    padding: '20px',
    marginBottom: '20px',
    border: '1px solid #e5e7eb'
  },
  sectionTitle: {
    margin: '0 0 15px 0',
    fontSize: '18px',
    fontWeight: 'bold',
    color: '#1f2937',
    borderBottom: '2px solid #008080',
    paddingBottom: '8px'
  },
  summaryGrid: {
    display: 'flex',
    flexDirection: 'column',
    gap: '8px'
  },
  summaryRow: {
    display: 'flex',
    justifyContent: 'space-between',
    fontSize: '16px',
    color: '#1f2937'
  },
  summaryRowTotal: {
    display: 'flex',
    justifyContent: 'space-between',
    fontSize: '20px',
    fontWeight: 'bold',
    color: '#1f2937',
    paddingTop: '12px',
    borderTop: '2px solid #008080',
    marginTop: '8px'
  },
  paymentsList: {
    display: 'flex',
    flexDirection: 'column',
    gap: '8px'
  },
  paymentRow: {
    display: 'flex',
    justifyContent: 'space-between',
    padding: '8px',
    backgroundColor: '#f9fafb',
    borderRadius: '4px'
  },
  paymentMethod: {
    fontSize: '14px',
    color: '#374151',
    textTransform: 'capitalize'
  },
  paymentAmount: {
    fontSize: '14px',
    fontWeight: 'bold',
    color: '#059669'
  },
  changeLabel: {
    fontSize: '14px',
    fontWeight: 'bold',
    color: '#f59e0b'
  },
  changeAmount: {
    fontSize: '14px',
    fontWeight: 'bold',
    color: '#f59e0b'
  },
  receiptOptions: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
    gap: '12px'
  },
  receiptButton: {
    padding: '15px',
    backgroundColor: '#008080',
    color: 'white',
    border: 'none',
    borderRadius: '8px',
    fontSize: '14px',
    fontWeight: 'bold',
    cursor: 'pointer',
    transition: 'all 0.2s ease',
    textAlign: 'center'
  },
  receiptButtonSecondary: {
    padding: '15px',
    backgroundColor: '#6b7280',
    color: 'white',
    border: 'none',
    borderRadius: '8px',
    fontSize: '14px',
    fontWeight: 'bold',
    cursor: 'pointer',
    transition: 'all 0.2s ease',
    textAlign: 'center'
  },
  customerInfo: {
    padding: '15px',
    backgroundColor: '#008080',
    color: 'white',
    borderRadius: '6px'
  },
  customerName: {
    fontSize: '18px',
    fontWeight: 'bold',
    marginBottom: '8px'
  },
  customerDetail: {
    fontSize: '14px',
    marginBottom: '4px',
    opacity: 0.9
  },
  loyaltyEarned: {
    fontSize: '14px',
    marginTop: '8px',
    fontWeight: '600',
    backgroundColor: 'rgba(255,255,255,0.2)',
    padding: '6px 10px',
    borderRadius: '4px',
    display: 'inline-block'
  },
  loyaltyBalance: {
    fontSize: '14px',
    marginTop: '6px',
    fontWeight: '600',
    backgroundColor: 'rgba(255,255,255,0.15)',
    padding: '6px 10px',
    borderRadius: '4px',
    display: 'inline-block',
    marginLeft: '8px'
  },
  modal: {
    position: 'fixed',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0,0,0,0.5)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 1000
  },
  modalContent: {
    backgroundColor: 'white',
    padding: '30px',
    borderRadius: '8px',
    maxWidth: '400px',
    width: '90%'
  },
  emailInput: {
    width: '100%',
    padding: '12px',
    border: '2px solid #d1d5db',
    borderRadius: '6px',
    fontSize: '16px',
    marginBottom: '15px'
  },
  modalError: {
    color: '#dc2626',
    fontSize: '14px',
    marginBottom: '15px'
  },
  modalActions: {
    display: 'flex',
    gap: '10px'
  },
  cancelButton: {
    flex: 1,
    padding: '12px',
    backgroundColor: '#6b7280',
    color: 'white',
    border: 'none',
    borderRadius: '6px',
    cursor: 'pointer'
  },
  sendButton: {
    flex: 1,
    padding: '12px',
    backgroundColor: '#008080',
    color: 'white',
    border: 'none',
    borderRadius: '6px',
    cursor: 'pointer'
  },
  actions: {
    display: 'flex',
    justifyContent: 'center'
  },
  newSaleButton: {
    padding: '20px 40px',
    backgroundColor: '#008080',
    color: 'white',
    border: 'none',
    borderRadius: '8px',
    fontSize: '18px',
    fontWeight: 'bold',
    cursor: 'pointer',
    minWidth: '200px'
  },
  loading: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    height: '200px',
    fontSize: '18px',
    color: '#6b7280'
  },
  error: {
    textAlign: 'center',
    padding: '40px',
    color: '#dc2626'
  },
  button: {
    padding: '12px 24px',
    backgroundColor: '#008080',
    color: 'white',
    border: 'none',
    borderRadius: '6px',
    cursor: 'pointer',
    fontSize: '16px',
    fontWeight: 'bold'
  }
};

export default ReceiptScreen;