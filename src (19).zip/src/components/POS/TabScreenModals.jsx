// components/POS/ManagerOverrideModal.jsx
import React, { useState } from 'react';
import BarcodeScanHandler from './BarcodeScanHandler';

export const ManagerOverrideModal = ({
  showModal,
  onClose,
  overrideReason,
  onApproveOverride,
  error
}) => {
  const [managerPin, setManagerPin] = useState('');

  if (!showModal) return null;

  const handleSubmit = () => {
    onApproveOverride(managerPin);
  };

  return (
    <div style={styles.modal}>
      <div style={styles.modalContent}>
        <div style={styles.modalHeader}>
          <h3>Manager Override Required</h3>
          <button
            style={styles.closeModalButton}
            onClick={onClose}
          >
            ×
          </button>
        </div>
        
        <p>{overrideReason}</p>
        
        {error && <div style={styles.errorBanner}>{error}</div>}
        
        <div style={styles.form}>
          <div style={styles.formGroup}>
            <label style={styles.label}>Manager PIN</label>
            <input
              type="password"
              value={managerPin}
              onChange={(e) => setManagerPin(e.target.value)}
              placeholder="Enter manager PIN"
              style={styles.input}
              autoFocus
            />
          </div>
        </div>
        
        <div style={styles.modalActions}>
          <button
            style={styles.cancelButton}
            onClick={onClose}
          >
            Cancel
          </button>
          <button
            style={styles.submitButton}
            onClick={handleSubmit}
            disabled={!managerPin}
          >
            Approve Override
          </button>
        </div>
      </div>
    </div>
  );
};

// components/POS/TabDetailsModal.jsx
export const TabDetailsModal = ({
  showModal,
  onClose,
  selectedTab,
  onAddItems,
  onMakePayment,
  formatCurrency
}) => {
  if (!showModal || !selectedTab) return null;

  return (
    <div style={styles.modal}>
      <div style={styles.modalContent}>
        <div style={styles.modalHeader}>
          <h3>Tab Details - {selectedTab.tab_number}</h3>
          <button
            style={styles.closeModalButton}
            onClick={onClose}
          >
            ×
          </button>
        </div>
        
        <div style={styles.tabDetails}>
          <div style={styles.detailSection}>
            <h4>Customer Information</h4>
            <p><strong>Name:</strong> {selectedTab.customer_name}</p>
            {selectedTab.customer_phone && (
              <p><strong>Phone:</strong> {selectedTab.customer_phone}</p>
            )}
            {selectedTab.customer_email && (
              <p><strong>Email:</strong> {selectedTab.customer_email}</p>
            )}
            {selectedTab.pos_loyalty_accounts && (
              <p><strong>Loyalty Member:</strong> Yes (Balance: {formatCurrency(selectedTab.pos_loyalty_accounts.balance || 0)})</p>
            )}
            {selectedTab.notes && (
              <p><strong>Notes:</strong> {selectedTab.notes}</p>
            )}
          </div>
          
          <div style={styles.detailSection}>
            <h4>Financial Summary</h4>
            <p><strong>Subtotal:</strong> {formatCurrency(selectedTab.subtotal)}</p>
            <p><strong>Tax:</strong> {formatCurrency(selectedTab.tax_amount)}</p>
            <p><strong>Total:</strong> {formatCurrency(selectedTab.total_amount)}</p>
            <p><strong>Amount Paid:</strong> {formatCurrency(selectedTab.amount_paid)}</p>
            <p><strong>Balance Remaining:</strong> {formatCurrency(selectedTab.balance_remaining)}</p>
          </div>
          
          <div style={styles.detailSection}>
            <h4>Items ({selectedTab.pos_tab_items?.length || 0})</h4>
            {selectedTab.pos_tab_items?.length > 0 ? (
              <div style={styles.itemsList}>
                {selectedTab.pos_tab_items.map((item, index) => (
                  <div key={index} style={styles.itemRow}>
                    <span>{item.quantity}x {item.name}</span>
                    <span>{formatCurrency(item.total_price)}</span>
                  </div>
                ))}
              </div>
            ) : (
              <p style={styles.emptyItems}>No items added yet</p>
            )}
          </div>
        </div>
        
        <div style={styles.modalActions}>
          <button
            style={styles.actionButton}
            onClick={() => onAddItems(selectedTab)}
          >
            Add Items
          </button>
          {selectedTab.balance_remaining > 0 && (
            <button
              style={styles.payButton}
              onClick={() => onMakePayment(selectedTab)}
            >
              Make Payment
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

// components/POS/QRManualInputModal.jsx
export const QRManualInputModal = ({
  showModal,
  onClose,
  onSubmit,
  value,
  onChange,
  placeholder = "Paste or type the QR code data here...",
  title = "Enter QR Code Manually",
  instructions = "Enter the QR code data"
}) => {
  if (!showModal) return null;

  return (
    <div style={styles.modal}>
      <div style={styles.modalContent}>
        <div style={styles.modalHeader}>
          <h3>{title}</h3>
          <button
            style={styles.closeModalButton}
            onClick={onClose}
          >
            ×
          </button>
        </div>
        
        <div style={styles.form}>
          <div style={styles.formGroup}>
            <label style={styles.label}>QR Code Value:</label>
            <input
              type="text"
              value={value}
              onChange={(e) => onChange(e.target.value)}
              placeholder={placeholder}
              style={styles.input}
              autoFocus
            />
            <p style={styles.qrInstructions}>
              {instructions}
            </p>
          </div>
        </div>
        
        <div style={styles.modalActions}>
          <button
            style={styles.cancelButton}
            onClick={onClose}
          >
            Cancel
          </button>
          <button
            style={styles.submitButton}
            onClick={onSubmit}
            disabled={!value.trim()}
          >
            Search
          </button>
        </div>
      </div>
    </div>
  );
};

// components/POS/QRScannerModal.jsx
export const QRScannerModal = ({
  showModal,
  onClose,
  onScan,
  title = "Scan QR Code",
  instructions = "Scan the QR code"
}) => {
  if (!showModal) return null;

  return (
    <div style={styles.modal}>
      <div style={styles.modalContent}>
        <div style={styles.modalHeader}>
          <h3>{title}</h3>
          <button
            style={styles.closeModalButton}
            onClick={onClose}
          >
            ×
          </button>
        </div>
        
        <BarcodeScanHandler onScan={onScan} />
        
        <div style={styles.qrInputSection}>
          <p style={styles.qrInstructions}>
            {instructions}
          </p>
          
          <div style={styles.modalActions}>
            <button
              style={styles.cancelButton}
              onClick={onClose}
            >
              Cancel
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

const styles = {
  modal: {
    position: 'fixed',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0,0,0,0.5)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 1000
  },
  modalContent: {
    backgroundColor: 'white',
    padding: '30px',
    borderRadius: '12px',
    maxWidth: '600px',
    width: '90%',
    maxHeight: '90vh',
    overflowY: 'auto'
  },
  modalHeader: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: '25px',
    paddingBottom: '15px',
    borderBottom: '2px solid #008080'
  },
  closeModalButton: {
    backgroundColor: 'transparent',
    border: 'none',
    fontSize: '24px',
    cursor: 'pointer',
    color: '#6b7280'
  },
  errorBanner: {
    backgroundColor: '#fee2e2',
    color: '#dc2626',
    padding: '15px',
    borderRadius: '6px',
    marginBottom: '20px'
  },
  form: {
    display: 'flex',
    flexDirection: 'column',
    gap: '20px'
  },
  formGroup: {
    display: 'flex',
    flexDirection: 'column'
  },
  label: {
    fontSize: '14px',
    fontWeight: 'bold',
    color: '#374151',
    marginBottom: '6px'
  },
  input: {
    padding: '12px',
    border: '2px solid #d1d5db',
    borderRadius: '6px',
    fontSize: '16px'
  },
  tabDetails: {
    display: 'flex',
    flexDirection: 'column',
    gap: '20px'
  },
  detailSection: {
    backgroundColor: '#f9fafb',
    padding: '15px',
    borderRadius: '6px'
  },
  itemsList: {
    display: 'flex',
    flexDirection: 'column',
    gap: '8px',
    marginTop: '10px'
  },
  itemRow: {
    display: 'flex',
    justifyContent: 'space-between',
    padding: '8px',
    backgroundColor: 'white',
    borderRadius: '4px',
    fontSize: '14px'
  },
  emptyItems: {
    textAlign: 'center',
    color: '#9ca3af',
    fontStyle: 'italic',
    padding: '20px'
  },
  qrInputSection: {
    marginTop: '20px',
    padding: '20px',
    backgroundColor: '#f9fafb',
    borderRadius: '8px',
    border: '1px solid #e5e7eb'
  },
  qrInstructions: {
    fontSize: '14px',
    marginBottom: '15px',
    color: '#6b7280'
  },
  modalActions: {
    display: 'flex',
    gap: '15px',
    marginTop: '25px'
  },
  cancelButton: {
    flex: 1,
    padding: '12px',
    backgroundColor: '#6b7280',
    color: 'white',
    border: 'none',
    borderRadius: '6px',
    cursor: 'pointer',
    fontSize: '16px',
    fontWeight: 'bold'
  },
  submitButton: {
    flex: 1,
    padding: '12px',
    backgroundColor: '#008080',
    color: 'white',
    border: 'none',
    borderRadius: '6px',
    cursor: 'pointer',
    fontSize: '16px',
    fontWeight: 'bold'
  },
  actionButton: {
    flex: 1,
    padding: '12px',
    backgroundColor: '#f3f4f6',
    color: '#374151',
    border: '1px solid #d1d5db',
    borderRadius: '6px',
    cursor: 'pointer',
    fontSize: '16px',
    fontWeight: 'bold'
  },
  payButton: {
    flex: 1,
    padding: '12px',
    backgroundColor: '#059669',
    color: 'white',
    border: 'none',
    borderRadius: '6px',
    cursor: 'pointer',
    fontSize: '16px',
    fontWeight: 'bold'
  }
};