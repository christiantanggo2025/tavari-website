// components/POS/ItemSelectionModal.jsx
import React from 'react';

const ItemSelectionModal = ({
  showModal,
  onClose,
  selectedPaymentTab,
  selectedItems,
  onItemToggle,
  onSelectAllItems,
  onClearItemSelection,
  onProceedToCustomerSelection,
  formatCurrency
}) => {
  if (!showModal || !selectedPaymentTab) return null;

  return (
    <div style={styles.modal}>
      <div style={styles.modalContent}>
        <div style={styles.modalHeader}>
          <h3>Select Items to Pay For - {selectedPaymentTab.tab_number}</h3>
          <button
            style={styles.closeModalButton}
            onClick={onClose}
          >
            ×
          </button>
        </div>

        <div style={styles.itemSelectionContent}>
          <div style={styles.itemSelectionHeader}>
            <p>Customer: <strong>{selectedPaymentTab.customer_name}</strong></p>
            <div style={styles.selectionActions}>
              <button
                style={styles.selectAllButton}
                onClick={onSelectAllItems}
              >
                Select All
              </button>
              <button
                style={styles.clearSelectionButton}
                onClick={onClearItemSelection}
              >
                Clear All
              </button>
            </div>
          </div>

          <div style={styles.itemsList}>
            {selectedPaymentTab.pos_tab_items?.length > 0 ? (
              selectedPaymentTab.pos_tab_items.map((item, index) => (
                <div
                  key={item.id || index}
                  style={{
                    ...styles.itemSelectionRow,
                    ...(selectedItems.some(selected => selected.id === item.id) ? styles.itemSelectionRowSelected : {})
                  }}
                  onClick={() => onItemToggle(item)}
                >
                  <div style={styles.itemSelectionCheckbox}>
                    <input
                      type="checkbox"
                      checked={selectedItems.some(selected => selected.id === item.id)}
                      onChange={() => onItemToggle(item)}
                    />
                  </div>
                  <div style={styles.itemSelectionDetails}>
                    <span style={styles.itemSelectionName}>
                      {item.quantity}x {item.name}
                    </span>
                    {item.modifiers && item.modifiers.length > 0 && (
                      <div style={styles.itemSelectionModifiers}>
                        {item.modifiers.map((mod, modIndex) => (
                          <span key={modIndex} style={styles.itemSelectionModifier}>
                            + {mod.name}
                          </span>
                        ))}
                      </div>
                    )}
                    {item.notes && (
                      <div style={styles.itemSelectionNotes}>
                        Note: {item.notes}
                      </div>
                    )}
                  </div>
                  <div style={styles.itemSelectionPrice}>
                    {formatCurrency(item.total_price)}
                  </div>
                </div>
              ))
            ) : (
              <p style={styles.noItemsText}>No items in this tab</p>
            )}
          </div>

          {selectedItems.length > 0 && (
            <div style={styles.selectionSummary}>
              <div style={styles.selectionSummaryRow}>
                <span>Selected Items: {selectedItems.length}</span>
                <span>
                  Subtotal: {formatCurrency(selectedItems.reduce((sum, item) => sum + (Number(item.total_price) || 0), 0))}
                </span>
              </div>
            </div>
          )}
        </div>

        <div style={styles.modalActions}>
          <button
            style={styles.cancelButton}
            onClick={onClose}
          >
            Cancel
          </button>
          <button
            style={styles.submitButton}
            onClick={onProceedToCustomerSelection}
            disabled={selectedItems.length === 0}
          >
            Continue to Customer Selection
          </button>
        </div>
      </div>
    </div>
  );
};

const styles = {
  modal: {
    position: 'fixed',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0,0,0,0.5)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 1000
  },
  modalContent: {
    backgroundColor: 'white',
    padding: '30px',
    borderRadius: '12px',
    maxWidth: '600px',
    width: '90%',
    maxHeight: '90vh',
    overflowY: 'auto'
  },
  modalHeader: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: '25px',
    paddingBottom: '15px',
    borderBottom: '2px solid #008080'
  },
  closeModalButton: {
    backgroundColor: 'transparent',
    border: 'none',
    fontSize: '24px',
    cursor: 'pointer',
    color: '#6b7280'
  },
  itemSelectionContent: {
    display: 'flex',
    flexDirection: 'column',
    gap: '20px',
    maxHeight: '60vh',
    overflow: 'hidden'
  },
  itemSelectionHeader: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingBottom: '15px',
    borderBottom: '1px solid #e5e7eb'
  },
  selectionActions: {
    display: 'flex',
    gap: '10px'
  },
  selectAllButton: {
    padding: '8px 12px',
    backgroundColor: '#008080',
    color: 'white',
    border: 'none',
    borderRadius: '4px',
    cursor: 'pointer',
    fontSize: '14px',
    fontWeight: 'bold'
  },
  clearSelectionButton: {
    padding: '8px 12px',
    backgroundColor: '#6b7280',
    color: 'white',
    border: 'none',
    borderRadius: '4px',
    cursor: 'pointer',
    fontSize: '14px',
    fontWeight: 'bold'
  },
  itemsList: {
    flex: 1,
    overflowY: 'auto',
    border: '1px solid #e5e7eb',
    borderRadius: '6px'
  },
  itemSelectionRow: {
    display: 'flex',
    alignItems: 'center',
    padding: '12px',
    borderBottom: '1px solid #f3f4f6',
    cursor: 'pointer',
    transition: 'background-color 0.2s'
  },
  itemSelectionRowSelected: {
    backgroundColor: '#f0fdfa',
    borderLeft: '4px solid #008080'
  },
  itemSelectionCheckbox: {
    marginRight: '12px'
  },
  itemSelectionDetails: {
    flex: 1,
    display: 'flex',
    flexDirection: 'column',
    gap: '4px'
  },
  itemSelectionName: {
    fontSize: '16px',
    fontWeight: 'bold',
    color: '#1f2937'
  },
  itemSelectionModifiers: {
    display: 'flex',
    flexWrap: 'wrap',
    gap: '4px'
  },
  itemSelectionModifier: {
    fontSize: '12px',
    color: '#6b7280',
    backgroundColor: '#f3f4f6',
    padding: '2px 6px',
    borderRadius: '3px'
  },
  itemSelectionNotes: {
    fontSize: '12px',
    color: '#9ca3af',
    fontStyle: 'italic'
  },
  itemSelectionPrice: {
    fontSize: '16px',
    fontWeight: 'bold',
    color: '#1f2937'
  },
  noItemsText: {
    textAlign: 'center',
    color: '#9ca3af',
    padding: '40px',
    fontStyle: 'italic'
  },
  selectionSummary: {
    backgroundColor: '#f9fafb',
    padding: '15px',
    borderRadius: '6px',
    border: '1px solid #e5e7eb'
  },
  selectionSummaryRow: {
    display: 'flex',
    justifyContent: 'space-between',
    fontSize: '16px',
    fontWeight: 'bold',
    color: '#1f2937'
  },
  modalActions: {
    display: 'flex',
    gap: '15px',
    marginTop: '25px'
  },
  cancelButton: {
    flex: 1,
    padding: '12px',
    backgroundColor: '#6b7280',
    color: 'white',
    border: 'none',
    borderRadius: '6px',
    cursor: 'pointer',
    fontSize: '16px',
    fontWeight: 'bold'
  },
  submitButton: {
    flex: 1,
    padding: '12px',
    backgroundColor: '#008080',
    color: 'white',
    border: 'none',
    borderRadius: '6px',
    cursor: 'pointer',
    fontSize: '16px',
    fontWeight: 'bold'
  }
};

export default ItemSelectionModal;