// components/POS/CreateTabModal.jsx
import React, { useState } from 'react';
import BarcodeScanHandler from './BarcodeScanHandler';
import { supabase } from '../../supabaseClient';
import { logAction } from '../../helpers/posAudit';

const CreateTabModal = ({ 
  showModal, 
  onClose, 
  onCreateTab, 
  selectedBusinessId,
  authUser 
}) => {
  const [newTab, setNewTab] = useState({
    customer_name: '',
    customer_phone: '',
    customer_email: '',
    notes: '',
    tab_number: '',
    loyalty_customer_id: null
  });
  
  const [showQRInput, setShowQRInput] = useState(false);
  const [qrInputValue, setQrInputValue] = useState('');
  const [scanningFor, setScanningFor] = useState('customer');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const generateTabNumber = () => {
    const timestamp = Date.now().toString().slice(-6);
    return `TAB-${timestamp}`;
  };

  const handleBarcodeOrQRScan = (code) => {
    console.log('Barcode/QR scanned:', code);
    
    if (showQRInput) {
      if (scanningFor === 'customer') {
        handleCustomerQRScan(code);
      } else if (scanningFor === 'receipt') {
        handleReceiptQRScan(code);
      }
    }
  };

  const handleCustomerQRScan = async (qrData) => {
    if (!selectedBusinessId) return;

    try {
      console.log('Processing QR code data:', qrData);
      
      let customerData = null;
      
      // Try to parse as JSON first (loyalty customer QR)
      try {
        const parsed = JSON.parse(qrData);
        console.log('Parsed JSON QR data:', parsed);
        if (parsed.type === 'loyalty_customer' && parsed.customer_id) {
          const { data: loyaltyCustomer, error } = await supabase
            .from('pos_loyalty_accounts')
            .select('id, customer_name, customer_email, customer_phone, balance')
            .eq('id', parsed.customer_id)
            .eq('business_id', selectedBusinessId)
            .single();

          console.log('Loyalty customer lookup result:', loyaltyCustomer, error);

          if (loyaltyCustomer && !error) {
            customerData = {
              loyalty_customer_id: loyaltyCustomer.id,
              customer_name: loyaltyCustomer.customer_name,
              customer_phone: loyaltyCustomer.customer_phone || '',
              customer_email: loyaltyCustomer.customer_email || ''
            };
          }
        }
      } catch (jsonError) {
        console.log('Not valid JSON, trying other formats');
      }

      // Try as direct loyalty account ID (UUID format)
      if (!customerData && qrData.match(/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i)) {
        console.log('Trying as direct UUID:', qrData);
        const { data: loyaltyCustomer, error } = await supabase
          .from('pos_loyalty_accounts')
          .select('id, customer_name, customer_email, customer_phone, balance')
          .eq('id', qrData)
          .eq('business_id', selectedBusinessId)
          .single();

        console.log('Direct UUID lookup result:', loyaltyCustomer, error);

        if (loyaltyCustomer && !error) {
          customerData = {
            loyalty_customer_id: loyaltyCustomer.id,
            customer_name: loyaltyCustomer.customer_name,
            customer_phone: loyaltyCustomer.customer_phone || '',
            customer_email: loyaltyCustomer.customer_email || ''
          };
        } else {
          console.log('UUID not found in loyalty accounts, skipping');
          customerData = null;
        }
      }

      // Try as phone number lookup
      if (!customerData && qrData.match(/^\+?[\d\s\-\(\)]+$/)) {
        console.log('Trying as phone number:', qrData);
        const cleanPhone = qrData.replace(/\D/g, '');
        const { data: loyaltyCustomer, error } = await supabase
          .from('pos_loyalty_accounts')
          .select('id, customer_name, customer_email, customer_phone, balance')
          .eq('customer_phone', cleanPhone)
          .eq('business_id', selectedBusinessId)
          .single();

        console.log('Phone lookup result:', loyaltyCustomer, error);

        if (loyaltyCustomer && !error) {
          customerData = {
            loyalty_customer_id: loyaltyCustomer.id,
            customer_name: loyaltyCustomer.customer_name,
            customer_phone: loyaltyCustomer.customer_phone || '',
            customer_email: loyaltyCustomer.customer_email || ''
          };
        }
      }

      // Try searching by customer_name if it's just text
      if (!customerData && qrData.length > 2 && !qrData.match(/^[\d\-\+\s\(\)]+$/)) {
        console.log('Trying as customer name search:', qrData);
        const { data: loyaltyCustomers, error } = await supabase
          .from('pos_loyalty_accounts')
          .select('id, customer_name, customer_email, customer_phone, balance')
          .eq('business_id', selectedBusinessId)
          .ilike('customer_name', `%${qrData}%`)
          .limit(1);

        console.log('Name search result:', loyaltyCustomers, error);

        if (loyaltyCustomers && loyaltyCustomers.length > 0 && !error) {
          const loyaltyCustomer = loyaltyCustomers[0];
          customerData = {
            loyalty_customer_id: loyaltyCustomer.id,
            customer_name: loyaltyCustomer.customer_name,
            customer_phone: loyaltyCustomer.customer_phone || '',
            customer_email: loyaltyCustomer.customer_email || ''
          };
        }
      }

      if (customerData) {
        console.log('Found customer data:', customerData);
        setNewTab(prev => ({
          ...prev,
          ...customerData
        }));

        await logAction({
          action: 'customer_qr_scanned',
          context: 'CreateTabModal',
          metadata: {
            customer_id: customerData.loyalty_customer_id,
            customer_name: customerData.customer_name,
            scan_type: 'loyalty_customer',
            qr_data: qrData
          }
        });

        alert(`Customer found: ${customerData.customer_name}`);
      } else {
        console.log('No customer found for QR data:', qrData);
        const isUUID = qrData.match(/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i);
        const isPhone = qrData.match(/^\+?[\d\s\-\(\)]+$/);
        
        if (!isUUID && !isPhone && qrData.length > 2 && qrData.length < 50 && !qrData.includes('/')) {
          setNewTab(prev => ({
            ...prev,
            customer_name: qrData,
            loyalty_customer_id: null
          }));
          alert(`Using "${qrData}" as customer name. No matching loyalty account found.`);
        } else {
          setError('Customer not found in loyalty system. Please verify the QR code or enter information manually.');
        }
      }
    } catch (err) {
      console.error('Customer QR scan error:', err);
      setError('Failed to process customer QR code: ' + err.message);
    } finally {
      setShowQRInput(false);
      setQrInputValue('');
    }
  };

  const handleReceiptQRScan = async (qrData) => {
    if (!selectedBusinessId) return;

    try {
      let receiptId = null;
      
      if (qrData.includes('/receipt/')) {
        const urlParts = qrData.split('/receipt/');
        receiptId = urlParts[1]?.split('?')[0];
      } else if (qrData.match(/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i)) {
        receiptId = qrData;
      }

      if (receiptId) {
        const { data: receipt, error } = await supabase
          .from('pos_sales')
          .select(`
            *,
            pos_loyalty_accounts (
              id, customer_name, customer_email, customer_phone
            )
          `)
          .eq('id', receiptId)
          .eq('business_id', selectedBusinessId)
          .single();

        if (receipt && !error && receipt.pos_loyalty_accounts) {
          setNewTab(prev => ({
            ...prev,
            loyalty_customer_id: receipt.pos_loyalty_accounts.id,
            customer_name: receipt.pos_loyalty_accounts.customer_name,
            customer_phone: receipt.pos_loyalty_accounts.customer_phone || '',
            customer_email: receipt.pos_loyalty_accounts.customer_email || ''
          }));

          await logAction({
            action: 'receipt_qr_scanned_for_tab',
            context: 'CreateTabModal',
            metadata: {
              receipt_id: receiptId,
              customer_id: receipt.pos_loyalty_accounts.id,
              scan_type: 'receipt_lookup'
            }
          });

          alert(`Customer loaded from receipt: ${receipt.pos_loyalty_accounts.customer_name}`);
        } else {
          setError('Receipt not found or no customer associated with this receipt.');
        }
      } else {
        setError('Invalid receipt QR code format.');
      }
    } catch (err) {
      console.error('Receipt QR scan error:', err);
      setError('Failed to process receipt QR code: ' + err.message);
    } finally {
      setShowQRInput(false);
      setQrInputValue('');
    }
  };

  const handleCreateTab = async () => {
    if (!newTab.customer_name.trim() || !authUser || !selectedBusinessId) {
      setError('Customer name is required');
      return;
    }

    try {
      setLoading(true);
      setError(null);

      const tabNumber = newTab.tab_number.trim() || generateTabNumber();

      const tabData = {
        business_id: selectedBusinessId,
        tab_number: tabNumber,
        customer_name: newTab.customer_name.trim(),
        customer_phone: newTab.customer_phone.trim() || null,
        customer_email: newTab.customer_email.trim() || null,
        loyalty_customer_id: newTab.loyalty_customer_id || null,
        notes: newTab.notes.trim() || null,
        started_by: authUser.id,
        status: 'open',
        subtotal: 0,
        tax_amount: 0,
        total_amount: 0,
        amount_paid: 0,
        balance_remaining: 0,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      };

      await onCreateTab(tabData);

      // Reset form
      setNewTab({ 
        customer_name: '', 
        customer_phone: '', 
        customer_email: '', 
        notes: '', 
        tab_number: '', 
        loyalty_customer_id: null 
      });

    } catch (err) {
      console.error('Error creating tab:', err);
      setError('Failed to create tab: ' + err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleQRScanResult = (qrData) => {
    if (scanningFor === 'customer') {
      handleCustomerQRScan(qrData);
    } else if (scanningFor === 'receipt') {
      handleReceiptQRScan(qrData);
    }
  };

  if (!showModal) return null;

  return (
    <div style={styles.modal}>
      <div style={styles.modalContent}>
        <div style={styles.modalHeader}>
          <h3>Create New Tab</h3>
          <button
            style={styles.closeModalButton}
            onClick={onClose}
          >
            ×
          </button>
        </div>
        
        {error && <div style={styles.errorBanner}>{error}</div>}
        
        <div style={styles.form}>
          <div style={styles.qrScanSection}>
            <p style={styles.qrScanText}>Quick customer lookup:</p>
            <div style={styles.qrScanButtons}>
              <button
                style={styles.qrScanButton}
                onClick={() => {
                  setScanningFor('customer');
                  setShowQRInput(true);
                }}
              >
                📱 Scan Loyalty Card
              </button>
              <button
                style={styles.qrScanButton}
                onClick={() => {
                  setScanningFor('receipt');
                  setShowQRInput(true);
                }}
              >
                🧾 Scan Receipt
              </button>
            </div>
          </div>

          <div style={styles.formDivider}>
            <span>OR ENTER MANUALLY</span>
          </div>
          
          <div style={styles.formGroup}>
            <label style={styles.label}>Customer Name *</label>
            <input
              type="text"
              value={newTab.customer_name}
              onChange={(e) => setNewTab({...newTab, customer_name: e.target.value})}
              placeholder="Enter customer name"
              style={styles.input}
              autoFocus
            />
          </div>
          
          <div style={styles.formGroup}>
            <label style={styles.label}>Customer Phone</label>
            <input
              type="tel"
              value={newTab.customer_phone}
              onChange={(e) => setNewTab({...newTab, customer_phone: e.target.value})}
              placeholder="(555) 123-4567"
              style={styles.input}
            />
          </div>
          
          <div style={styles.formGroup}>
            <label style={styles.label}>Customer Email</label>
            <input
              type="email"
              value={newTab.customer_email}
              onChange={(e) => setNewTab({...newTab, customer_email: e.target.value})}
              placeholder="customer@example.com"
              style={styles.input}
            />
          </div>
          
          <div style={styles.formGroup}>
            <label style={styles.label}>Tab Number</label>
            <input
              type="text"
              value={newTab.tab_number}
              onChange={(e) => setNewTab({...newTab, tab_number: e.target.value})}
              placeholder="Leave blank for auto-generate"
              style={styles.input}
            />
          </div>
          
          <div style={styles.formGroup}>
            <label style={styles.label}>Notes</label>
            <textarea
              value={newTab.notes}
              onChange={(e) => setNewTab({...newTab, notes: e.target.value})}
              placeholder="Special instructions or notes..."
              style={styles.textarea}
              rows="3"
            />
          </div>

          {newTab.loyalty_customer_id && (
            <div style={styles.loyaltyInfo}>
              ⭐ Loyalty customer linked
            </div>
          )}
        </div>
        
        <div style={styles.modalActions}>
          <button
            style={styles.cancelButton}
            onClick={onClose}
          >
            Cancel
          </button>
          <button
            style={styles.submitButton}
            onClick={handleCreateTab}
            disabled={!newTab.customer_name.trim() || loading}
          >
            {loading ? 'Creating...' : 'Create Tab'}
          </button>
        </div>
      </div>

      {/* QR Input Modal */}
      {showQRInput && (
        <div style={styles.modal}>
          <div style={styles.modalContent}>
            <div style={styles.modalHeader}>
              <h3>
                {scanningFor === 'customer' ? 'Scan/Enter Customer Info' : 'Scan/Enter Receipt Code'}
              </h3>
              <button
                style={styles.closeModalButton}
                onClick={() => {
                  setShowQRInput(false);
                  setQrInputValue('');
                }}
              >
                ×
              </button>
            </div>
            
            <BarcodeScanHandler onScan={handleBarcodeOrQRScan} />
            
            <div style={styles.qrInputSection}>
              <p style={styles.qrInstructions}>
                {scanningFor === 'customer' 
                  ? 'Scan the customer\'s loyalty card barcode/QR code, or enter their information manually below:'
                  : 'Scan the receipt barcode/QR code, or enter the receipt ID manually below:'
                }
              </p>
              
              <div style={styles.formGroup}>
                <label style={styles.label}>
                  {scanningFor === 'customer' ? 'Customer ID, Phone, or Name:' : 'Receipt ID:'}
                </label>
                <input
                  type="text"
                  value={qrInputValue}
                  onChange={(e) => setQrInputValue(e.target.value)}
                  placeholder={scanningFor === 'customer' ? 'Enter customer ID, phone number, or name' : 'Enter receipt ID'}
                  style={styles.input}
                  autoFocus
                />
              </div>
              
              <div style={styles.modalActions}>
                <button
                  style={styles.cancelButton}
                  onClick={() => {
                    setShowQRInput(false);
                    setQrInputValue('');
                  }}
                >
                  Cancel
                </button>
                <button
                  style={styles.submitButton}
                  onClick={() => {
                    if (qrInputValue.trim()) {
                      handleQRScanResult(qrInputValue.trim());
                    }
                  }}
                  disabled={!qrInputValue.trim()}
                >
                  Look Up Customer
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

const styles = {
  modal: {
    position: 'fixed',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0,0,0,0.5)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 1000
  },
  modalContent: {
    backgroundColor: 'white',
    padding: '30px',
    borderRadius: '12px',
    maxWidth: '600px',
    width: '90%',
    maxHeight: '90vh',
    overflowY: 'auto'
  },
  modalHeader: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: '25px',
    paddingBottom: '15px',
    borderBottom: '2px solid #008080'
  },
  closeModalButton: {
    backgroundColor: 'transparent',
    border: 'none',
    fontSize: '24px',
    cursor: 'pointer',
    color: '#6b7280'
  },
  errorBanner: {
    backgroundColor: '#fee2e2',
    color: '#dc2626',
    padding: '15px',
    borderRadius: '6px',
    marginBottom: '20px'
  },
  form: {
    display: 'flex',
    flexDirection: 'column',
    gap: '20px'
  },
  qrScanSection: {
    backgroundColor: '#f0fdfa',
    padding: '20px',
    borderRadius: '8px',
    border: '2px solid #008080'
  },
  qrScanText: {
    margin: '0 0 15px 0',
    fontSize: '16px',
    fontWeight: 'bold',
    color: '#008080',
    textAlign: 'center'
  },
  qrScanButtons: {
    display: 'flex',
    gap: '10px',
    justifyContent: 'center'
  },
  qrScanButton: {
    padding: '10px 15px',
    backgroundColor: '#008080',
    color: 'white',
    border: 'none',
    borderRadius: '6px',
    cursor: 'pointer',
    fontSize: '14px',
    fontWeight: 'bold'
  },
  formDivider: {
    textAlign: 'center',
    position: 'relative',
    margin: '20px 0',
    color: '#6b7280',
    fontSize: '14px',
    fontWeight: 'bold'
  },
  formGroup: {
    display: 'flex',
    flexDirection: 'column'
  },
  label: {
    fontSize: '14px',
    fontWeight: 'bold',
    color: '#374151',
    marginBottom: '6px'
  },
  input: {
    padding: '12px',
    border: '2px solid #d1d5db',
    borderRadius: '6px',
    fontSize: '16px'
  },
  textarea: {
    padding: '12px',
    border: '2px solid #d1d5db',
    borderRadius: '6px',
    fontSize: '16px',
    fontFamily: 'inherit',
    resize: 'vertical'
  },
  loyaltyInfo: {
    backgroundColor: '#d1fae5',
    color: '#059669',
    padding: '10px',
    borderRadius: '6px',
    textAlign: 'center',
    fontWeight: 'bold'
  },
  qrInputSection: {
    marginTop: '20px',
    padding: '20px',
    backgroundColor: '#f9fafb',
    borderRadius: '8px',
    border: '1px solid #e5e7eb'
  },
  qrInstructions: {
    fontSize: '14px',
    marginBottom: '15px',
    color: '#6b7280'
  },
  modalActions: {
    display: 'flex',
    gap: '15px',
    marginTop: '25px'
  },
  cancelButton: {
    flex: 1,
    padding: '12px',
    backgroundColor: '#6b7280',
    color: 'white',
    border: 'none',
    borderRadius: '6px',
    cursor: 'pointer',
    fontSize: '16px',
    fontWeight: 'bold'
  },
  submitButton: {
    flex: 1,
    padding: '12px',
    backgroundColor: '#008080',
    color: 'white',
    border: 'none',
    borderRadius: '6px',
    cursor: 'pointer',
    fontSize: '16px',
    fontWeight: 'bold'
  }
};

export default CreateTabModal;