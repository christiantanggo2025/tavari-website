// components/POS/CustomerSelectionModal.jsx
import React, { useState } from 'react';
import BarcodeScanHandler from './BarcodeScanHandler';
import { supabase } from '../../supabaseClient';

const CustomerSelectionModal = ({
  showModal,
  onClose,
  onBackToItems,
  selectedItems,
  selectedPaymentTab,
  paymentCustomer,
  onCustomerSelected,
  onProceedToPayment,
  formatCurrency,
  selectedBusinessId
}) => {
  const [showQRInput, setShowQRInput] = useState(false);
  const [showQRManualInput, setShowQRManualInput] = useState(false);
  const [qrSearchValue, setQrSearchValue] = useState('');
  const [error, setError] = useState(null);

  const getBalanceDisplay = (balance) => {
    return `$${(Number(balance) || 0).toFixed(2)}`;
  };

  const handleBarcodeOrQRScan = (code) => {
    console.log('Barcode/QR scanned for customer selection:', code);
    
    if (showQRInput) {
      handleCustomerQRForPayment(code);
      setShowQRInput(false);
    }
  };

  const handleCustomerQRForPayment = async (qrData) => {
    if (!selectedBusinessId) return;

    try {
      console.log('Processing customer QR for payment:', qrData);
      
      let customerData = null;
      
      // Try to parse as JSON first (loyalty customer QR)
      try {
        const parsed = JSON.parse(qrData);
        if (parsed.type === 'loyalty_customer' && parsed.customer_id) {
          const { data: loyaltyCustomer, error } = await supabase
            .from('pos_loyalty_accounts')
            .select('id, customer_name, customer_email, customer_phone, balance')
            .eq('id', parsed.customer_id)
            .eq('business_id', selectedBusinessId)
            .single();

          if (loyaltyCustomer && !error) {
            customerData = loyaltyCustomer;
          }
        }
      } catch (jsonError) {
        console.log('Not valid JSON, trying other formats');
      }

      // Try as direct loyalty account ID (UUID format)
      if (!customerData && qrData.match(/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i)) {
        const { data: loyaltyCustomer, error } = await supabase
          .from('pos_loyalty_accounts')
          .select('id, customer_name, customer_email, customer_phone, balance')
          .eq('id', qrData)
          .eq('business_id', selectedBusinessId)
          .single();

        if (loyaltyCustomer && !error) {
          customerData = loyaltyCustomer;
        }
      }

      // Try as phone number
      if (!customerData && qrData.match(/^\+?[\d\s\-\(\)]+$/)) {
        const cleanPhone = qrData.replace(/\D/g, '');
        const { data: loyaltyCustomer, error } = await supabase
          .from('pos_loyalty_accounts')
          .select('id, customer_name, customer_email, customer_phone, balance')
          .eq('customer_phone', cleanPhone)
          .eq('business_id', selectedBusinessId)
          .single();

        if (loyaltyCustomer && !error) {
          customerData = loyaltyCustomer;
        }
      }

      // Try searching by customer_name if it's just text
      if (!customerData && qrData.length > 2 && !qrData.match(/^[\d\-\+\s\(\)]+$/)) {
        const { data: loyaltyCustomers, error } = await supabase
          .from('pos_loyalty_accounts')
          .select('id, customer_name, customer_email, customer_phone, balance')
          .eq('business_id', selectedBusinessId)
          .ilike('customer_name', `%${qrData}%`)
          .limit(1);

        if (loyaltyCustomers && loyaltyCustomers.length > 0 && !error) {
          customerData = loyaltyCustomers[0];
        }
      }

      if (customerData) {
        onCustomerSelected(customerData);
        console.log('Found payment customer:', customerData);
      } else {
        setError('Customer not found in loyalty system');
      }

    } catch (err) {
      console.error('Customer QR scan error:', err);
      setError('Failed to process customer QR code: ' + err.message);
    }
  };

  const handleManualQRSearch = async () => {
    if (!qrSearchValue.trim()) {
      setError('Please enter a QR code value');
      return;
    }

    await handleCustomerQRForPayment(qrSearchValue.trim());
    setShowQRManualInput(false);
    setQrSearchValue('');
  };

  if (!showModal) return null;

  return (
    <div style={styles.modal}>
      <div style={styles.modalContent}>
        <div style={styles.modalHeader}>
          <h3>Select Customer & Loyalty Account</h3>
          <button
            style={styles.closeModalButton}
            onClick={onClose}
          >
            ×
          </button>
        </div>

        {error && <div style={styles.errorBanner}>{error}</div>}

        <div style={styles.customerSelectionContent}>
          <div style={styles.paymentSummary}>
            <h4>Payment Summary</h4>
            <p>Items: {selectedItems.length}</p>
            <p>Subtotal: {formatCurrency(selectedItems.reduce((sum, item) => sum + (Number(item.total_price) || 0), 0))}</p>
          </div>

          <div style={styles.customerOptions}>
            <h4>Customer & Loyalty Options</h4>
            
            <div style={styles.customerOptionGroup}>
              <button
                style={{
                  ...styles.customerOptionButton,
                  ...(paymentCustomer && paymentCustomer.id === selectedPaymentTab.pos_loyalty_accounts?.id ? styles.selectedOptionButton : {})
                }}
                onClick={() => onCustomerSelected(selectedPaymentTab.pos_loyalty_accounts)}
              >
                📋 Use Tab's Customer ({selectedPaymentTab.customer_name})
                {selectedPaymentTab.pos_loyalty_accounts && (
                  <span style={styles.loyaltyIndicator}>
                    ⭐ Loyalty: {getBalanceDisplay(selectedPaymentTab.pos_loyalty_accounts.balance || 0)}
                  </span>
                )}
                {paymentCustomer && paymentCustomer.id === selectedPaymentTab.pos_loyalty_accounts?.id && (
                  <span style={styles.selectedIndicator}>✓ Selected</span>
                )}
              </button>
            </div>

            <div style={styles.customerOptionGroup}>
              <div style={styles.qrScanButtons}>
                <button
                  style={styles.qrScanButton}
                  onClick={() => setShowQRInput(true)}
                >
                  📱 Scan Loyalty QR
                </button>
                <button
                  style={styles.qrManualButton}
                  onClick={() => setShowQRManualInput(true)}
                >
                  ⌨️ Enter QR Manually
                </button>
              </div>
            </div>

            <div style={styles.customerOptionGroup}>
              <button
                style={{
                  ...styles.customerOptionButton,
                  ...(paymentCustomer === null ? styles.selectedOptionButton : {})
                }}
                onClick={() => onCustomerSelected(null)}
              >
                👤 No Loyalty Account (Cash Customer)
                {paymentCustomer === null && (
                  <span style={styles.selectedIndicator}>✓ Selected</span>
                )}
              </button>
            </div>

            {(paymentCustomer !== undefined) && (
              <div style={styles.selectedCustomerInfo}>
                <h4>Selected Customer:</h4>
                {paymentCustomer ? (
                  <>
                    <p><strong>{paymentCustomer.customer_name}</strong></p>
                    {paymentCustomer.customer_phone && <p>📞 {paymentCustomer.customer_phone}</p>}
                    {paymentCustomer.balance !== undefined && (
                      <p>💰 Balance: {getBalanceDisplay(paymentCustomer.balance)}</p>
                    )}
                  </>
                ) : (
                  <>
                    <p><strong>💵 Cash Customer</strong></p>
                    <p>No loyalty account - payment will be cash/card only</p>
                  </>
                )}
              </div>
            )}
          </div>
        </div>

        <div style={styles.modalActions}>
          <button
            style={styles.cancelButton}
            onClick={onBackToItems}
          >
            Back to Items
          </button>
          <button
            style={styles.submitButton}
            onClick={onProceedToPayment}
          >
            Continue to Payment
          </button>
        </div>
      </div>

      {/* QR Input Modal */}
      {showQRInput && (
        <div style={styles.modal}>
          <div style={styles.modalContent}>
            <div style={styles.modalHeader}>
              <h3>Scan Customer Loyalty QR</h3>
              <button
                style={styles.closeModalButton}
                onClick={() => setShowQRInput(false)}
              >
                ×
              </button>
            </div>
            
            <BarcodeScanHandler onScan={handleBarcodeOrQRScan} />
            
            <div style={styles.qrInputSection}>
              <p style={styles.qrInstructions}>
                Scan the customer's loyalty card QR code or barcode
              </p>
              
              <div style={styles.modalActions}>
                <button
                  style={styles.cancelButton}
                  onClick={() => setShowQRInput(false)}
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Manual QR Input Modal */}
      {showQRManualInput && (
        <div style={styles.modal}>
          <div style={styles.modalContent}>
            <div style={styles.modalHeader}>
              <h3>Enter QR Code Manually</h3>
              <button
                style={styles.closeModalButton}
                onClick={() => {
                  setShowQRManualInput(false);
                  setQrSearchValue('');
                }}
              >
                ×
              </button>
            </div>
            
            <div style={styles.form}>
              <div style={styles.formGroup}>
                <label style={styles.label}>QR Code Value:</label>
                <input
                  type="text"
                  value={qrSearchValue}
                  onChange={(e) => setQrSearchValue(e.target.value)}
                  placeholder="Paste or type the QR code data here..."
                  style={styles.input}
                  autoFocus
                />
                <p style={styles.qrInstructions}>
                  Enter the QR code data from a customer's loyalty card. This can be:
                  <br />• Customer UUID (e.g., 12345678-1234-1234-1234-123456789012)
                  <br />• Phone number (e.g., 5551234567)
                  <br />• Customer name
                  <br />• JSON loyalty data
                </p>
              </div>
            </div>
            
            <div style={styles.modalActions}>
              <button
                style={styles.cancelButton}
                onClick={() => {
                  setShowQRManualInput(false);
                  setQrSearchValue('');
                }}
              >
                Cancel
              </button>
              <button
                style={styles.submitButton}
                onClick={handleManualQRSearch}
                disabled={!qrSearchValue.trim()}
              >
                Look Up Customer
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

const styles = {
  modal: {
    position: 'fixed',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0,0,0,0.5)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 1000
  },
  modalContent: {
    backgroundColor: 'white',
    padding: '30px',
    borderRadius: '12px',
    maxWidth: '600px',
    width: '90%',
    maxHeight: '90vh',
    overflowY: 'auto'
  },
  modalHeader: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: '25px',
    paddingBottom: '15px',
    borderBottom: '2px solid #008080'
  },
  closeModalButton: {
    backgroundColor: 'transparent',
    border: 'none',
    fontSize: '24px',
    cursor: 'pointer',
    color: '#6b7280'
  },
  errorBanner: {
    backgroundColor: '#fee2e2',
    color: '#dc2626',
    padding: '15px',
    borderRadius: '6px',
    marginBottom: '20px'
  },
  customerSelectionContent: {
    display: 'flex',
    flexDirection: 'column',
    gap: '20px'
  },
  paymentSummary: {
    backgroundColor: '#f0fdfa',
    padding: '15px',
    borderRadius: '6px',
    border: '2px solid #008080'
  },
  customerOptions: {
    display: 'flex',
    flexDirection: 'column',
    gap: '15px'
  },
  customerOptionGroup: {
    display: 'flex',
    flexDirection: 'column',
    gap: '8px'
  },
  customerOptionButton: {
    padding: '12px 15px',
    backgroundColor: 'white',
    color: '#008080',
    border: '2px solid #008080',
    borderRadius: '6px',
    cursor: 'pointer',
    fontSize: '14px',
    fontWeight: 'bold',
    textAlign: 'left',
    display: 'flex',
    flexDirection: 'column',
    gap: '4px'
  },
  loyaltyIndicator: {
    fontSize: '12px',
    color: '#059669',
    fontWeight: 'normal'
  },
  qrScanButtons: {
    display: 'flex',
    gap: '10px',
    justifyContent: 'center'
  },
  qrScanButton: {
    flex: 1,
    padding: '10px 12px',
    backgroundColor: '#008080',
    color: 'white',
    border: 'none',
    borderRadius: '6px',
    cursor: 'pointer',
    fontSize: '14px',
    fontWeight: 'bold',
    whiteSpace: 'nowrap'
  },
  qrManualButton: {
    flex: 1,
    padding: '10px 12px',
    backgroundColor: '#6b7280',
    color: 'white',
    border: 'none',
    borderRadius: '6px',
    cursor: 'pointer',
    fontSize: '14px',
    fontWeight: 'bold',
    whiteSpace: 'nowrap'
  },
  selectedCustomerInfo: {
    backgroundColor: '#d1fae5',
    padding: '15px',
    borderRadius: '6px',
    border: '1px solid #059669'
  },
  selectedOptionButton: {
    backgroundColor: '#f0fdfa',
    borderColor: '#14b8a6',
    borderWidth: '3px'
  },
  selectedIndicator: {
    fontSize: '14px',
    color: '#059669',
    fontWeight: 'bold',
    marginLeft: 'auto'
  },
  qrInputSection: {
    marginTop: '20px',
    padding: '20px',
    backgroundColor: '#f9fafb',
    borderRadius: '8px',
    border: '1px solid #e5e7eb'
  },
  qrInstructions: {
    fontSize: '14px',
    marginBottom: '15px',
    color: '#6b7280'
  },
  form: {
    display: 'flex',
    flexDirection: 'column',
    gap: '20px'
  },
  formGroup: {
    display: 'flex',
    flexDirection: 'column'
  },
  label: {
    fontSize: '14px',
    fontWeight: 'bold',
    color: '#374151',
    marginBottom: '6px'
  },
  input: {
    padding: '12px',
    border: '2px solid #d1d5db',
    borderRadius: '6px',
    fontSize: '16px'
  },
  modalActions: {
    display: 'flex',
    gap: '15px',
    marginTop: '25px'
  },
  cancelButton: {
    flex: 1,
    padding: '12px',
    backgroundColor: '#6b7280',
    color: 'white',
    border: 'none',
    borderRadius: '6px',
    cursor: 'pointer',
    fontSize: '16px',
    fontWeight: 'bold'
  },
  submitButton: {
    flex: 1,
    padding: '12px',
    backgroundColor: '#008080',
    color: 'white',
    border: 'none',
    borderRadius: '6px',
    cursor: 'pointer',
    fontSize: '16px',
    fontWeight: 'bold'
  }
};

export default CustomerSelectionModal;