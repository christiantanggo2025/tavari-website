// helpers/Mail/CampaignSchedulerService.js - Step 101: Campaign Scheduling Service
import { supabase } from '../../supabaseClient';

class CampaignSchedulerService {
  constructor() {
    this.timezones = [
      'America/Toronto', 'America/Vancouver', 'America/Edmonton', 
      'America/Winnipeg', 'America/Halifax', 'America/St_Johns', 'UTC'
    ];
    
    this.recurringFrequencies = ['weekly', 'monthly', 'custom'];
    this.daysOfWeek = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'];
  }

  // Schedule a campaign for immediate or future sending
  async scheduleCampaign(campaignId, scheduleData) {
    try {
      const { type, scheduled_for, timezone, recurring_settings, optimization } = scheduleData;

      // Validate schedule data
      const validation = this.validateScheduleData(scheduleData);
      if (!validation.isValid) {
        return {
          success: false,
          error: validation.errors.join(', ')
        };
      }

      // Create schedule record
      const scheduleRecord = {
        id: `schedule_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        campaign_id: campaignId,
        schedule_type: type,
        timezone: timezone || 'America/Toronto',
        status: type === 'send_now' ? 'processing' : 'scheduled',
        created_at: new Date().toISOString()
      };

      if (type !== 'send_now') {
        scheduleRecord.scheduled_for = scheduled_for;
      }

      if (type === 'recurring' && recurring_settings) {
        scheduleRecord.recurring_settings = recurring_settings;
        scheduleRecord.next_send_times = this.calculateNextSendTimes(scheduled_for, recurring_settings, timezone);
      }

      if (optimization) {
        scheduleRecord.optimization_settings = optimization;
      }

      // Store schedule in database
      const { data, error } = await supabase
        .from('mail_campaign_schedules')
        .insert(scheduleRecord)
        .select()
        .single();

      if (error) throw error;

      // Update campaign status
      const campaignStatus = type === 'send_now' ? 'sending' : 'scheduled';
      const { error: campaignError } = await supabase
        .from('mail_campaigns')
        .update({ 
          status: campaignStatus,
          scheduled_for: type !== 'send_now' ? scheduled_for : null,
          updated_at: new Date().toISOString()
        })
        .eq('id', campaignId);

      if (campaignError) throw campaignError;

      // If send_now, trigger immediate processing
      if (type === 'send_now') {
        await this.triggerImmediateSend(campaignId);
      }

      return {
        success: true,
        schedule_id: scheduleRecord.id,
        schedule: data,
        message: type === 'send_now' ? 'Campaign queued for immediate sending' : 
                 type === 'send_later' ? 'Campaign scheduled successfully' :
                 'Recurring campaign scheduled successfully'
      };
    } catch (error) {
      console.error('Error scheduling campaign:', error);
      return {
        success: false,
        error: error.message
      };
    }
  }

  // Calculate next send times for recurring campaigns
  calculateNextSendTimes(startDateTime, recurringSettings, timezone) {
    const sendTimes = [];
    const startDate = new Date(startDateTime);
    const { frequency, interval = 1, daysOfWeek = [], endDate, maxSends = 52 } = recurringSettings;
    
    let currentDate = new Date(startDate);
    let sendCount = 0;
    const maxIterations = maxSends || 52; // Prevent infinite loops

    while (sendCount < maxIterations) {
      // Add current date to send times
      sendTimes.push(currentDate.toISOString());
      sendCount++;

      // Calculate next send date based on frequency
      if (frequency === 'weekly') {
        if (daysOfWeek.length > 0) {
          // Find next occurrence of selected days
          currentDate = this.getNextWeeklyOccurrence(currentDate, daysOfWeek);
        } else {
          // Default to weekly interval
          currentDate = new Date(currentDate.getTime() + (7 * 24 * 60 * 60 * 1000));
        }
      } else if (frequency === 'monthly') {
        // Same day next month
        currentDate = new Date(currentDate.getFullYear(), currentDate.getMonth() + interval, currentDate.getDate());
      } else if (frequency === 'custom') {
        // Custom interval in days
        currentDate = new Date(currentDate.getTime() + (interval * 24 * 60 * 60 * 1000));
      }

      // Check if we've reached the end date
      if (endDate && currentDate >= new Date(endDate)) {
        break;
      }

      // Prevent infinite loops and excessive future scheduling
      const oneYearFromNow = new Date(Date.now() + (365 * 24 * 60 * 60 * 1000));
      if (currentDate > oneYearFromNow) {
        break;
      }
    }

    return sendTimes;
  }

  // Get next occurrence of selected days of the week
  getNextWeeklyOccurrence(currentDate, daysOfWeek) {
    const dayNames = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
    const currentDay = currentDate.getDay();
    const currentDayName = dayNames[currentDay];
    
    // Find next selected day
    let daysToAdd = 1;
    for (let i = 1; i <= 7; i++) {
      const nextDayIndex = (currentDay + i) % 7;
      const nextDayName = dayNames[nextDayIndex];
      
      if (daysOfWeek.includes(nextDayName)) {
        daysToAdd = i;
        break;
      }
    }

    return new Date(currentDate.getTime() + (daysToAdd * 24 * 60 * 60 * 1000));
  }

  // Validate schedule data
  validateScheduleData(scheduleData) {
    const errors = [];
    const { type, scheduled_for, timezone, recurring_settings } = scheduleData;

    // Validate schedule type
    if (!['send_now', 'send_later', 'recurring'].includes(type)) {
      errors.push('Invalid schedule type');
    }

    // Validate timezone
    if (timezone && !this.timezones.includes(timezone)) {
      errors.push('Invalid timezone');
    }

    // Validate future scheduling
    if (type !== 'send_now') {
      if (!scheduled_for) {
        errors.push('Scheduled date/time is required');
      } else {
        const scheduleDate = new Date(scheduled_for);
        const now = new Date();
        
        if (scheduleDate <= now) {
          errors.push('Schedule time must be in the future');
        }

        const oneYearFromNow = new Date(now.getTime() + (365 * 24 * 60 * 60 * 1000));
        if (scheduleDate > oneYearFromNow) {
          errors.push('Schedule time cannot be more than 1 year in the future');
        }
      }
    }

    // Validate recurring settings
    if (type === 'recurring' && recurring_settings) {
      const { frequency, interval, daysOfWeek, endDate, maxSends } = recurring_settings;

      if (!this.recurringFrequencies.includes(frequency)) {
        errors.push('Invalid recurring frequency');
      }

      if (frequency === 'custom' && (!interval || interval < 1)) {
        errors.push('Custom interval must be at least 1 day');
      }

      if (frequency === 'weekly' && (!daysOfWeek || daysOfWeek.length === 0)) {
        errors.push('Weekly recurring campaigns must specify days of week');
      }

      if (daysOfWeek && daysOfWeek.some(day => !this.daysOfWeek.includes(day))) {
        errors.push('Invalid day of week specified');
      }

      if (endDate && scheduled_for) {
        const endDateTime = new Date(endDate);
        const startDateTime = new Date(scheduled_for);
        if (endDateTime <= startDateTime) {
          errors.push('End date must be after start date');
        }
      }

      if (!endDate && !maxSends) {
        errors.push('Recurring campaigns must specify either end date or maximum sends');
      }

      if (maxSends && (maxSends < 1 || maxSends > 100)) {
        errors.push('Maximum sends must be between 1 and 100');
      }
    }

    return {
      isValid: errors.length === 0,
      errors
    };
  }

  // Trigger immediate sending
  async triggerImmediateSend(campaignId) {
    try {
      // This would integrate with the existing email sending service
      // For now, we'll just update the campaign status
      const { error } = await supabase
        .from('mail_campaigns')
        .update({ 
          status: 'sending',
          send_started_at: new Date().toISOString()
        })
        .eq('id', campaignId);

      if (error) throw error;

      return { success: true };
    } catch (error) {
      console.error('Error triggering immediate send:', error);
      return { success: false, error: error.message };
    }
  }

  // Process scheduled campaigns (would be called by a cron job)
  async processScheduledCampaigns() {
    try {
      const now = new Date();
      const fiveMinutesFromNow = new Date(now.getTime() + (5 * 60 * 1000));

      // Find campaigns scheduled to send in the next 5 minutes
      const { data: scheduledCampaigns, error } = await supabase
        .from('mail_campaign_schedules')
        .select(`
          *,
          campaign:mail_campaigns(id, name, status)
        `)
        .eq('status', 'scheduled')
        .lte('scheduled_for', fiveMinutesFromNow.toISOString())
        .gte('scheduled_for', now.toISOString());

      if (error) throw error;

      const results = [];
      for (const schedule of scheduledCampaigns || []) {
        try {
          // Mark as processing
          await supabase
            .from('mail_campaign_schedules')
            .update({ status: 'processing', processed_at: new Date().toISOString() })
            .eq('id', schedule.id);

          // Trigger campaign send
          await this.triggerImmediateSend(schedule.campaign_id);

          // Mark as completed
          await supabase
            .from('mail_campaign_schedules')
            .update({ status: 'completed' })
            .eq('id', schedule.id);

          results.push({
            schedule_id: schedule.id,
            campaign_id: schedule.campaign_id,
            status: 'processed'
          });

          // Handle recurring campaigns
          if (schedule.schedule_type === 'recurring' && schedule.recurring_settings) {
            await this.scheduleNextRecurrence(schedule);
          }

        } catch (error) {
          console.error(`Error processing scheduled campaign ${schedule.id}:`, error);
          
          // Mark as failed
          await supabase
            .from('mail_campaign_schedules')
            .update({ 
              status: 'failed', 
              error_message: error.message,
              processed_at: new Date().toISOString()
            })
            .eq('id', schedule.id);

          results.push({
            schedule_id: schedule.id,
            campaign_id: schedule.campaign_id,
            status: 'failed',
            error: error.message
          });
        }
      }

      return {
        success: true,
        processed: results.length,
        results
      };
    } catch (error) {
      console.error('Error processing scheduled campaigns:', error);
      return {
        success: false,
        error: error.message
      };
    }
  }

  // Schedule next recurrence for recurring campaigns
  async scheduleNextRecurrence(schedule) {
    try {
      const { recurring_settings, next_send_times, campaign_id } = schedule;
      
      if (!next_send_times || next_send_times.length <= 1) {
        // No more sends scheduled
        return;
      }

      // Remove the first send time (just processed) and get the next one
      const remainingSendTimes = next_send_times.slice(1);
      const nextSendTime = remainingSendTimes[0];

      if (!nextSendTime) {
        return;
      }

      // Create new schedule record for next occurrence
      const nextSchedule = {
        id: `schedule_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        campaign_id: campaign_id,
        schedule_type: 'recurring',
        scheduled_for: nextSendTime,
        timezone: schedule.timezone,
        recurring_settings: recurring_settings,
        next_send_times: remainingSendTimes,
        status: 'scheduled',
        parent_schedule_id: schedule.id,
        created_at: new Date().toISOString()
      };

      const { error } = await supabase
        .from('mail_campaign_schedules')
        .insert(nextSchedule);

      if (error) throw error;

      return { success: true, next_schedule_id: nextSchedule.id };
    } catch (error) {
      console.error('Error scheduling next recurrence:', error);
      return { success: false, error: error.message };
    }
  }

  // Get send time recommendations based on audience data
  async getSendTimeRecommendations(businessId) {
    try {
      // This would analyze historical engagement data
      // For now, return industry best practices
      const recommendations = [
        {
          time: '10:00',
          day: 'tuesday',
          engagement_score: 92,
          reason: 'Highest open rates in your industry',
          data_points: 1500
        },
        {
          time: '14:00',
          day: 'thursday',
          engagement_score: 88,
          reason: 'Peak engagement time for your audience',
          data_points: 1200
        },
        {
          time: '09:00',
          day: 'wednesday',
          engagement_score: 85,
          reason: 'High click-through rates historically',
          data_points: 950
        }
      ];

      return {
        success: true,
        recommendations
      };
    } catch (error) {
      console.error('Error getting send time recommendations:', error);
      return {
        success: false,
        error: error.message
      };
    }
  }

  // Get scheduled campaigns for a business
  async getScheduledCampaigns(businessId) {
    try {
      const { data, error } = await supabase
        .from('mail_campaign_schedules')
        .select(`
          *,
          campaign:mail_campaigns!inner(id, name, subject_line, business_id)
        `)
        .eq('campaign.business_id', businessId)
        .in('status', ['scheduled', 'processing'])
        .order('scheduled_for', { ascending: true });

      if (error) throw error;

      return {
        success: true,
        schedules: data || []
      };
    } catch (error) {
      console.error('Error getting scheduled campaigns:', error);
      return {
        success: false,
        error: error.message
      };
    }
  }

  // Cancel a scheduled campaign
  async cancelScheduledCampaign(scheduleId) {
    try {
      const { error } = await supabase
        .from('mail_campaign_schedules')
        .update({ 
          status: 'cancelled',
          cancelled_at: new Date().toISOString()
        })
        .eq('id', scheduleId);

      if (error) throw error;

      return {
        success: true,
        message: 'Campaign schedule cancelled successfully'
      };
    } catch (error) {
      console.error('Error cancelling scheduled campaign:', error);
      return {
        success: false,
        error: error.message
      };
    }
  }

  // Update scheduled campaign
  async updateScheduledCampaign(scheduleId, updates) {
    try {
      const validation = this.validateScheduleData(updates);
      if (!validation.isValid) {
        return {
          success: false,
          error: validation.errors.join(', ')
        };
      }

      const { error } = await supabase
        .from('mail_campaign_schedules')
        .update({
          ...updates,
          updated_at: new Date().toISOString()
        })
        .eq('id', scheduleId);

      if (error) throw error;

      return {
        success: true,
        message: 'Campaign schedule updated successfully'
      };
    } catch (error) {
      console.error('Error updating scheduled campaign:', error);
      return {
        success: false,
        error: error.message
      };
    }
  }

  // Database setup for scheduling tables
  static async setupSchedulingTables() {
    try {
      // Create campaign schedules table
      await supabase.rpc('execute_sql', {
        query: `
          CREATE TABLE IF NOT EXISTS mail_campaign_schedules (
            id TEXT PRIMARY KEY,
            campaign_id UUID REFERENCES mail_campaigns(id) ON DELETE CASCADE,
            schedule_type TEXT NOT NULL CHECK (schedule_type IN ('send_now', 'send_later', 'recurring')),
            scheduled_for TIMESTAMP,
            timezone TEXT DEFAULT 'America/Toronto',
            recurring_settings JSONB,
            next_send_times TEXT[],
            optimization_settings JSONB,
            status TEXT DEFAULT 'scheduled' CHECK (status IN ('scheduled', 'processing', 'completed', 'failed', 'cancelled')),
            parent_schedule_id TEXT,
            error_message TEXT,
            processed_at TIMESTAMP,
            cancelled_at TIMESTAMP,
            created_at TIMESTAMP DEFAULT timezone('utc'::text, now()),
            updated_at TIMESTAMP DEFAULT timezone('utc'::text, now())
          );
        `
      });

      // Create indexes for performance
      await supabase.rpc('execute_sql', {
        query: `
          CREATE INDEX IF NOT EXISTS idx_campaign_schedules_campaign_id 
          ON mail_campaign_schedules(campaign_id);
          
          CREATE INDEX IF NOT EXISTS idx_campaign_schedules_scheduled_for 
          ON mail_campaign_schedules(scheduled_for);
          
          CREATE INDEX IF NOT EXISTS idx_campaign_schedules_status 
          ON mail_campaign_schedules(status);
          
          CREATE INDEX IF NOT EXISTS idx_campaign_schedules_type 
          ON mail_campaign_schedules(schedule_type);
        `
      });

      // Add RLS policy
      await supabase.rpc('execute_sql', {
        query: `
          ALTER TABLE mail_campaign_schedules ENABLE ROW LEVEL SECURITY;
          
          CREATE POLICY IF NOT EXISTS "Users can access schedules for their business campaigns" 
          ON mail_campaign_schedules
          FOR ALL USING (
            campaign_id IN (
              SELECT id FROM mail_campaigns 
              WHERE business_id IN (SELECT id FROM businesses WHERE id = auth.uid())
            )
          );
        `
      });

      console.log('Campaign scheduling tables created successfully');
      return { success: true };
    } catch (error) {
      console.error('Error setting up scheduling tables:', error);
      return { success: false, error: error.message };
    }
  }
}

export default new CampaignSchedulerService();