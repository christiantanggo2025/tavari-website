// CampaignBuilder.jsx - Enhanced with Steps 101-110 Features
import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { supabase } from '../../supabaseClient';
import { useBusiness } from '../../contexts/BusinessContext';

// Import existing components
import CampaignSettings from '../../components/Mail/CampaignSettings';
import BlockLibrary from '../../components/Mail/BlockLibrary';
import ContentEditor from '../../components/Mail/ContentEditor';
import EmailPreview from '../../components/Mail/EmailPreview';
import DraftsModal from '../../components/Mail/DraftsModal';
import ContactSelector from '../../components/Mail/ContactSelector';

// Import new components for steps 101-110
import CampaignScheduler from '../../components/Mail/CampaignScheduler';
import EmailClientTester from '../../components/Mail/EmailClientTester';
import ComplexLayoutTester from '../../components/Mail/ComplexLayoutTester';
import CampaignAnalyticsDashboard from '../../components/Mail/CampaignAnalyticsDashboard';

import { styles } from '../../styles/Mail/CampaignBuilder.styles';
import {
  FiSave, FiSend, FiEye, FiSmartphone, FiMonitor, FiFileText, FiDollarSign,
  FiClock, FiSettings, FiBarChart2, FiTestTube, FiLayers, FiTarget
} from 'react-icons/fi';

const CampaignBuilder = () => {
  const navigate = useNavigate();
  const { campaignId } = useParams();
  const { business } = useBusiness();
  const isEditing = !!campaignId;

  // Existing state
  const [campaign, setCampaign] = useState({
    name: '',
    subject_line: '',
    preheader_text: '',
    content_blocks: [],
    status: 'draft'
  });

  const [previewMode, setPreviewMode] = useState('desktop');
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState('');
  const [contacts, setContacts] = useState([]);
  const [selectedContacts, setSelectedContacts] = useState('all');
  const [customContactIds, setCustomContactIds] = useState([]);
  const [showContactSelector, setShowContactSelector] = useState(false);
  const [showDraftsModal, setShowDraftsModal] = useState(false);
  const [isMobile, setIsMobile] = useState(window.innerWidth <= 1024);

  // New state for steps 101-110
  const [showScheduler, setShowScheduler] = useState(false);
  const [showEmailClientTester, setShowEmailClientTester] = useState(false);
  const [showComplexLayoutTester, setShowComplexLayoutTester] = useState(false);
  const [showAnalyticsDashboard, setShowAnalyticsDashboard] = useState(false);
  const [campaignComplexity, setCampaignComplexity] = useState('simple');
  const [testResults, setTestResults] = useState({
    emailClients: null,
    complexLayouts: null,
    lastTested: null
  });

  // Billing integration state with fallback
  const [targetCount, setTargetCount] = useState(0);
  const [estimatedCost, setEstimatedCost] = useState(0);
  const [billingInfo, setBillingInfo] = useState(null);

  const businessId = business?.id;

  useEffect(() => {
    if (isEditing && campaignId && businessId) {
      loadCampaign();
    }
    if (businessId) {
      loadContacts();
      loadBillingInfo();
    }
  }, [campaignId, businessId]);

  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth <= 1024);
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  useEffect(() => {
    calculateTargetCountAndCost();
  }, [selectedContacts, customContactIds, contacts]);

  // Analyze campaign complexity for layout testing
  useEffect(() => {
    analyzeCampaignComplexity();
  }, [campaign.content_blocks]);

  const loadCampaign = async () => {
    try {
      const { data, error } = await supabase
        .from('mail_campaigns')
        .select('*')
        .eq('id', campaignId)
        .eq('business_id', businessId)
        .single();

      if (error) throw error;

      setCampaign({
        name: data.name || '',
        subject_line: data.subject_line || '',
        preheader_text: data.preheader_text || '',
        content_blocks: data.content_json || [],
        status: data.status || 'draft'
      });
    } catch (error) {
      console.error('Error loading campaign:', error);
      setMessage('Error loading campaign');
    }
  };

  const loadContacts = async () => {
    try {
      const { data, error } = await supabase
        .from('mail_contacts')
        .select('id, first_name, last_name, email, subscribed')
        .eq('business_id', businessId)
        .eq('subscribed', true)
        .order('first_name');

      if (error) throw error;
      setContacts(data || []);
    } catch (error) {
      console.error('Error loading contacts:', error);
    }
  };

  // Load billing info with fallback for missing RPC function
  const loadBillingInfo = async () => {
    try {
      // Try the RPC function first
      const { data, error } = await supabase
        .rpc('get_current_billing_period', { p_business_id: businessId });

      if (error) {
        console.log('RPC function not available, using fallback billing info');
        // Fallback: create mock billing info
        setBillingInfo({
          id: 'mock_billing',
          business_id: businessId,
          included_emails: 1000,
          emails_used: 0,
          billing_period_start: new Date().toISOString(),
          billing_period_end: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
          status: 'active'
        });
        return;
      }
      
      setBillingInfo(data[0] || {
        id: 'default_billing',
        business_id: businessId,
        included_emails: 1000,
        emails_used: 0,
        billing_period_start: new Date().toISOString(),
        billing_period_end: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
        status: 'active'
      });
    } catch (error) {
      console.error('Error loading billing info:', error);
      // Set default billing info
      setBillingInfo({
        id: 'error_fallback',
        business_id: businessId,
        included_emails: 1000,
        emails_used: 0,
        billing_period_start: new Date().toISOString(),
        billing_period_end: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
        status: 'active'
      });
    }
  };

  const calculateTargetCountAndCost = () => {
    let count = 0;
    
    if (selectedContacts === 'all') {
      count = contacts.filter(c => c.subscribed).length;
    } else if (selectedContacts === 'custom') {
      count = customContactIds.length;
    }

    setTargetCount(count);

    // Calculate cost based on current billing period
    if (billingInfo && count > 0) {
      const remainingIncluded = Math.max(0, billingInfo.included_emails - (billingInfo.emails_used || 0));
      const overageEmails = Math.max(0, count - remainingIncluded);
      const cost = overageEmails * 0.0025; // $0.0025 per email overage
      setEstimatedCost(cost);
    } else {
      setEstimatedCost(count * 0.0025);
    }
  };

  // Analyze campaign complexity for testing recommendations
  const analyzeCampaignComplexity = () => {
    const blocks = campaign.content_blocks;
    let complexity = 'simple';

    if (blocks.length === 0) {
      complexity = 'empty';
    } else if (blocks.length > 10) {
      complexity = 'complex';
    } else if (blocks.some(b => b.type === 'columns') || 
               blocks.filter(b => b.type === 'image').length > 3) {
      complexity = 'moderate';
    }

    setCampaignComplexity(complexity);
  };

  const handleInputChange = (field, value) => {
    setCampaign(prev => ({
      ...prev,
      [field]: value
    }));
    setMessage('');
  };

  const validateCampaign = () => {
    const errors = [];

    if (!campaign.name.trim()) {
      errors.push('Campaign name is required');
    }

    if (!campaign.subject_line.trim()) {
      errors.push('Subject line is required');
    }

    if (campaign.content_blocks.length === 0) {
      errors.push('Campaign must have at least one content block');
    }

    // Check if unsubscribe link exists
    const hasUnsubscribe = campaign.content_blocks.some(block =>
      (block.type === 'text' && block.content?.includes('{UnsubscribeLink}')) ||
      (block.type === 'button' && block.content?.url?.includes('unsubscribe'))
    );

    if (!hasUnsubscribe) {
      errors.push('Campaign must include an unsubscribe link for compliance');
    }

    return errors;
  };

  const generateEmailHTML = () => {
    const blockHTML = campaign.content_blocks.map(block => {
      switch (block.type) {
        case 'text':
          return `<p style="font-size: ${block.settings.fontSize}; color: ${block.settings.color}; text-align: ${block.settings.textAlign}; line-height: ${block.settings.lineHeight};">${block.content}</p>`;

        case 'heading':
          return `<${block.settings.level} style="font-size: ${block.settings.fontSize}; color: ${block.settings.color}; text-align: ${block.settings.textAlign}; font-weight: ${block.settings.fontWeight};">${block.content}</${block.settings.level}>`;

        case 'button':
          return `<div style="text-align: ${block.settings.textAlign}; margin: 20px 0;"><a href="${block.content.url}" style="background-color: ${block.settings.backgroundColor}; color: ${block.settings.color}; padding: ${block.settings.padding}; border-radius: ${block.settings.borderRadius}; text-decoration: none; display: inline-block;">${block.content.text}</a></div>`;

        case 'image':
          const imageHtml = `<img src="${block.content.src}" alt="${block.content.alt}" style="max-width: ${block.content.width}; width: ${block.content.width}; height: auto; border-radius: ${block.settings.borderRadius};" />`;
          const imageContent = block.content.url ? `<a href="${block.content.url}">${imageHtml}</a>` : imageHtml;
          return `<div style="text-align: ${block.content.alignment}; margin: ${block.settings.margin};">${imageContent}</div>`;

        case 'divider':
          return `<hr style="border: none; border-top: 1px ${block.content.style} ${block.content.color}; width: ${block.content.width}; margin: ${block.settings.margin};" />`;

        case 'spacer':
          return `<div style="height: ${block.content.height}; background-color: ${block.settings.backgroundColor};"></div>`;

        case 'social':
          const socialButtons = block.content.platforms
            .filter(platform => platform.enabled && platform.url)
            .map(platform => {
              const socialIcons = {
                facebook: '📘',
                twitter: '🦆',
                instagram: '📷',
                linkedin: '💼',
                youtube: '📺'
              };
              return `<a href="${platform.url}" style="display: inline-block; margin: 0 ${parseInt(block.settings.spacing)/2}px; text-decoration: none; font-size: ${block.settings.size};">${socialIcons[platform.name] || '🔗'}</a>`;
            }).join('');
          return `<div style="text-align: ${block.settings.alignment}; margin: 20px 0;">${socialButtons}</div>`;

        case 'columns':
          return `
            <table style="width: 100%; border-collapse: collapse;">
              <tr>
                <td style="width: 50%; padding-right: ${parseInt(block.settings.gap)/2}px; vertical-align: top;">
                  ${block.content.column1 || 'Left column content...'}
                </td>
                <td style="width: 50%; padding-left: ${parseInt(block.settings.gap)/2}px; vertical-align: top;">
                  ${block.content.column2 || 'Right column content...'}
                </td>
              </tr>
            </table>
          `;

        default:
          return '';
      }
    }).join('');

    return `
      <html>
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1">
        </head>
        <body style="margin: 0; padding: 20px; font-family: Arial, sans-serif; background-color: #f8f8f8;">
          <div style="max-width: 600px; margin: 0 auto; background-color: white; padding: 30px; border-radius: 8px;">
            ${blockHTML}
            <div style="margin-top: 40px; padding-top: 20px; border-top: 1px solid #eee; font-size: 12px; color: #999; text-align: center;">
              <p>You received this email because you subscribed to our mailing list.</p>
              <p><a href="{UnsubscribeLink}" style="color: #999;">Unsubscribe</a> | <a href="{UpdatePreferencesLink}" style="color: #999;">Update Preferences</a></p>
            </div>
          </div>
        </body>
      </html>
    `;
  };

  const handleSave = async () => {
    if (!businessId) {
      setMessage('No business selected');
      return;
    }

    setSaving(true);
    try {
      setMessage('');

      const campaignData = {
        business_id: businessId,
        name: campaign.name.trim(),
        subject_line: campaign.subject_line.trim(),
        preheader_text: campaign.preheader_text.trim(),
        content_json: campaign.content_blocks,
        content_html: generateEmailHTML(),
        status: campaign.status,
        total_recipients: targetCount,
        estimated_cost: estimatedCost,
        updated_at: new Date().toISOString()
      };

      let result;
      if (isEditing) {
        result = await supabase
          .from('mail_campaigns')
          .update(campaignData)
          .eq('id', campaignId)
          .select()
          .single();
      } else {
        result = await supabase
          .from('mail_campaigns')
          .insert(campaignData)
          .select()
          .single();
      }

      if (result.error) throw result.error;

      setMessage('Campaign saved successfully');

      if (!isEditing && result.data) {
        navigate(`/dashboard/mail/builder/${result.data.id}`);
      }

    } catch (error) {
      console.error('Error saving campaign:', error);
      setMessage('Error saving campaign: ' + error.message);
    } finally {
      setSaving(false);
    }
  };

  // Handle scheduling (Step 101)
  const handleScheduleCampaign = async (scheduleData) => {
    try {
      // For now, we'll simulate scheduling - in production this would use CampaignSchedulerService
      console.log('Scheduling campaign with data:', scheduleData);
      
      if (scheduleData.type === 'send_now') {
        setMessage('Campaign sent successfully!');
        navigate(`/dashboard/mail/sender/${campaignId}`);
      } else {
        setMessage(`Campaign scheduled successfully for ${scheduleData.scheduled_for}!`);
        setCampaign(prev => ({ ...prev, status: 'scheduled' }));
      }
    } catch (error) {
      console.error('Error scheduling campaign:', error);
      setMessage('Error scheduling campaign. Please try again.');
    }
  };

  const handleSend = () => {
    const errors = validateCampaign();
    if (errors.length > 0) {
      setMessage('Please fix these issues before sending:\n' + errors.join('\n'));
      return;
    }
    setShowScheduler(true);
  };

  // Handle test results (Steps 97, 100)
  const handleEmailClientTestComplete = (results) => {
    setTestResults(prev => ({
      ...prev,
      emailClients: results,
      lastTested: new Date().toISOString()
    }));
    setMessage('Email client testing completed. Check results for recommendations.');
  };

  const handleComplexLayoutTestComplete = (results) => {
    setTestResults(prev => ({
      ...prev,
      complexLayouts: results,
      lastTested: new Date().toISOString()
    }));
    setMessage('Layout complexity testing completed. Review recommendations for improvements.');
  };

  const handleSendCampaign = async (recipientCount) => {
    try {
      navigate(`/dashboard/mail/sender/${campaignId}?recipients=${selectedContacts}&count=${recipientCount}`);
    } catch (error) {
      console.error('Error sending campaign:', error);
      setMessage('Error preparing campaign for sending');
    }
  };

  // Get complexity indicator color
  const getComplexityColor = (complexity) => {
    switch (complexity) {
      case 'simple': return '#4caf50';
      case 'moderate': return '#ff9800';
      case 'complex': return '#f44336';
      default: return '#ccc';
    }
  };

  return (
    <div style={styles.container}>
      {/* Enhanced Header with New Features */}
      <div style={styles.header}>
        <h1 style={styles.title}>
          {isEditing ? 'Edit Campaign' : 'Create Campaign'}
          <span style={{
            fontSize: '12px',
            fontWeight: 'bold',
            color: 'white',
            backgroundColor: getComplexityColor(campaignComplexity),
            padding: '2px 8px',
            borderRadius: '12px',
            marginLeft: '10px',
            textTransform: 'uppercase',
          }}>
            {campaignComplexity}
          </span>
        </h1>
        <div style={styles.headerActions}>
          {/* NEW: Testing and Analytics Buttons */}
          <button
            style={{
              backgroundColor: 'white',
              color: '#666',
              border: '2px solid #ddd',
              borderRadius: '8px',
              padding: '10px 16px',
              fontSize: '14px',
              fontWeight: 'bold',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              gap: '6px',
              transition: 'all 0.2s ease',
            }}
            onClick={() => setShowEmailClientTester(true)}
            title="Test email client compatibility"
          >
            <FiTestTube style={styles.buttonIcon} />
            Client Test
          </button>
          <button
            style={{
              backgroundColor: 'white',
              color: '#666',
              border: '2px solid #ddd',
              borderRadius: '8px',
              padding: '10px 16px',
              fontSize: '14px',
              fontWeight: 'bold',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              gap: '6px',
              transition: 'all 0.2s ease',
            }}
            onClick={() => setShowComplexLayoutTester(true)}
            title="Test layout complexity"
          >
            <FiLayers style={styles.buttonIcon} />
            Layout Test
          </button>
          <button
            style={{
              backgroundColor: 'white',
              color: '#666',
              border: '2px solid #ddd',
              borderRadius: '8px',
              padding: '10px 16px',
              fontSize: '14px',
              fontWeight: 'bold',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              gap: '6px',
              transition: 'all 0.2s ease',
            }}
            onClick={() => setShowAnalyticsDashboard(true)}
            title="View campaign analytics"
          >
            <FiBarChart2 style={styles.buttonIcon} />
            Analytics
          </button>

          {/* Existing buttons */}
          <button
            style={styles.secondaryButton}
            onClick={() => setPreviewMode(previewMode === 'desktop' ? 'mobile' : 'desktop')}
          >
            {previewMode === 'desktop' ? <FiSmartphone /> : <FiMonitor />}
            {previewMode === 'desktop' ? 'Mobile' : 'Desktop'} Preview
          </button>
          <button
            style={styles.secondaryButton}
            onClick={handleSave}
            disabled={saving}
          >
            <FiSave style={styles.buttonIcon} />
            {saving ? 'Saving...' : 'Save'}
          </button>
          <button
            style={styles.secondaryButton}
            onClick={() => setShowDraftsModal(true)}
          >
            <FiFileText style={styles.buttonIcon} />
            Drafts
          </button>
          {/* NEW: Enhanced Send Button */}
          <button
            style={styles.primaryButton}
            onClick={handleSend}
          >
            <FiClock style={styles.buttonIcon} />
            Schedule & Send
          </button>
        </div>
      </div>

      {/* Message */}
      {message && (
        <div style={{
          ...styles.message,
          backgroundColor: message.includes('Error') || message.includes('fix') ? '#ffebee' : '#e8f5e8',
          color: message.includes('Error') || message.includes('fix') ? '#c62828' : '#2e7d32'
        }}>
          {message.split('\n').map((line, index) => (
            <div key={index}>{line}</div>
          ))}
        </div>
      )}

      {/* Billing Summary */}
      {billingInfo && (
        <div style={styles.billingSummary}>
          <div style={styles.billingInfo}>
            <div style={styles.billingItem}>
              <FiDollarSign style={styles.billingIcon} />
              <span>Target: {targetCount} emails</span>
            </div>
            <div style={styles.billingItem}>
              <span>Estimated cost: ${estimatedCost.toFixed(4)}</span>
            </div>
            <div style={styles.billingItem}>
              <span>
                Used: {billingInfo.emails_used || 0} / {billingInfo.included_emails} included
              </span>
            </div>
          </div>
        </div>
      )}

      {/* NEW: Test Results Summary */}
      {testResults.lastTested && (
        <div style={{
          backgroundColor: '#f0f8f8',
          border: '1px solid #b3d9e6',
          borderRadius: '8px',
          padding: '15px',
          marginBottom: '20px',
        }}>
          <h3 style={{
            fontSize: '16px',
            fontWeight: 'bold',
            color: '#333',
            marginBottom: '10px',
          }}>Recent Test Results</h3>
          <div style={{
            display: 'flex',
            gap: '20px',
            flexWrap: 'wrap',
          }}>
            {testResults.emailClients && (
              <div style={{
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
                fontSize: '14px',
                color: '#555',
              }}>
                <FiTestTube style={{ fontSize: '16px', color: 'teal' }} />
                <span>Email Clients: Last tested {new Date(testResults.lastTested).toLocaleDateString()}</span>
              </div>
            )}
            {testResults.complexLayouts && (
              <div style={{
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
                fontSize: '14px',
                color: '#555',
              }}>
                <FiLayers style={{ fontSize: '16px', color: 'teal' }} />
                <span>Layout Complexity: Analyzed {new Date(testResults.lastTested).toLocaleDateString()}</span>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Main Content */}
      <div style={isMobile ? styles.contentMobile : styles.content}>
        {/* Preview Panel - Show first on mobile */}
        {isMobile && (
          <div style={styles.previewPanel}>
            <EmailPreview
              campaign={campaign}
              business={business}
              previewMode={previewMode}
              onPreviewModeChange={setPreviewMode}
            />
          </div>
        )}

        {/* Editor Panel */}
        <div style={styles.editorPanel}>
          <CampaignSettings
            campaign={campaign}
            onInputChange={handleInputChange}
          />

          <BlockLibrary
            onAddBlock={(type) => setCampaign(prev => ({
              ...prev,
              content_blocks: [...prev.content_blocks, {
                id: Date.now().toString() + Math.random().toString(36).substr(2, 9),
                type,
                content: getDefaultContent(type),
                settings: getDefaultSettings(type)
              }]
            }))}
          />

          <ContentEditor
            campaign={campaign}
            setCampaign={setCampaign}
            businessId={businessId}
          />
        </div>

        {/* Preview Panel - Show second on desktop */}
        {!isMobile && (
          <div style={styles.previewPanel}>
            <EmailPreview
              campaign={campaign}
              business={business}
              previewMode={previewMode}
              onPreviewModeChange={setPreviewMode}
            />
          </div>
        )}
      </div>

      {/* NEW: Enhanced Modals for Steps 101-110 */}
      
      {/* Step 101: Campaign Scheduler */}
      {showScheduler && (
        <CampaignScheduler
          campaign={campaign}
          isOpen={showScheduler}
          onClose={() => setShowScheduler(false)}
          onSchedule={handleScheduleCampaign}
          businessTimezone={business?.timezone || 'America/Toronto'}
        />
      )}

      {/* Step 97: Email Client Tester */}
      {showEmailClientTester && (
        <EmailClientTester
          campaign={campaign}
          business={business}
          isOpen={showEmailClientTester}
          onClose={() => setShowEmailClientTester(false)}
          onTestComplete={handleEmailClientTestComplete}
        />
      )}

      {/* Step 100: Complex Layout Tester */}
      {showComplexLayoutTester && (
        <ComplexLayoutTester
          campaign={campaign}
          isOpen={showComplexLayoutTester}
          onClose={() => setShowComplexLayoutTester(false)}
          onLayoutUpdate={(updatedCampaign) => setCampaign(updatedCampaign)}
          onTestComplete={handleComplexLayoutTestComplete}
        />
      )}

      {/* Step 108: Analytics Dashboard */}
      {showAnalyticsDashboard && (
        <CampaignAnalyticsDashboard
          businessId={businessId}
          isOpen={showAnalyticsDashboard}
          onClose={() => setShowAnalyticsDashboard(false)}
        />
      )}

      {/* Existing Modals */}
      {showDraftsModal && (
        <DraftsModal
          isOpen={showDraftsModal}
          onClose={() => setShowDraftsModal(false)}
          businessId={businessId}
          navigate={navigate}
        />
      )}

      {showContactSelector && (
        <ContactSelector
          isOpen={showContactSelector}
          onClose={() => setShowContactSelector(false)}
          campaign={campaign}
          contacts={contacts}
          selectedContacts={selectedContacts}
          customContactIds={customContactIds}
          onSelectedContactsChange={setSelectedContacts}
          onCustomContactIdsChange={setCustomContactIds}
          onSend={handleSendCampaign}
        />
      )}
    </div>
  );
};

// Helper functions for default content and settings
const getDefaultContent = (type) => {
  switch (type) {
    case 'text':
      return 'Enter your text content here...';
    case 'heading':
      return 'Your Heading Here';
    case 'button':
      return { text: 'Click Here', url: '', style: 'primary' };
    case 'image':
      return { src: '', alt: '', width: '100%', alignment: 'center', url: '' };
    case 'divider':
      return { style: 'solid', color: '#ddd', width: '100%' };
    case 'social':
      return {
        platforms: [
          { name: 'facebook', url: '', enabled: true },
          { name: 'twitter', url: '', enabled: true },
          { name: 'instagram', url: '', enabled: true },
          { name: 'linkedin', url: '', enabled: false },
          { name: 'youtube', url: '', enabled: false }
        ],
        style: 'icons'
      };
    case 'spacer':
      return { height: '20px' };
    case 'columns':
      return {
        column1: 'Left column content...',
        column2: 'Right column content...'
      };
    default:
      return '';
  }
};

const getDefaultSettings = (type) => {
  switch (type) {
    case 'text':
      return { fontSize: '16px', color: '#333', textAlign: 'left', lineHeight: '1.6' };
    case 'heading':
      return { level: 'h2', fontSize: '24px', color: '#333', textAlign: 'left', fontWeight: 'bold' };
    case 'button':
      return { backgroundColor: 'teal', color: 'white', borderRadius: '6px', padding: '12px 24px', textAlign: 'center' };
    case 'image':
      return { borderRadius: '0px', margin: '15px 0' };
    case 'divider':
      return { margin: '20px 0' };
    case 'social':
      return { size: '32px', spacing: '10px', alignment: 'center' };
    case 'spacer':
      return { backgroundColor: 'transparent' };
    case 'columns':
      return { gap: '20px', alignment: 'top' };
    default:
      return {};
  }
};

export default CampaignBuilder;