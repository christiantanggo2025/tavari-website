// components/Mail/CampaignSettings.jsx
import React from 'react';
import { styles } from '../../styles/Mail/CampaignBuilder.styles';

const CampaignSettings = ({ campaign, onInputChange }) => {
  return (
    <div style={styles.campaignSettings}>
      <h2 style={styles.sectionTitle}>Campaign Settings</h2>
      <div style={styles.formGroup}>
        <label style={styles.label}>Campaign Name *</label>
        <input
          type="text"
          style={styles.input}
          value={campaign.name}
          onChange={(e) => onInputChange('name', e.target.value)}
          placeholder="e.g., Summer Special Offer"
        />
      </div>
      <div style={styles.formGroup}>
        <label style={styles.label}>Subject Line *</label>
        <input
          type="text"
          style={styles.input}
          value={campaign.subject_line}
          onChange={(e) => onInputChange('subject_line', e.target.value)}
          placeholder="e.g., 🌞 Summer Fun Awaits!"
        />
      </div>
      <div style={styles.formGroup}>
        <label style={styles.label}>Preheader Text</label>
        <input
          type="text"
          style={styles.input}
          value={campaign.preheader_text}
          onChange={(e) => onInputChange('preheader_text', e.target.value)}
          placeholder="Optional preview text that appears after subject line"
        />
      </div>
    </div>
  );
};

export default CampaignSettings;