// helpers/Mail/emailSendingService.js
import { supabase } from '../../supabaseClient';

class EmailSendingService {
  constructor() {
    this.sesConfig = {
      region: process.env.REACT_APP_AWS_REGION || 'us-east-1',
      accessKeyId: process.env.REACT_APP_AWS_ACCESS_KEY_ID,
      secretAccessKey: process.env.REACT_APP_AWS_SECRET_ACCESS_KEY
    };
    
    this.sendRateLimits = {
      default: 14, // emails per second (SES default)
      maxBurst: 100 // max burst capacity
    };
    
    this.retryConfig = {
      maxRetries: 3,
      baseDelay: 1000, // 1 second base delay
      maxDelay: 30000 // 30 seconds max delay
    };
  }

  // Step 114: Initialize AWS SES configuration
  async initializeSES() {
    try {
      // This would typically be done server-side
      // For now, we'll simulate the configuration
      console.log('Initializing AWS SES configuration...');
      
      // In production, this would be handled by your backend
      // with proper AWS SDK integration
      return {
        success: true,
        region: this.sesConfig.region,
        configured: true
      };
    } catch (error) {
      console.error('Error initializing SES:', error);
      throw new Error('Failed to initialize email service');
    }
  }

  // Step 115: Domain verification workflow
  async addDomainForVerification(businessId, domain) {
    try {
      // Check if domain already exists
      const { data: existingDomain } = await supabase
        .from('mail_domains')
        .select('*')
        .eq('business_id', businessId)
        .eq('domain', domain)
        .single();

      if (existingDomain) {
        throw new Error('Domain already exists for this business');
      }

      // Generate verification token
      const verificationToken = this.generateVerificationToken();
      
      // In production, this would make AWS SES API call
      const dnsRecords = this.generateDNSRecords(domain, verificationToken);

      // Store domain in database
      const { data, error } = await supabase
        .from('mail_domains')
        .insert({
          business_id: businessId,
          domain: domain,
          verification_token: verificationToken,
          spf_record: dnsRecords.spf,
          dmarc_record: dnsRecords.dmarc,
          dkim_tokens: dnsRecords.dkim,
          ses_verification_status: 'pending'
        })
        .select()
        .single();

      if (error) throw error;

      return {
        domain: data,
        dnsRecords: dnsRecords,
        instructions: this.getDNSInstructions(domain, dnsRecords)
      };
    } catch (error) {
      console.error('Error adding domain:', error);
      throw error;
    }
  }

  // Step 116: Check domain verification status
  async checkDomainVerification(businessId, domainId) {
    try {
      // In production, this would check with AWS SES API
      // For now, we'll simulate the check
      
      const { data: domain, error } = await supabase
        .from('mail_domains')
        .select('*')
        .eq('id', domainId)
        .eq('business_id', businessId)
        .single();

      if (error) throw error;

      // Simulate verification check (in production, call AWS SES)
      const verificationResult = await this.simulateVerificationCheck(domain);

      // Update domain status
      if (verificationResult.verified !== domain.verified) {
        const { error: updateError } = await supabase
          .from('mail_domains')
          .update({
            verified: verificationResult.verified,
            ses_verification_status: verificationResult.status,
            verified_at: verificationResult.verified ? new Date().toISOString() : null
          })
          .eq('id', domainId);

        if (updateError) throw updateError;
      }

      return verificationResult;
    } catch (error) {
      console.error('Error checking domain verification:', error);
      throw error;
    }
  }

  // Step 121: Queue campaign for sending
  async queueCampaignForSending(campaignId, contactIds = null) {
    try {
      // Get campaign details
      const { data: campaign, error: campaignError } = await supabase
        .from('mail_campaigns')
        .select('*, business_id')
        .eq('id', campaignId)
        .single();

      if (campaignError) throw campaignError;

      // Get contacts to send to
      let query = supabase
        .from('mail_contacts')
        .select('id, email, first_name, last_name, subscribed')
        .eq('business_id', campaign.business_id)
        .eq('subscribed', true);

      if (contactIds && contactIds.length > 0) {
        query = query.in('id', contactIds);
      }

      const { data: contacts, error: contactsError } = await query;
      if (contactsError) throw contactsError;

      // Filter out suppressed emails
      const validContacts = [];
      for (const contact of contacts) {
        const suppressed = await this.isEmailSuppressed(campaign.business_id, contact.email);
        if (!suppressed) {
          validContacts.push(contact);
        }
      }

      // Queue each contact for sending
      const queueItems = validContacts.map(contact => ({
        campaign_id: campaignId,
        contact_id: contact.id,
        email_address: contact.email,
        priority: 5, // Normal priority
        scheduled_for: new Date().toISOString()
      }));

      const { data: queuedItems, error: queueError } = await supabase
        .from('mail_sending_queue')
        .insert(queueItems)
        .select();

      if (queueError) throw queueError;

      // Update campaign status
      await supabase
        .from('mail_campaigns')
        .update({
          status: 'sending',
          total_recipients: validContacts.length
        })
        .eq('id', campaignId);

      return {
        queued: queuedItems.length,
        suppressed: contacts.length - validContacts.length,
        queueItems: queuedItems
      };
    } catch (error) {
      console.error('Error queueing campaign:', error);
      throw error;
    }
  }

  // Step 122: Process sending queue with retry logic
  async processSendingQueue(batchSize = 10) {
    try {
      // Get next batch of queued emails
      const { data: queueItems, error } = await supabase
        .from('mail_sending_queue')
        .select(`
          *,
          campaign:mail_campaigns(name, subject_line, content_html, business_id),
          contact:mail_contacts(first_name, last_name, email)
        `)
        .eq('status', 'queued')
        .lte('scheduled_for', new Date().toISOString())
        .limit(batchSize)
        .order('created_at');

      if (error) throw error;
      if (!queueItems || queueItems.length === 0) {
        return { processed: 0, sent: 0, failed: 0 };
      }

      let sent = 0;
      let failed = 0;

      // Process each email
      for (const item of queueItems) {
        try {
          // Mark as processing
          await supabase
            .from('mail_sending_queue')
            .update({ status: 'processing', processed_at: new Date().toISOString() })
            .eq('id', item.id);

          // Send the email
          const sendResult = await this.sendSingleEmail(item);
          
          if (sendResult.success) {
            // Mark as sent and create send record
            await this.recordSuccessfulSend(item, sendResult);
            sent++;
          } else {
            // Handle send failure
            await this.handleSendFailure(item, sendResult.error);
            failed++;
          }
        } catch (error) {
          console.error(`Error processing queue item ${item.id}:`, error);
          await this.handleSendFailure(item, error.message);
          failed++;
        }
      }

      return { processed: queueItems.length, sent, failed };
    } catch (error) {
      console.error('Error processing sending queue:', error);
      throw error;
    }
  }

  // Step 114: Send single email via SES
  async sendSingleEmail(queueItem) {
    try {
      const { campaign, contact } = queueItem;
      
      // Prepare email content with personalization
      const personalizedContent = this.personalizeEmailContent(
        campaign.content_html,
        contact,
        campaign.business_id
      );

      // In production, this would use AWS SES SDK
      // For now, we'll simulate the sending
      const sesResult = await this.simulateSESSend({
        to: contact.email,
        subject: campaign.subject_line,
        html: personalizedContent,
        from: await this.getFromAddress(campaign.business_id)
      });

      return {
        success: true,
        messageId: sesResult.MessageId,
        timestamp: new Date().toISOString()
      };
    } catch (error) {
      return {
        success: false,
        error: error.message,
        timestamp: new Date().toISOString()
      };
    }
  }

  // Step 119: Handle bounce notifications
  async processBounceNotification(notification) {
    try {
      const bounce = notification.bounce;
      const mail = notification.mail;

      for (const bouncedRecipient of bounce.bouncedRecipients) {
        // Find the original send record
        const { data: sendRecord } = await supabase
          .from('mail_campaign_sends')
          .select('*, campaign:mail_campaigns(business_id)')
          .eq('ses_message_id', mail.messageId)
          .eq('email_address', bouncedRecipient.emailAddress)
          .single();

        if (sendRecord) {
          // Record the bounce
          await supabase.from('mail_bounces').insert({
            business_id: sendRecord.campaign.business_id,
            contact_id: sendRecord.contact_id,
            campaign_id: sendRecord.campaign_id,
            campaign_send_id: sendRecord.id,
            email_address: bouncedRecipient.emailAddress,
            bounce_type: bounce.bounceType.toLowerCase(),
            bounce_subtype: bounce.bounceSubType?.toLowerCase(),
            bounce_reason: bouncedRecipient.diagnosticCode || bounce.bounceSubType,
            ses_notification_id: notification.notificationId,
            raw_notification: notification
          });

          // Update send record status
          await supabase
            .from('mail_campaign_sends')
            .update({ status: 'bounced' })
            .eq('id', sendRecord.id);
        }
      }

      return { success: true, processed: bounce.bouncedRecipients.length };
    } catch (error) {
      console.error('Error processing bounce notification:', error);
      throw error;
    }
  }

  // Helper methods
  async isEmailSuppressed(businessId, email) {
    try {
      const { data, error } = await supabase
        .rpc('is_email_suppressed', {
          p_business_id: businessId,
          p_email: email
        });

      if (error) throw error;
      return data;
    } catch (error) {
      console.error('Error checking email suppression:', error);
      return false; // Default to not suppressed if check fails
    }
  }

  personalizeEmailContent(htmlContent, contact, businessId) {
    return htmlContent
      .replace(/\{FirstName\}/g, contact.first_name || '')
      .replace(/\{LastName\}/g, contact.last_name || '')
      .replace(/\{Email\}/g, contact.email || '')
      .replace(/\{UnsubscribeLink\}/g, `${process.env.REACT_APP_BASE_URL}/unsubscribe?token=${this.generateUnsubscribeToken(contact.id, businessId)}`)
      .replace(/\{UpdatePreferencesLink\}/g, `${process.env.REACT_APP_BASE_URL}/preferences?token=${this.generateUnsubscribeToken(contact.id, businessId)}`);
  }

  async getFromAddress(businessId) {
    try {
      const { data: settings } = await supabase
        .from('mail_settings')
        .select('from_email, from_name')
        .eq('business_id', businessId)
        .single();

      return settings ? `${settings.from_name} <${settings.from_email}>` : 'noreply@example.com';
    } catch (error) {
      return 'noreply@example.com';
    }
  }

  generateVerificationToken() {
    return Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
  }

  generateUnsubscribeToken(contactId, businessId) {
    // In production, this would be a secure JWT or encrypted token
    return Buffer.from(`${contactId}:${businessId}:${Date.now()}`).toString('base64');
  }

  generateDNSRecords(domain, verificationToken) {
    return {
      spf: `"v=spf1 include:amazonses.com ~all"`,
      dmarc: `"v=DMARC1; p=quarantine; rua=mailto:dmarc@${domain}; ruf=mailto:dmarc@${domain}; fo=1"`,
      dkim: [
        `${verificationToken}._domainkey.${domain}`,
        `${verificationToken}2._domainkey.${domain}`,
        `${verificationToken}3._domainkey.${domain}`
      ]
    };
  }

  getDNSInstructions(domain, records) {
    return {
      spf: {
        type: 'TXT',
        name: domain,
        value: records.spf,
        description: 'Add this SPF record to authorize Amazon SES to send emails for your domain'
      },
      dmarc: {
        type: 'TXT',
        name: `_dmarc.${domain}`,
        value: records.dmarc,
        description: 'Add this DMARC record to improve email deliverability and security'
      },
      dkim: records.dkim.map((token, index) => ({
        type: 'CNAME',
        name: token,
        value: `${token}.dkim.amazonses.com`,
        description: `DKIM record ${index + 1} for email authentication`
      }))
    };
  }

  async simulateVerificationCheck(domain) {
    // Simulate verification check - in production, this would call AWS SES API
    const isVerified = Math.random() > 0.3; // 70% chance of being verified
    
    return {
      verified: isVerified,
      status: isVerified ? 'success' : 'pending',
      dkimStatus: isVerified ? 'verified' : 'pending',
      spfStatus: isVerified ? 'verified' : 'pending',
      dmarcStatus: isVerified ? 'verified' : 'pending'
    };
  }

  async simulateSESSend(emailData) {
    // Simulate SES send - in production, this would use AWS SES SDK
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        if (Math.random() > 0.05) { // 95% success rate
          resolve({
            MessageId: `sim-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
            ResponseMetadata: {
              RequestId: Math.random().toString(36).substr(2, 9)
            }
          });
        } else {
          reject(new Error('Simulated send failure'));
        }
      }, 100); // Simulate network delay
    });
  }

  async recordSuccessfulSend(queueItem, sendResult) {
    try {
      // Create send record
      await supabase.from('mail_campaign_sends').insert({
        campaign_id: queueItem.campaign_id,
        contact_id: queueItem.contact_id,
        email_address: queueItem.email_address,
        status: 'sent',
        sent_at: sendResult.timestamp,
        ses_message_id: sendResult.messageId
      });

      // Remove from queue
      await supabase
        .from('mail_sending_queue')
        .update({ status: 'sent', processed_at: new Date().toISOString() })
        .eq('id', queueItem.id);

      // Update campaign stats
      await supabase.rpc('increment_campaign_sent_count', {
        campaign_id: queueItem.campaign_id
      });
    } catch (error) {
      console.error('Error recording successful send:', error);
    }
  }

  async handleSendFailure(queueItem, errorMessage) {
    try {
      const retryCount = (queueItem.retry_count || 0) + 1;
      
      if (retryCount <= this.retryConfig.maxRetries) {
        // Schedule retry with exponential backoff
        const delayMs = Math.min(
          this.retryConfig.baseDelay * Math.pow(2, retryCount - 1),
          this.retryConfig.maxDelay
        );
        
        const retryAt = new Date(Date.now() + delayMs);
        
        await supabase
          .from('mail_sending_queue')
          .update({
            status: 'queued',
            retry_count: retryCount,
            error_message: errorMessage,
            scheduled_for: retryAt.toISOString()
          })
          .eq('id', queueItem.id);
      } else {
        // Max retries exceeded, mark as failed
        await supabase
          .from('mail_sending_queue')
          .update({
            status: 'failed',
            error_message: errorMessage,
            processed_at: new Date().toISOString()
          })
          .eq('id', queueItem.id);

        // Create failed send record
        await supabase.from('mail_campaign_sends').insert({
          campaign_id: queueItem.campaign_id,
          contact_id: queueItem.contact_id,
          email_address: queueItem.email_address,
          status: 'failed',
          error_message: errorMessage,
          retry_count: retryCount
        });
      }
    } catch (error) {
      console.error('Error handling send failure:', error);
    }
  }
}

export default new EmailSendingService();