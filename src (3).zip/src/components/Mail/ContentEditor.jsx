// components/Mail/ContentEditor.jsx
import React, { useState } from 'react';
import { styles } from '../../styles/Mail/CampaignBuilder.styles';
import { 
  FiMove, FiEdit3, FiTrash2, FiCopy, FiType, FiImage, 
  FiLink, FiMinus, FiShare2, FiSettings, FiColumns, FiPlus
} from 'react-icons/fi';

const ContentEditor = ({ contentBlocks, onChange, businessId }) => {
  const [activeBlock, setActiveBlock] = useState(null);

  const getDefaultContent = (type) => {
    switch (type) {
      case 'text':
        return 'Click to edit this text...';
      case 'heading':
        return 'Your Heading Here';
      case 'button':
        return { text: 'Click Here', url: '' };
      case 'image':
        return { src: '', alt: '', width: '100%', alignment: 'center', url: '' };
      case 'divider':
        return { style: 'solid', color: '#ddd', width: '100%' };
      case 'social':
        return { 
          platforms: [
            { name: 'facebook', enabled: false, url: '' },
            { name: 'twitter', enabled: false, url: '' },
            { name: 'instagram', enabled: false, url: '' },
            { name: 'linkedin', enabled: false, url: '' },
            { name: 'youtube', enabled: false, url: '' },
            { name: 'website', enabled: false, url: '' }
          ]
        };
      case 'spacer':
        return { height: '20px' };
      case 'columns':
        return { column1: 'Left column content...', column2: 'Right column content...' };
      default:
        return '';
    }
  };

  const getDefaultSettings = (type) => {
    switch (type) {
      case 'text':
        return { 
          fontSize: '14px', 
          color: '#333', 
          textAlign: 'left', 
          lineHeight: '1.6' 
        };
      case 'heading':
        return { 
          level: 'h2', 
          fontSize: '24px', 
          color: '#333', 
          textAlign: 'left', 
          fontWeight: 'bold' 
        };
      case 'button':
        return { 
          backgroundColor: 'teal', 
          color: 'white', 
          padding: '12px 24px', 
          borderRadius: '6px', 
          textAlign: 'center' 
        };
      case 'image':
        return { 
          borderRadius: '0px', 
          margin: '10px 0' 
        };
      case 'divider':
        return { 
          margin: '20px 0' 
        };
      case 'social':
        return { 
          size: '32px', 
          spacing: '10px', 
          alignment: 'center' 
        };
      case 'spacer':
        return { 
          backgroundColor: 'transparent' 
        };
      case 'columns':
        return { 
          gap: '20px' 
        };
      default:
        return {};
    }
  };

  const updateBlock = (blockId, field, value) => {
    const updatedBlocks = contentBlocks.map(block => {
      if (block.id === blockId) {
        if (field.startsWith('settings.')) {
          const settingField = field.replace('settings.', '');
          return {
            ...block,
            settings: { ...block.settings, [settingField]: value }
          };
        } else if (field.startsWith('content.')) {
          const contentField = field.replace('content.', '');
          return {
            ...block,
            content: { ...block.content, [contentField]: value }
          };
        } else {
          return { ...block, [field]: value };
        }
      }
      return block;
    });
    onChange(updatedBlocks);
  };

  const deleteBlock = (blockId) => {
    const updatedBlocks = contentBlocks.filter(block => block.id !== blockId);
    onChange(updatedBlocks);
    setActiveBlock(null);
  };

  const duplicateBlock = (blockId) => {
    const blockToDuplicate = contentBlocks.find(block => block.id === blockId);
    if (blockToDuplicate) {
      const newBlock = {
        ...blockToDuplicate,
        id: Date.now().toString()
      };
      const blockIndex = contentBlocks.findIndex(block => block.id === blockId);
      const updatedBlocks = [
        ...contentBlocks.slice(0, blockIndex + 1),
        newBlock,
        ...contentBlocks.slice(blockIndex + 1)
      ];
      onChange(updatedBlocks);
    }
  };

  const moveBlock = (fromIndex, toIndex) => {
    const updatedBlocks = [...contentBlocks];
    const [removed] = updatedBlocks.splice(fromIndex, 1);
    updatedBlocks.splice(toIndex, 0, removed);
    onChange(updatedBlocks);
  };

  const renderBlockEditor = (block) => {
    switch (block.type) {
      case 'text':
        return (
          <div style={styles.blockContent}>
            <textarea
              style={styles.textarea}
              value={block.content}
              onChange={(e) => updateBlock(block.id, 'content', e.target.value)}
              placeholder="Enter your text content..."
              rows="4"
            />
            <div style={styles.textControls}>
              <select
                style={styles.select}
                value={block.settings.fontSize}
                onChange={(e) => updateBlock(block.id, 'settings.fontSize', e.target.value)}
              >
                <option value="12px">12px</option>
                <option value="14px">14px</option>
                <option value="16px">16px</option>
                <option value="18px">18px</option>
                <option value="20px">20px</option>
              </select>
              <div style={styles.alignmentButtons}>
                {['left', 'center', 'right'].map(align => (
                  <button
                    key={align}
                    style={{
                      ...styles.alignmentButton,
                      ...(block.settings.textAlign === align ? styles.activeAlignment : {})
                    }}
                    onClick={() => updateBlock(block.id, 'settings.textAlign', align)}
                  >
                    {align}
                  </button>
                ))}
              </div>
            </div>
          </div>
        );

      case 'heading':
        return (
          <div style={styles.blockContent}>
            <input
              type="text"
              style={styles.input}
              value={block.content}
              onChange={(e) => updateBlock(block.id, 'content', e.target.value)}
              placeholder="Enter heading text..."
            />
            <div style={styles.formRow}>
              <select
                style={styles.select}
                value={block.settings.level}
                onChange={(e) => updateBlock(block.id, 'settings.level', e.target.value)}
              >
                <option value="h1">H1</option>
                <option value="h2">H2</option>
                <option value="h3">H3</option>
                <option value="h4">H4</option>
              </select>
              <div style={styles.alignmentButtons}>
                {['left', 'center', 'right'].map(align => (
                  <button
                    key={align}
                    style={{
                      ...styles.alignmentButton,
                      ...(block.settings.textAlign === align ? styles.activeAlignment : {})
                    }}
                    onClick={() => updateBlock(block.id, 'settings.textAlign', align)}
                  >
                    {align}
                  </button>
                ))}
              </div>
            </div>
          </div>
        );

      case 'button':
        return (
          <div style={styles.blockContent}>
            <div style={styles.formGroup}>
              <label style={styles.label}>Button Text</label>
              <input
                type="text"
                style={styles.input}
                value={block.content.text}
                onChange={(e) => updateBlock(block.id, 'content.text', e.target.value)}
                placeholder="Button text..."
              />
            </div>
            <div style={styles.formGroup}>
              <label style={styles.label}>Link URL</label>
              <input
                type="url"
                style={styles.input}
                value={block.content.url}
                onChange={(e) => updateBlock(block.id, 'content.url', e.target.value)}
                placeholder="https://example.com"
              />
            </div>
            <div style={styles.formRow}>
              <div style={styles.formGroup}>
                <label style={styles.label}>Background Color</label>
                <input
                  type="color"
                  style={styles.colorInput}
                  value={block.settings.backgroundColor}
                  onChange={(e) => updateBlock(block.id, 'settings.backgroundColor', e.target.value)}
                />
              </div>
              <div style={styles.alignmentButtons}>
                {['left', 'center', 'right'].map(align => (
                  <button
                    key={align}
                    style={{
                      ...styles.alignmentButton,
                      ...(block.settings.textAlign === align ? styles.activeAlignment : {})
                    }}
                    onClick={() => updateBlock(block.id, 'settings.textAlign', align)}
                  >
                    {align}
                  </button>
                ))}
              </div>
            </div>
          </div>
        );

      case 'image':
        return (
          <div style={styles.blockContent}>
            <div style={styles.formGroup}>
              <label style={styles.label}>Image URL</label>
              <input
                type="url"
                style={styles.input}
                value={block.content.src}
                onChange={(e) => updateBlock(block.id, 'content.src', e.target.value)}
                placeholder="https://example.com/image.jpg"
              />
            </div>
            <div style={styles.formGroup}>
              <label style={styles.label}>Alt Text</label>
              <input
                type="text"
                style={styles.input}
                value={block.content.alt}
                onChange={(e) => updateBlock(block.id, 'content.alt', e.target.value)}
                placeholder="Image description..."
              />
            </div>
            <div style={styles.formRow}>
              <div style={styles.formGroup}>
                <label style={styles.label}>Width</label>
                <select
                  style={styles.select}
                  value={block.content.width}
                  onChange={(e) => updateBlock(block.id, 'content.width', e.target.value)}
                >
                  <option value="100%">100%</option>
                  <option value="75%">75%</option>
                  <option value="50%">50%</option>
                  <option value="25%">25%</option>
                </select>
              </div>
              <div style={styles.alignmentButtons}>
                {['left', 'center', 'right'].map(align => (
                  <button
                    key={align}
                    style={{
                      ...styles.alignmentButton,
                      ...(block.content.alignment === align ? styles.activeAlignment : {})
                    }}
                    onClick={() => updateBlock(block.id, 'content.alignment', align)}
                  >
                    {align}
                  </button>
                ))}
              </div>
            </div>
          </div>
        );

      default:
        return (
          <div style={styles.placeholderBlock}>
            <p>Editor for {block.type} block coming soon...</p>
          </div>
        );
    }
  };

  return (
    <div style={styles.contentEditor}>
      {/* Content Blocks */}
      <div style={styles.contentBlocks}>
        <h3 style={styles.sectionTitle}>Email Content</h3>
        
        {contentBlocks.length === 0 ? (
          <div style={styles.emptyContent}>
            <FiPlus style={styles.emptyIcon} />
            <div style={styles.emptyText}>No content blocks yet</div>
            <div style={styles.emptySubtext}>Add content blocks above to build your email</div>
          </div>
        ) : (
          contentBlocks.map((block, index) => (
            <div
              key={block.id}
              style={{
                ...styles.contentBlock,
                ...(activeBlock === block.id ? styles.activeBlock : {})
              }}
              onClick={() => setActiveBlock(activeBlock === block.id ? null : block.id)}
            >
              <div style={styles.blockHeader}>
                <div style={styles.blockInfo}>
                  <FiMove style={styles.dragHandle} />
                  <span style={styles.blockType}>{block.type}</span>
                </div>
                <div style={styles.blockActions}>
                  <button
                    style={styles.blockActionButton}
                    onClick={(e) => {
                      e.stopPropagation();
                      duplicateBlock(block.id);
                    }}
                    title="Duplicate block"
                  >
                    <FiCopy />
                  </button>
                  <button
                    style={styles.blockActionButton}
                    onClick={(e) => {
                      e.stopPropagation();
                      deleteBlock(block.id);
                    }}
                    title="Delete block"
                  >
                    <FiTrash2 />
                  </button>
                </div>
              </div>

              {activeBlock === block.id && renderBlockEditor(block)}
            </div>
          ))
        )}
      </div>

      {/* Dynamic Fields Helper */}
      {contentBlocks.length > 0 && (
        <div style={styles.dynamicFields}>
          <span style={styles.dynamicFieldsLabel}>Available fields:</span>
          {['FirstName', 'LastName', 'Email'].map(field => (
            <button
              key={field}
              style={styles.dynamicFieldButton}
              onClick={() => {
                // This would copy the field to clipboard or insert into active text field
                navigator.clipboard.writeText(`{${field}}`);
              }}
              title={`Click to copy {${field}} to clipboard`}
            >
              {field}
            </button>
          ))}
        </div>
      )}
    </div>
  );
};

export default ContentEditor;