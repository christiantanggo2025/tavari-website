// components/Mail/CampaignSettings.jsx
import React from 'react';
import { styles } from '../../styles/Mail/CampaignBuilder.styles';

const CampaignSettings = ({ campaign, onChange }) => {
  const handleInputChange = (field, value) => {
    onChange(field, value);
  };

  return (
    <div style={{ marginBottom: '30px' }}>
      <h2 style={styles.sectionTitle}>Campaign Settings</h2>
      
      <div style={styles.formGroup}>
        <label style={styles.label}>Campaign Name *</label>
        <input
          type="text"
          style={styles.input}
          value={campaign.name}
          onChange={(e) => handleInputChange('name', e.target.value)}
          placeholder="e.g., Summer Special Offer"
        />
      </div>
      
      <div style={styles.formGroup}>
        <label style={styles.label}>Subject Line *</label>
        <input
          type="text"
          style={styles.input}
          value={campaign.subject_line}
          onChange={(e) => handleInputChange('subject_line', e.target.value)}
          placeholder="e.g., 🌞 Summer Fun Awaits!"
        />
      </div>
      
      <div style={styles.formGroup}>
        <label style={styles.label}>Preheader Text</label>
        <input
          type="text"
          style={styles.input}
          value={campaign.preheader_text}
          onChange={(e) => handleInputChange('preheader_text', e.target.value)}
          placeholder="Optional preview text that appears after subject line"
        />
      </div>
    </div>
  );
};

export default CampaignSettings;