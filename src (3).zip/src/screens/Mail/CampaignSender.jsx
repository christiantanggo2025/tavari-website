// screens/Mail/CampaignSender.jsx
import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { supabase } from '../../supabaseClient';
import { useBusiness } from '../../contexts/BusinessContext';
import emailSendingService from '../../helpers/Mail/emailSendingService';
import {
  FiSend, FiUsers, FiMail, FiCheckCircle, FiAlertTriangle, FiX, FiRefreshCw,
  FiClock, FiBarChart2, FiSettings, FiPlay, FiPause, FiStop, FiEye
} from 'react-icons/fi';

const CampaignSender = () => {
  const { campaignId } = useParams();
  const navigate = useNavigate();
  const { business } = useBusiness();
  
  const [campaign, setCampaign] = useState(null);
  const [contacts, setContacts] = useState([]);
  const [selectedContacts, setSelectedContacts] = useState('all');
  const [customContactIds, setCustomContactIds] = useState([]);
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const [sendingProgress, setSendingProgress] = useState(null);
  const [testEmails, setTestEmails] = useState('');
  const [sendingTest, setSendingTest] = useState(false);
  const [validationErrors, setValidationErrors] = useState([]);
  const [sendingStats, setSendingStats] = useState({
    queued: 0,
    sent: 0,
    failed: 0,
    bounced: 0
  });
  const [isMonitoring, setIsMonitoring] = useState(false);
  const [sendingPaused, setSendingPaused] = useState(false);

  const businessId = business?.id;

  useEffect(() => {
    if (campaignId && businessId) {
      loadCampaign();
      loadContacts();
    }
  }, [campaignId, businessId]);

  useEffect(() => {
    let interval;
    if (isMonitoring) {
      interval = setInterval(() => {
        updateSendingProgress();
      }, 2000); // Update every 2 seconds
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isMonitoring, campaignId]);

  const loadCampaign = async () => {
    try {
      const { data, error } = await supabase
        .from('mail_campaigns')
        .select('*')
        .eq('id', campaignId)
        .eq('business_id', businessId)
        .single();

      if (error) throw error;
      setCampaign(data);
      
      // Check if campaign is already sending
      if (data.status === 'sending') {
        setIsMonitoring(true);
        updateSendingProgress();
      }
    } catch (error) {
      console.error('Error loading campaign:', error);
      navigate('/dashboard/mail/campaigns');
    }
  };

  const loadContacts = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('mail_contacts')
        .select('id, first_name, last_name, email, subscribed, tags')
        .eq('business_id', businessId)
        .eq('subscribed', true)
        .order('first_name');

      if (error) throw error;
      setContacts(data || []);
    } catch (error) {
      console.error('Error loading contacts:', error);
    } finally {
      setLoading(false);
    }
  };

  // Step 126: Real-time sending progress tracking
  const updateSendingProgress = async () => {
    try {
      // Get queue status
      const { data: queueStats, error: queueError } = await supabase
        .from('mail_sending_queue')
        .select('status')
        .eq('campaign_id', campaignId);

      if (queueError) throw queueError;

      // Get send records
      const { data: sendStats, error: sendError } = await supabase
        .from('mail_campaign_sends')
        .select('status')
        .eq('campaign_id', campaignId);

      if (sendError) throw sendError;

      // Calculate stats
      const stats = {
        queued: queueStats?.filter(q => q.status === 'queued').length || 0,
        processing: queueStats?.filter(q => q.status === 'processing').length || 0,
        sent: sendStats?.filter(s => s.status === 'sent').length || 0,
        failed: sendStats?.filter(s => s.status === 'failed').length || 0,
        bounced: sendStats?.filter(s => s.status === 'bounced').length || 0
      };

      setSendingStats(stats);

      // Update progress
      const total = campaign?.total_recipients || 0;
      const completed = stats.sent + stats.failed + stats.bounced;
      
      setSendingProgress({
        total,
        completed,
        percentage: total > 0 ? Math.round((completed / total) * 100) : 0,
        remaining: stats.queued + stats.processing
      });

      // Check if sending is complete
      if (completed >= total && total > 0) {
        setIsMonitoring(false);
        setSending(false);
        
        // Update campaign status
        await supabase
          .from('mail_campaigns')
          .update({ 
            status: 'sent',
            sent_at: new Date().toISOString(),
            emails_sent: stats.sent
          })
          .eq('id', campaignId);
      }
    } catch (error) {
      console.error('Error updating sending progress:', error);
    }
  };

  // Step 127: Pre-send validation
  const validateCampaignForSending = () => {
    const errors = [];

    if (!campaign) {
      errors.push('Campaign not found');
      return errors;
    }

    if (!campaign.name?.trim()) {
      errors.push('Campaign name is required');
    }

    if (!campaign.subject_line?.trim()) {
      errors.push('Subject line is required');
    }

    if (!campaign.content_json || campaign.content_json.length === 0) {
      errors.push('Campaign must have content blocks');
    }

    // Check for unsubscribe link
    const hasUnsubscribe = campaign.content_json?.some(block =>
      (block.type === 'text' && typeof block.content === 'string' && 
       block.content.includes('{UnsubscribeLink}')) ||
      (block.type === 'button' && block.content?.url && 
       block.content.url.includes('unsubscribe'))
    );

    if (!hasUnsubscribe) {
      errors.push('Campaign must include an unsubscribe link for CASL compliance');
    }

    // Check recipient count
    const recipientCount = getRecipientCount();
    if (recipientCount === 0) {
      errors.push('No recipients selected');
    }

    setValidationErrors(errors);
    return errors;
  };

  // Step 128: Send test emails
  const handleSendTest = async () => {
    if (!testEmails.trim()) {
      alert('Please enter at least one email address for testing.');
      return;
    }

    const emails = testEmails.split(',').map(email => email.trim()).filter(email => email);
    const invalidEmails = emails.filter(email => !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email));
    
    if (invalidEmails.length > 0) {
      alert(`Invalid email addresses: ${invalidEmails.join(', ')}`);
      return;
    }

    setSendingTest(true);
    try {
      // Create test contacts
      const testContacts = emails.map(email => ({
        id: `test-${Date.now()}-${Math.random()}`,
        email: email,
        first_name: 'Test',
        last_name: 'Recipient'
      }));

      // Send test emails
      for (const testContact of testContacts) {
        const queueItem = {
          campaign_id: campaignId,
          contact_id: testContact.id,
          email_address: testContact.email,
          campaign: campaign,
          contact: testContact
        };

        await emailSendingService.sendSingleEmail(queueItem);
      }

      alert(`Test emails sent successfully to ${emails.length} recipient(s)!`);
      setTestEmails('');
    } catch (error) {
      console.error('Error sending test emails:', error);
      alert('Failed to send test emails. Please try again.');
    } finally {
      setSendingTest(false);
    }
  };

  // Step 129: Start campaign sending
  const handleStartSending = async () => {
    const errors = validateCampaignForSending();
    if (errors.length > 0) {
      return;
    }

    const recipientCount = getRecipientCount();
    const confirmMessage = `Send "${campaign.name}" to ${recipientCount} contact(s)?\n\nThis action cannot be undone.`;
    
    if (!window.confirm(confirmMessage)) return;

    setSending(true);
    setIsMonitoring(true);
    
    try {
      // Determine which contacts to send to
      let contactIdsToSend = null;
      if (selectedContacts === 'custom') {
        contactIdsToSend = customContactIds;
      }

      // Queue campaign for sending
      const result = await emailSendingService.queueCampaignForSending(campaignId, contactIdsToSend);
      
      console.log('Campaign queued:', result);
      
      // Start processing the queue
      processQueue();
      
    } catch (error) {
      console.error('Error starting campaign send:', error);
      alert('Failed to start sending campaign. Please try again.');
      setSending(false);
      setIsMonitoring(false);
    }
  };

  // Step 130: Process sending queue
  const processQueue = async () => {
    try {
      while (isMonitoring && !sendingPaused) {
        const result = await emailSendingService.processSendingQueue(10);
        
        if (result.processed === 0) {
          // No more items to process
          break;
        }

        // Update progress
        await updateSendingProgress();
        
        // Small delay to prevent overwhelming the system
        await new Promise(resolve => setTimeout(resolve, 1000));
      }
    } catch (error) {
      console.error('Error processing queue:', error);
    }
  };

  // Step 129: Emergency stop functionality
  const handleStopSending = async () => {
    if (!window.confirm('Are you sure you want to stop sending this campaign? Unsent emails will remain in the queue.')) {
      return;
    }

    try {
      // Cancel all queued items for this campaign
      await supabase
        .from('mail_sending_queue')
        .update({ status: 'cancelled' })
        .eq('campaign_id', campaignId)
        .eq('status', 'queued');

      setIsMonitoring(false);
      setSending(false);
      setSendingPaused(false);

      // Update campaign status
      await supabase
        .from('mail_campaigns')
        .update({ status: 'paused' })
        .eq('id', campaignId);

      alert('Campaign sending stopped. You can resume later if needed.');
    } catch (error) {
      console.error('Error stopping campaign:', error);
      alert('Failed to stop campaign sending.');
    }
  };

  const handlePauseSending = () => {
    setSendingPaused(!sendingPaused);
  };

  const getRecipientCount = () => {
    if (selectedContacts === 'all') {
      return contacts.length;
    } else if (selectedContacts === 'custom') {
      return customContactIds.length;
    }
    return 0;
  };

  const handleContactToggle = (contactId) => {
    if (customContactIds.includes(contactId)) {
      setCustomContactIds(customContactIds.filter(id => id !== contactId));
    } else {
      setCustomContactIds([...customContactIds, contactId]);
    }
  };

  const handleSelectAll = () => {
    setCustomContactIds(contacts.map(c => c.id));
  };

  const handleDeselectAll = () => {
    setCustomContactIds([]);
  };

  if (loading) {
    return (
      <div style={styles.container}>
        <div style={styles.loading}>Loading campaign...</div>
      </div>
    );
  }

  if (!campaign) {
    return (
      <div style={styles.container}>
        <div style={styles.error}>Campaign not found</div>
      </div>
    );
  }

  return (
    <div style={styles.container}>
      {/* Header */}
      <div style={styles.header}>
        <div style={styles.headerLeft}>
          <h1 style={styles.title}>Send Campaign: {campaign.name}</h1>
          <p style={styles.subtitle}>Configure and send your email campaign</p>
        </div>
        <div style={styles.headerActions}>
          <button
            style={styles.secondaryButton}
            onClick={() => navigate(`/dashboard/mail/builder/${campaignId}`)}
          >
            <FiEye style={styles.buttonIcon} />
            Preview
          </button>
          {campaign.status === 'sending' && (
            <>
              <button
                style={styles.secondaryButton}
                onClick={handlePauseSending}
              >
                {sendingPaused ? <FiPlay /> : <FiPause />}
                {sendingPaused ? 'Resume' : 'Pause'}
              </button>
              <button
                style={styles.dangerButton}
                onClick={handleStopSending}
              >
                <FiStop style={styles.buttonIcon} />
                Stop
              </button>
            </>
          )}
        </div>
      </div>

      {/* Validation Errors */}
      {validationErrors.length > 0 && (
        <div style={styles.validationErrors}>
          <div style={styles.errorsHeader}>
            <FiAlertTriangle style={styles.errorIcon} />
            <span>Please fix these issues before sending:</span>
          </div>
          <ul style={styles.errorsList}>
            {validationErrors.map((error, index) => (
              <li key={index}>{error}</li>
            ))}
          </ul>
        </div>
      )}

      {/* Sending Progress */}
      {(sending || campaign.status === 'sending') && sendingProgress && (
        <div style={styles.progressSection}>
          <div style={styles.progressHeader}>
            <h3 style={styles.progressTitle}>
              <FiSend style={styles.progressIcon} />
              Sending Progress
            </h3>
            <div style={styles.progressStats}>
              <span style={styles.progressText}>
                {sendingProgress.completed} of {sendingProgress.total} ({sendingProgress.percentage}%)
              </span>
            </div>
          </div>
          
          <div style={styles.progressBar}>
            <div 
              style={{
                ...styles.progressFill,
                width: `${sendingProgress.percentage}%`
              }}
            />
          </div>

          <div style={styles.sendingStatsGrid}>
            <div style={styles.statCard}>
              <FiClock style={styles.statIcon} />
              <div style={styles.statNumber}>{sendingStats.queued}</div>
              <div style={styles.statLabel}>Queued</div>
            </div>
            <div style={styles.statCard}>
              <FiCheckCircle style={styles.statIcon} />
              <div style={styles.statNumber}>{sendingStats.sent}</div>
              <div style={styles.statLabel}>Sent</div>
            </div>
            <div style={styles.statCard}>
              <FiAlertTriangle style={styles.statIcon} />
              <div style={styles.statNumber}>{sendingStats.failed}</div>
              <div style={styles.statLabel}>Failed</div>
            </div>
            <div style={styles.statCard}>
              <FiRefreshCw style={styles.statIcon} />
              <div style={styles.statNumber}>{sendingStats.bounced}</div>
              <div style={styles.statLabel}>Bounced</div>
            </div>
          </div>
        </div>
      )}

      {/* Test Email Section */}
      <div style={styles.testSection}>
        <h3 style={styles.sectionTitle}>
          <FiMail style={styles.sectionIcon} />
          Send Test Email
        </h3>
        <div style={styles.testControls}>
          <input
            type="text"
            style={styles.testInput}
            value={testEmails}
            onChange={(e) => setTestEmails(e.target.value)}
            placeholder="Enter test email addresses (comma-separated)"
            disabled={sending}
          />
          <button
            style={styles.testButton}
            onClick={handleSendTest}
            disabled={sendingTest || !testEmails.trim() || sending}
          >
            {sendingTest ? 'Sending...' : 'Send Test'}
          </button>
        </div>
        <div style={styles.testHint}>
          Send a test email to verify your campaign looks correct before sending to all contacts.
        </div>
      </div>

      {/* Recipient Selection */}
      <div style={styles.recipientSection}>
        <h3 style={styles.sectionTitle}>
          <FiUsers style={styles.sectionIcon} />
          Select Recipients
        </h3>

        <div style={styles.recipientOptions}>
          <label style={styles.recipientOption}>
            <input
              type="radio"
              name="recipients"
              value="all"
              checked={selectedContacts === 'all'}
              onChange={(e) => setSelectedContacts(e.target.value)}
              disabled={sending}
            />
            <div style={styles.optionContent}>
              <div style={styles.optionTitle}>All Subscribed Contacts</div>
              <div style={styles.optionDescription}>
                Send to all {contacts.length} subscribed contacts
              </div>
            </div>
          </label>

          <label style={styles.recipientOption}>
            <input
              type="radio"
              name="recipients"
              value="custom"
              checked={selectedContacts === 'custom'}
              onChange={(e) => setSelectedContacts(e.target.value)}
              disabled={sending}
            />
            <div style={styles.optionContent}>
              <div style={styles.optionTitle}>Custom Selection</div>
              <div style={styles.optionDescription}>
                Choose specific contacts ({customContactIds.length} selected)
              </div>
            </div>
          </label>
        </div>

        {/* Custom Contact Selection */}
        {selectedContacts === 'custom' && (
          <div style={styles.customSelection}>
            <div style={styles.bulkActions}>
              <button
                style={styles.bulkButton}
                onClick={handleSelectAll}
                disabled={sending}
              >
                Select All
              </button>
              <button
                style={styles.bulkButton}
                onClick={handleDeselectAll}
                disabled={sending}
              >
                Deselect All
              </button>
            </div>

            <div style={styles.contactsList}>
              {contacts.length === 0 ? (
                <div style={styles.noContacts}>
                  No subscribed contacts found.
                </div>
              ) : (
                contacts.map(contact => (
                  <label key={contact.id} style={styles.contactItem}>
                    <input
                      type="checkbox"
                      checked={customContactIds.includes(contact.id)}
                      onChange={() => handleContactToggle(contact.id)}
                      disabled={sending}
                    />
                    <div style={styles.contactInfo}>
                      <div style={styles.contactName}>
                        {contact.first_name} {contact.last_name}
                      </div>
                      <div style={styles.contactEmail}>
                        {contact.email}
                      </div>
                    </div>
                  </label>
                ))
              )}
            </div>
          </div>
        )}
      </div>

      {/* Send Summary */}
      <div style={styles.sendSummary}>
        <div style={styles.summaryStats}>
          <div style={styles.statItem}>
            <FiUsers style={styles.statIcon} />
            <span style={styles.statLabel}>Recipients:</span>
            <span style={styles.statValue}>{getRecipientCount()}</span>
          </div>
          <div style={styles.statItem}>
            <FiMail style={styles.statIcon} />
            <span style={styles.statLabel}>Estimated Cost:</span>
            <span style={styles.statValue}>
              ${(getRecipientCount() * 0.0025).toFixed(4)}
            </span>
          </div>
        </div>

        {getRecipientCount() > 0 && !sending && campaign.status !== 'sending' && (
          <div style={styles.sendWarning}>
            <FiAlertTriangle style={styles.warningIcon} />
            <span>This action cannot be undone. The campaign will be sent immediately.</span>
          </div>
        )}
      </div>

      {/* Send Button */}
      {campaign.status !== 'sending' && (
        <div style={styles.sendActions}>
          <button
            style={styles.sendButton}
            onClick={handleStartSending}
            disabled={getRecipientCount() === 0 || sending || validationErrors.length > 0}
          >
            <FiSend style={styles.buttonIcon} />
            Send to {getRecipientCount()} Contact{getRecipientCount() !== 1 ? 's' : ''}
          </button>
        </div>
      )}
    </div>
  );
};

const styles = {
  container: {
    padding: '20px',
    maxWidth: '1000px',
    margin: '0 auto',
    backgroundColor: '#f8f8f8',
    minHeight: '100vh',
  },
  loading: {
    textAlign: 'center',
    padding: '40px',
    fontSize: '18px',
    color: '#666',
  },
  error: {
    textAlign: 'center',
    padding: '40px',
    fontSize: '18px',
    color: '#f44336',
  },
  header: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: '30px',
    flexWrap: 'wrap',
    gap: '20px',
  },
  headerLeft: {
    flex: 1,
  },
  title: {
    fontSize: '28px',
    fontWeight: 'bold',
    color: '#333',
    marginBottom: '8px',
  },
  subtitle: {
    fontSize: '16px',
    color: '#666',
    margin: 0,
  },
  headerActions: {
    display: 'flex',
    gap: '12px',
    alignItems: 'center',
  },
  secondaryButton: {
    backgroundColor: 'white',
    color: 'teal',
    border: '2px solid teal',
    borderRadius: '8px',
    padding: '10px 18px',
    fontSize: '14px',
    fontWeight: 'bold',
    cursor: 'pointer',
    display: 'flex',
    alignItems: 'center',
    gap: '8px',
  },
  dangerButton: {
    backgroundColor: '#f44336',
    color: 'white',
    border: 'none',
    borderRadius: '8px',
    padding: '12px 20px',
    fontSize: '14px',
    fontWeight: 'bold',
    cursor: 'pointer',
    display: 'flex',
    alignItems: 'center',
    gap: '8px',
  },
  buttonIcon: {
    fontSize: '14px',
  },
  validationErrors: {
    backgroundColor: '#ffebee',
    border: '1px solid #f44336',
    borderRadius: '8px',
    padding: '15px',
    marginBottom: '20px',
  },
  errorsHeader: {
    display: 'flex',
    alignItems: 'center',
    gap: '8px',
    fontSize: '16px',
    fontWeight: 'bold',
    color: '#c62828',
    marginBottom: '10px',
  },
  errorIcon: {
    fontSize: '16px',
  },
  errorsList: {
    margin: '0',
    paddingLeft: '20px',
    color: '#c62828',
  },
  progressSection: {
    backgroundColor: 'white',
    borderRadius: '8px',
    border: '1px solid #ddd',
    padding: '20px',
    marginBottom: '20px',
  },
  progressHeader: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: '15px',
  },
  progressTitle: {
    fontSize: '18px',
    fontWeight: 'bold',
    color: '#333',
    display: 'flex',
    alignItems: 'center',
    gap: '8px',
    margin: 0,
  },
  progressIcon: {
    color: 'teal',
  },
  progressStats: {
    fontSize: '14px',
    color: '#666',
  },
  progressText: {
    fontWeight: 'bold',
  },
  progressBar: {
    width: '100%',
    height: '20px',
    backgroundColor: '#f0f0f0',
    borderRadius: '10px',
    overflow: 'hidden',
    marginBottom: '20px',
  },
  progressFill: {
    height: '100%',
    backgroundColor: 'teal',
    borderRadius: '10px',
    transition: 'width 0.3s ease',
  },
  sendingStatsGrid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(4, 1fr)',
    gap: '15px',
  },
  statCard: {
    textAlign: 'center',
    padding: '15px',
    backgroundColor: '#f8f8f8',
    borderRadius: '8px',
  },
  statIcon: {
    fontSize: '20px',
    color: 'teal',
    marginBottom: '8px',
  },
  statNumber: {
    fontSize: '20px',
    fontWeight: 'bold',
    color: '#333',
  },
  statLabel: {
    fontSize: '12px',
    color: '#666',
    marginTop: '4px',
  },
  testSection: {
    backgroundColor: 'white',
    borderRadius: '8px',
    border: '1px solid #ddd',
    padding: '20px',
    marginBottom: '20px',
  },
  sectionTitle: {
    fontSize: '16px',
    fontWeight: 'bold',
    color: '#333',
    marginBottom: '15px',
    display: 'flex',
    alignItems: 'center',
    gap: '8px',
  },
  sectionIcon: {
    color: 'teal',
  },
  testControls: {
    display: 'flex',
    gap: '10px',
    marginBottom: '8px',
  },
  testInput: {
    flex: 1,
    padding: '8px 12px',
    fontSize: '14px',
    border: '2px solid #ddd',
    borderRadius: '6px',
  },
  testButton: {
    backgroundColor: 'teal',
    color: 'white',
    border: 'none',
    borderRadius: '6px',
    padding: '8px 16px',
    fontSize: '14px',
    fontWeight: 'bold',
    cursor: 'pointer',
  },
  testHint: {
    fontSize: '12px',
    color: '#666',
    fontStyle: 'italic',
  },
  recipientSection: {
    backgroundColor: 'white',
    borderRadius: '8px',
    border: '1px solid #ddd',
    padding: '20px',
    marginBottom: '20px',
  },
  recipientOptions: {
    display: 'flex',
    flexDirection: 'column',
    gap: '10px',
    marginBottom: '15px',
  },
  recipientOption: {
    display: 'flex',
    alignItems: 'center',
    gap: '12px',
    padding: '12px',
    border: '2px solid #ddd',
    borderRadius: '8px',
    cursor: 'pointer',
  },
  optionContent: {
    flex: 1,
  },
  optionTitle: {
    fontSize: '14px',
    fontWeight: 'bold',
    color: '#333',
    marginBottom: '2px',
  },
  optionDescription: {
    fontSize: '12px',
    color: '#666',
  },
  customSelection: {
    border: '1px solid #ddd',
    borderRadius: '8px',
    padding: '15px',
  },
  bulkActions: {
    display: 'flex',
    gap: '10px',
    marginBottom: '15px',
  },
  bulkButton: {
    backgroundColor: 'white',
    color: 'teal',
    border: '2px solid teal',
    borderRadius: '6px',
    padding: '6px 12px',
    fontSize: '12px',
    fontWeight: 'bold',
    cursor: 'pointer',
  },
  contactsList: {
    maxHeight: '250px',
    overflow: 'auto',
    border: '1px solid #f0f0f0',
    borderRadius: '6px',
  },
  contactItem: {
    display: 'flex',
    alignItems: 'center',
    gap: '12px',
    padding: '10px',
    borderBottom: '1px solid #f0f0f0',
    cursor: 'pointer',
  },
  contactInfo: {
    flex: 1,
  },
  contactName: {
    fontSize: '14px',
    fontWeight: 'bold',
    color: '#333',
    marginBottom: '2px',
  },
  contactEmail: {
    fontSize: '12px',
    color: '#666',
  },
  noContacts: {
    textAlign: 'center',
    padding: '40px 20px',
    color: '#666',
    fontStyle: 'italic',
  },
  sendSummary: {
    backgroundColor: 'white',
    borderRadius: '8px',
    border: '1px solid #ddd',
    padding: '20px',
    marginBottom: '20px',
  },
  summaryStats: {
    display: 'flex',
    gap: '20px',
    marginBottom: '10px',
  },
  statItem: {
    display: 'flex',
    alignItems: 'center',
    gap: '8px',
    fontSize: '14px',
  },
  statValue: {
    fontWeight: 'bold',
    color: '#333',
  },
  sendWarning: {
    display: 'flex',
    alignItems: 'center',
    gap: '8px',
    fontSize: '12px',
    color: '#e17055',
    fontWeight: 'bold',
  },
  warningIcon: {
    fontSize: '14px',
  },
  sendActions: {
    textAlign: 'center',
  },
  sendButton: {
    backgroundColor: 'teal',
    color: 'white',
    border: 'none',
    borderRadius: '8px',
    padding: '15px 30px',
    fontSize: '16px',
    fontWeight: 'bold',
    cursor: 'pointer',
    display: 'inline-flex',
    alignItems: 'center',
    gap: '10px',
  },
};

export default CampaignSender;