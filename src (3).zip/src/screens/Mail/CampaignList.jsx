// screens/Mail/CampaignList.jsx
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { FiMail, FiPlus, FiEdit3, FiSend, FiEye, FiTrash2, FiCopy, FiClock, FiCheckCircle, FiAlertCircle } from 'react-icons/fi';

const CampaignList = () => {
  const navigate = useNavigate();
  const [campaigns, setCampaigns] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('all'); // all, draft, sent, scheduled

  useEffect(() => {
    loadCampaigns();
  }, [filter]);

  const loadCampaigns = async () => {
    try {
      setLoading(true);
      // TODO: Replace with actual Supabase calls
      // const { data, error } = await supabase
      //   .from('mail_campaigns')
      //   .select('*')
      //   .eq('business_id', currentBusinessId)
      //   .order('created_at', { ascending: false });
      
      // Mock data for now
      const mockCampaigns = [
        {
          id: '1',
          name: 'Summer Fun Special',
          subject_line: '🌞 Beat the Heat with 50% Off All Activities!',
          status: 'sent',
          total_recipients: 1189,
          emails_sent: 1189,
          created_at: '2024-08-10T10:00:00Z',
          sent_at: '2024-08-10T14:30:00Z'
        },
        {
          id: '2',
          name: 'Birthday Party Package',
          subject_line: '🎉 Make Your Birthday Unforgettable',
          status: 'draft',
          total_recipients: 0,
          emails_sent: 0,
          created_at: '2024-08-15T09:15:00Z',
          sent_at: null
        },
        {
          id: '3',
          name: 'Back to School Special',
          subject_line: 'After School Fun Awaits! 📚',
          status: 'draft',
          total_recipients: 0,
          emails_sent: 0,
          created_at: '2024-08-14T16:45:00Z',
          sent_at: null
        }
      ];
      
      setCampaigns(mockCampaigns);
    } catch (error) {
      console.error('Error loading campaigns:', error);
    } finally {
      setLoading(false);
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'sent':
        return <FiCheckCircle style={{ color: '#4caf50' }} />;
      case 'draft':
        return <FiEdit3 style={{ color: '#ff9800' }} />;
      case 'scheduled':
        return <FiClock style={{ color: '#2196f3' }} />;
      case 'failed':
        return <FiAlertCircle style={{ color: '#f44336' }} />;
      default:
        return <FiMail style={{ color: '#666' }} />;
    }
  };

  const getStatusText = (status) => {
    switch (status) {
      case 'sent':
        return 'Sent';
      case 'draft':
        return 'Draft';
      case 'scheduled':
        return 'Scheduled';
      case 'failed':
        return 'Failed';
      default:
        return 'Unknown';
    }
  };

  const formatDate = (dateString) => {
    if (!dateString) return 'N/A';
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const handleEdit = (campaignId) => {
    navigate(`/dashboard/mail/builder/${campaignId}`);
  };

  const handleDuplicate = (campaign) => {
    // TODO: Implement campaign duplication
    console.log('Duplicating campaign:', campaign.name);
  };

  const handleDelete = (campaignId) => {
    if (window.confirm('Are you sure you want to delete this campaign?')) {
      // TODO: Implement campaign deletion
      console.log('Deleting campaign:', campaignId);
    }
  };

  const filteredCampaigns = campaigns.filter(campaign => {
    if (filter === 'all') return true;
    return campaign.status === filter;
  });

  if (loading) {
    return (
      <div style={styles.container}>
        <div style={styles.loading}>Loading campaigns...</div>
      </div>
    );
  }

  return (
    <div style={styles.container}>
      {/* Header */}
      <div style={styles.header}>
        <div style={styles.headerLeft}>
          <h1 style={styles.title}>Email Campaigns</h1>
          <p style={styles.subtitle}>Create and manage your email marketing campaigns</p>
        </div>
        <button 
          style={styles.createButton}
          onClick={() => navigate('/dashboard/mail/builder')}
        >
          <FiPlus style={styles.buttonIcon} />
          Create Campaign
        </button>
      </div>

      {/* Filter Tabs */}
      <div style={styles.filterTabs}>
        {[
          { key: 'all', label: 'All Campaigns' },
          { key: 'draft', label: 'Drafts' },
          { key: 'sent', label: 'Sent' },
          { key: 'scheduled', label: 'Scheduled' }
        ].map(tab => (
          <button
            key={tab.key}
            style={{
              ...styles.filterTab,
              ...(filter === tab.key ? styles.activeFilterTab : {})
            }}
            onClick={() => setFilter(tab.key)}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Campaigns List */}
      {filteredCampaigns.length === 0 ? (
        <div style={styles.emptyState}>
          <div style={styles.emptyIcon}><FiMail /></div>
          <h3 style={styles.emptyTitle}>No campaigns found</h3>
          <p style={styles.emptyText}>
            {filter === 'all' 
              ? "You haven't created any campaigns yet."
              : `No ${filter} campaigns found.`
            }
          </p>
          <button 
            style={styles.emptyButton}
            onClick={() => navigate('/dashboard/mail/builder')}
          >
            <FiPlus style={styles.buttonIcon} />
            Create Your First Campaign
          </button>
        </div>
      ) : (
        <div style={styles.campaignsList}>
          {filteredCampaigns.map(campaign => (
            <div key={campaign.id} style={styles.campaignCard}>
              <div style={styles.campaignHeader}>
                <div style={styles.campaignInfo}>
                  <div style={styles.campaignName}>{campaign.name}</div>
                  <div style={styles.campaignSubject}>{campaign.subject_line}</div>
                </div>
                <div style={styles.campaignStatus}>
                  {getStatusIcon(campaign.status)}
                  <span style={styles.statusText}>{getStatusText(campaign.status)}</span>
                </div>
              </div>
              
              <div style={styles.campaignStats}>
                <div style={styles.stat}>
                  <span style={styles.statLabel}>Recipients:</span>
                  <span style={styles.statValue}>{campaign.total_recipients.toLocaleString()}</span>
                </div>
                <div style={styles.stat}>
                  <span style={styles.statLabel}>Sent:</span>
                  <span style={styles.statValue}>{campaign.emails_sent.toLocaleString()}</span>
                </div>
                <div style={styles.stat}>
                  <span style={styles.statLabel}>Created:</span>
                  <span style={styles.statValue}>{formatDate(campaign.created_at)}</span>
                </div>
                {campaign.sent_at && (
                  <div style={styles.stat}>
                    <span style={styles.statLabel}>Sent:</span>
                    <span style={styles.statValue}>{formatDate(campaign.sent_at)}</span>
                  </div>
                )}
              </div>
              
              <div style={styles.campaignActions}>
                {campaign.status === 'draft' && (
                  <button 
                    style={styles.actionButton}
                    onClick={() => handleEdit(campaign.id)}
                  >
                    <FiEdit3 style={styles.actionIcon} />
                    Edit
                  </button>
                )}
                
                <button 
                  style={styles.actionButton}
                  onClick={() => navigate(`/dashboard/mail/campaigns/${campaign.id}`)}
                >
                  <FiEye style={styles.actionIcon} />
                  View
                </button>
                
                <button 
                  style={styles.actionButton}
                  onClick={() => handleDuplicate(campaign)}
                >
                  <FiCopy style={styles.actionIcon} />
                  Duplicate
                </button>
                
                {campaign.status === 'draft' && (
                  <button 
                    style={{...styles.actionButton, ...styles.sendButton}}
                    onClick={() => navigate(`/dashboard/mail/send/${campaign.id}`)}
                  >
                    <FiSend style={styles.actionIcon} />
                    Send
                  </button>
                )}
                
                <button 
                  style={{...styles.actionButton, ...styles.deleteButton}}
                  onClick={() => handleDelete(campaign.id)}
                >
                  <FiTrash2 style={styles.actionIcon} />
                  Delete
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

const styles = {
  container: {
    padding: '20px',
    maxWidth: '1200px',
    margin: '0 auto',
    backgroundColor: '#f8f8f8',
    minHeight: '100vh',
  },
  loading: {
    textAlign: 'center',
    padding: '40px',
    fontSize: '18px',
    color: '#666',
  },
  header: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: '30px',
    flexWrap: 'wrap',
    gap: '20px',
  },
  headerLeft: {
    flex: 1,
  },
  title: {
    fontSize: '28px',
    fontWeight: 'bold',
    color: '#333',
    marginBottom: '8px',
  },
  subtitle: {
    fontSize: '16px',
    color: '#666',
    margin: 0,
  },
  createButton: {
    backgroundColor: 'teal',
    color: 'white',
    border: 'none',
    borderRadius: '8px',
    padding: '12px 24px',
    fontSize: '16px',
    fontWeight: 'bold',
    cursor: 'pointer',
    display: 'flex',
    alignItems: 'center',
    gap: '8px',
  },
  buttonIcon: {
    fontSize: '16px',
  },
  filterTabs: {
    display: 'flex',
    gap: '4px',
    marginBottom: '30px',
    backgroundColor: 'white',
    borderRadius: '8px',
    padding: '4px',
    border: '1px solid #ddd',
  },
  filterTab: {
    backgroundColor: 'transparent',
    border: 'none',
    borderRadius: '6px',
    padding: '10px 16px',
    fontSize: '14px',
    fontWeight: 'bold',
    color: '#666',
    cursor: 'pointer',
    transition: 'all 0.2s ease',
  },
  activeFilterTab: {
    backgroundColor: 'teal',
    color: 'white',
  },
  emptyState: {
    textAlign: 'center',
    padding: '60px 20px',
    backgroundColor: 'white',
    borderRadius: '8px',
    border: '1px solid #ddd',
  },
  emptyIcon: {
    fontSize: '48px',
    color: '#ccc',
    marginBottom: '20px',
  },
  emptyTitle: {
    fontSize: '24px',
    fontWeight: 'bold',
    color: '#333',
    marginBottom: '10px',
  },
  emptyText: {
    fontSize: '16px',
    color: '#666',
    marginBottom: '30px',
  },
  emptyButton: {
    backgroundColor: 'teal',
    color: 'white',
    border: 'none',
    borderRadius: '8px',
    padding: '12px 24px',
    fontSize: '16px',
    fontWeight: 'bold',
    cursor: 'pointer',
    display: 'inline-flex',
    alignItems: 'center',
    gap: '8px',
  },
  campaignsList: {
    display: 'flex',
    flexDirection: 'column',
    gap: '20px',
  },
  campaignCard: {
    backgroundColor: 'white',
    borderRadius: '8px',
    border: '1px solid #ddd',
    padding: '20px',
  },
  campaignHeader: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: '15px',
    gap: '20px',
  },
  campaignInfo: {
    flex: 1,
  },
  campaignName: {
    fontSize: '20px',
    fontWeight: 'bold',
    color: '#333',
    marginBottom: '5px',
  },
  campaignSubject: {
    fontSize: '16px',
    color: '#666',
    lineHeight: '1.4',
  },
  campaignStatus: {
    display: 'flex',
    alignItems: 'center',
    gap: '8px',
    padding: '8px 12px',
    backgroundColor: '#f8f8f8',
    borderRadius: '20px',
  },
  statusText: {
    fontSize: '14px',
    fontWeight: 'bold',
    color: '#333',
  },
  campaignStats: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fit, minmax(150px, 1fr))',
    gap: '15px',
    marginBottom: '20px',
    padding: '15px',
    backgroundColor: '#f8f8f8',
    borderRadius: '8px',
  },
  stat: {
    display: 'flex',
    flexDirection: 'column',
    gap: '4px',
  },
  statLabel: {
    fontSize: '12px',
    color: '#666',
    fontWeight: 'bold',
    textTransform: 'uppercase',
  },
  statValue: {
    fontSize: '16px',
    color: '#333',
    fontWeight: 'bold',
  },
  campaignActions: {
    display: 'flex',
    gap: '10px',
    flexWrap: 'wrap',
  },
  actionButton: {
    backgroundColor: 'white',
    border: '2px solid #ddd',
    borderRadius: '6px',
    padding: '8px 16px',
    fontSize: '14px',
    fontWeight: 'bold',
    color: '#333',
    cursor: 'pointer',
    display: 'flex',
    alignItems: 'center',
    gap: '6px',
    transition: 'all 0.2s ease',
  },
  actionIcon: {
    fontSize: '14px',
  },
  sendButton: {
    backgroundColor: 'teal',
    borderColor: 'teal',
    color: 'white',
  },
  deleteButton: {
    borderColor: '#f44336',
    color: '#f44336',
  },
};

export default CampaignList;