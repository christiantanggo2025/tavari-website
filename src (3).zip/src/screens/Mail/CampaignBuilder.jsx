// screens/Mail/CampaignBuilder.jsx
import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { supabase } from '../../supabaseClient';
import { useBusiness } from '../../contexts/BusinessContext';
import ImageUpload from '../../components/Mail/ImageUpload';
import SocialButtons from '../../components/Mail/SocialButtons';
import { styles } from '../../styles/Mail/CampaignBuilder.styles';
import {
  FiSave, FiSend, FiEye, FiSmartphone, FiMonitor, FiArrowLeft, FiPlus,
  FiType, FiImage, FiLink, FiMinus, FiShare2, FiSettings, FiTrash2,
  FiMove, FiCopy, FiEdit3, FiMail, FiUser, FiTag, FiCalendar, FiX,
  FiAlignLeft, FiAlignCenter, FiAlignRight, FiFileText
} from 'react-icons/fi';

const CampaignBuilder = () => {
  const navigate = useNavigate();
  const { campaignId } = useParams();
  const { business } = useBusiness();
  const isEditing = !!campaignId;

  const [campaign, setCampaign] = useState({
    name: '',
    subject_line: '',
    preheader_text: '',
    content_blocks: [],
    status: 'draft'
  });

  const [previewMode, setPreviewMode] = useState('desktop'); // desktop, mobile
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState('');
  const [contacts, setContacts] = useState([]);
  const [selectedContacts, setSelectedContacts] = useState('all'); // all, subscribed, custom
  const [customContactIds, setCustomContactIds] = useState([]);
  const [showContactSelector, setShowContactSelector] = useState(false);
  const [draggedBlock, setDraggedBlock] = useState(null);
  const [dragOverIndex, setDragOverIndex] = useState(null);
  const [showDraftsModal, setShowDraftsModal] = useState(false);
  const [drafts, setDrafts] = useState([]);
  const [loadingDrafts, setLoadingDrafts] = useState(false);
  const [isMobile, setIsMobile] = useState(window.innerWidth <= 1024);

  const businessId = business?.id;

  // Block types available in the editor
  const blockTypes = [
    { type: 'text', icon: FiType, label: 'Text Block', description: 'Add formatted text content' },
    { type: 'heading', icon: FiType, label: 'Heading', description: 'Add a heading or title' },
    { type: 'button', icon: FiLink, label: 'Button', description: 'Add a call-to-action button' },
    { type: 'image', icon: FiImage, label: 'Image', description: 'Add an image' },
    { type: 'divider', icon: FiMinus, label: 'Divider', description: 'Add a visual separator' },
    { type: 'social', icon: FiShare2, label: 'Social Links', description: 'Add social media buttons' },
    { type: 'spacer', icon: FiSettings, label: 'Spacer', description: 'Add vertical spacing' },
    { type: 'columns', icon: FiCopy, label: 'Two Columns', description: 'Side-by-side content' }
  ];

  useEffect(() => {
    if (isEditing && campaignId && businessId) {
      loadCampaign();
    }
    if (businessId) {
      loadContacts();
    }
  }, [campaignId, businessId]);

  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth <= 1024);
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  useEffect(() => {
    if (showDraftsModal) {
      loadDrafts();
    }
  }, [showDraftsModal, businessId]);

  const loadCampaign = async () => {
    try {
      const { data, error } = await supabase
        .from('mail_campaigns')
        .select('*')
        .eq('id', campaignId)
        .eq('business_id', businessId)
        .single();

      if (error) throw error;

      setCampaign({
        name: data.name || '',
        subject_line: data.subject_line || '',
        preheader_text: data.preheader_text || '',
        content_blocks: data.content_json || [],
        status: data.status || 'draft'
      });
    } catch (error) {
      console.error('Error loading campaign:', error);
      setMessage('Error loading campaign');
    }
  };

  const loadContacts = async () => {
    try {
      const { data, error } = await supabase
        .from('mail_contacts')
        .select('id, first_name, last_name, email, subscribed')
        .eq('business_id', businessId)
        .eq('subscribed', true)
        .order('first_name');

      if (error) throw error;
      setContacts(data || []);
    } catch (error) {
      console.error('Error loading contacts:', error);
    }
  };

  const loadDrafts = async () => {
    if (!businessId) return;
    
    setLoadingDrafts(true);
    try {
      const { data, error } = await supabase
        .from('mail_campaigns')
        .select('id, name, subject_line, created_at, updated_at')
        .eq('business_id', businessId)
        .eq('status', 'draft')
        .order('updated_at', { ascending: false });

      if (error) throw error;
      setDrafts(data || []);
    } catch (error) {
      console.error('Error loading drafts:', error);
      setMessage('Error loading drafts');
    } finally {
      setLoadingDrafts(false);
    }
  };

  const loadDraft = async (draftId) => {
    try {
      navigate(`/dashboard/mail/builder/${draftId}`);
      setShowDraftsModal(false);
    } catch (error) {
      console.error('Error loading draft:', error);
      setMessage('Error loading draft');
    }
  };

  const deleteDraft = async (draftId) => {
    if (!window.confirm('Are you sure you want to delete this draft?')) return;
    
    try {
      const { error } = await supabase
        .from('mail_campaigns')
        .delete()
        .eq('id', draftId)
        .eq('business_id', businessId);

      if (error) throw error;
      
      // Reload drafts list
      await loadDrafts();
      setMessage('Draft deleted successfully');
    } catch (error) {
      console.error('Error deleting draft:', error);
      setMessage('Error deleting draft');
    }
  };

  const handleInputChange = (field, value) => {
    setCampaign(prev => ({
      ...prev,
      [field]: value
    }));
    setMessage(''); // Clear any existing messages
  };

  const generateBlockId = () => {
    return Date.now().toString() + Math.random().toString(36).substr(2, 9);
  };

  const addContentBlock = (type, index = null) => {
    const newBlock = {
      id: generateBlockId(),
      type,
      content: getDefaultContent(type),
      settings: getDefaultSettings(type)
    };

    setCampaign(prev => {
      const newBlocks = [...prev.content_blocks];
      if (index !== null) {
        newBlocks.splice(index, 0, newBlock);
      } else {
        newBlocks.push(newBlock);
      }
      return { ...prev, content_blocks: newBlocks };
    });
  };

  const getDefaultContent = (type) => {
    switch (type) {
      case 'text':
        return 'Enter your text content here...';
      case 'heading':
        return 'Your Heading Here';
      case 'button':
        return { text: 'Click Here', url: '', style: 'primary' };
      case 'image':
        return { src: '', alt: '', width: '100%', alignment: 'center', url: '' };
      case 'divider':
        return { style: 'solid', color: '#ddd', width: '100%' };
      case 'social':
        return {
          platforms: [
            { name: 'facebook', url: '', enabled: true },
            { name: 'twitter', url: '', enabled: true },
            { name: 'instagram', url: '', enabled: true },
            { name: 'linkedin', url: '', enabled: false },
            { name: 'youtube', url: '', enabled: false }
          ],
          style: 'icons'
        };
      case 'spacer':
        return { height: '20px' };
      case 'columns':
        return {
          column1: 'Left column content...',
          column2: 'Right column content...'
        };
      default:
        return '';
    }
  };

  const getDefaultSettings = (type) => {
    switch (type) {
      case 'text':
        return { fontSize: '16px', color: '#333', textAlign: 'left', lineHeight: '1.6' };
      case 'heading':
        return { level: 'h2', fontSize: '24px', color: '#333', textAlign: 'left', fontWeight: 'bold' };
      case 'button':
        return { backgroundColor: 'teal', color: 'white', borderRadius: '6px', padding: '12px 24px', textAlign: 'center' };
      case 'image':
        return { borderRadius: '0px', margin: '15px 0' };
      case 'divider':
        return { margin: '20px 0' };
      case 'social':
        return { size: '32px', spacing: '10px', alignment: 'center' };
      case 'spacer':
        return { backgroundColor: 'transparent' };
      case 'columns':
        return { gap: '20px', alignment: 'top' };
      default:
        return {};
    }
  };

  const updateContentBlock = (blockId, updates) => {
    setCampaign(prev => ({
      ...prev,
      content_blocks: prev.content_blocks.map(block =>
        block.id === blockId ? { ...block, ...updates } : block
      )
    }));
  };

  const duplicateBlock = (blockId) => {
    setCampaign(prev => {
      const blockIndex = prev.content_blocks.findIndex(b => b.id === blockId);
      if (blockIndex === -1) return prev;

      const originalBlock = prev.content_blocks[blockIndex];
      const duplicatedBlock = {
        ...originalBlock,
        id: generateBlockId()
      };

      const newBlocks = [...prev.content_blocks];
      newBlocks.splice(blockIndex + 1, 0, duplicatedBlock);

      return { ...prev, content_blocks: newBlocks };
    });
  };

  const removeContentBlock = (blockId) => {
    setCampaign(prev => ({
      ...prev,
      content_blocks: prev.content_blocks.filter(block => block.id !== blockId)
    }));
  };

  const moveBlock = (fromIndex, toIndex) => {
    setCampaign(prev => {
      const newBlocks = [...prev.content_blocks];
      const [movedBlock] = newBlocks.splice(fromIndex, 1);
      newBlocks.splice(toIndex, 0, movedBlock);
      return { ...prev, content_blocks: newBlocks };
    });
  };

  const handleDragStart = (e, blockId, index) => {
    setDraggedBlock({ id: blockId, index });
    e.dataTransfer.effectAllowed = 'move';
  };

  const handleDragOver = (e, index) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    setDragOverIndex(index);
  };

  const handleDrop = (e, dropIndex) => {
    e.preventDefault();
    if (draggedBlock && draggedBlock.index !== dropIndex) {
      moveBlock(draggedBlock.index, dropIndex);
    }
    setDraggedBlock(null);
    setDragOverIndex(null);
  };

  const insertDynamicField = (blockId, field) => {
    const dynamicFields = {
      first_name: '{FirstName}',
      last_name: '{LastName}',
      email: '{Email}',
      full_name: '{FirstName} {LastName}'
    };

    updateContentBlock(blockId, {
      content: (prev) => {
        const currentContent = prev || '';
        return currentContent + ' ' + dynamicFields[field];
      }
    });
  };

  const validateCampaign = () => {
    const errors = [];

    if (!campaign.name.trim()) {
      errors.push('Campaign name is required');
    }

    if (!campaign.subject_line.trim()) {
      errors.push('Subject line is required');
    }

    if (campaign.content_blocks.length === 0) {
      errors.push('Campaign must have at least one content block');
    }

    // Check if unsubscribe link exists
    const hasUnsubscribe = campaign.content_blocks.some(block =>
      (block.type === 'text' && block.content.includes('{UnsubscribeLink}')) ||
      (block.type === 'button' && block.content.url && block.content.url.includes('unsubscribe'))
    );

    if (!hasUnsubscribe) {
      errors.push('Campaign must include an unsubscribe link for compliance');
    }

    return errors;
  };

  const handleSave = async () => {
    if (!businessId) {
      setMessage('No business selected');
      return;
    }

    setSaving(true);
    try {
      setMessage('');

      const campaignData = {
        business_id: businessId,
        name: campaign.name.trim(),
        subject_line: campaign.subject_line.trim(),
        preheader_text: campaign.preheader_text.trim(),
        content_json: campaign.content_blocks,
        content_html: generateEmailHTML(),
        status: campaign.status,
        updated_at: new Date().toISOString()
      };

      let result;
      if (isEditing) {
        result = await supabase
          .from('mail_campaigns')
          .update(campaignData)
          .eq('id', campaignId)
          .select()
          .single();
      } else {
        result = await supabase
          .from('mail_campaigns')
          .insert(campaignData)
          .select()
          .single();
      }

      if (result.error) throw result.error;

      setMessage('Campaign saved successfully');

      // If creating new campaign, navigate to edit mode
      if (!isEditing && result.data) {
        navigate(`/dashboard/mail/builder/${result.data.id}`);
      }

    } catch (error) {
      console.error('Error saving campaign:', error);
      setMessage('Error saving campaign: ' + error.message);
    } finally {
      setSaving(false);
    }
  };

  const handleSend = () => {
    const errors = validateCampaign();
    if (errors.length > 0) {
      setMessage('Please fix these issues before sending:\n' + errors.join('\n'));
      return;
    }
    setShowContactSelector(true);
  };

  const generateEmailHTML = () => {
    // Convert blocks to HTML - simplified for now
    const blockHTML = campaign.content_blocks.map(block => {
      switch (block.type) {
        case 'text':
          return `<p style="font-size: ${block.settings.fontSize}; color: ${block.settings.color}; text-align: ${block.settings.textAlign}; line-height: ${block.settings.lineHeight};">${block.content}</p>`;

        case 'heading':
          return `<${block.settings.level} style="font-size: ${block.settings.fontSize}; color: ${block.settings.color}; text-align: ${block.settings.textAlign}; font-weight: ${block.settings.fontWeight};">${block.content}</${block.settings.level}>`;

        case 'button':
          return `<div style="text-align: ${block.settings.textAlign}; margin: 20px 0;"><a href="${block.content.url}" style="background-color: ${block.settings.backgroundColor}; color: ${block.settings.color}; padding: ${block.settings.padding}; border-radius: ${block.settings.borderRadius}; text-decoration: none; display: inline-block;">${block.content.text}</a></div>`;

        case 'image':
          const imageHtml = `<img src="${block.content.src}" alt="${block.content.alt}" style="max-width: ${block.content.width}; width: ${block.content.width}; height: auto; border-radius: ${block.settings.borderRadius};" />`;
          const imageContent = block.content.url ? `<a href="${block.content.url}">${imageHtml}</a>` : imageHtml;
          return `<div style="text-align: ${block.content.alignment}; margin: ${block.settings.margin};">${imageContent}</div>`;

        case 'divider':
          return `<hr style="border: none; border-top: 1px ${block.content.style} ${block.content.color}; width: ${block.content.width}; margin: ${block.settings.margin};" />`;

        case 'spacer':
          return `<div style="height: ${block.content.height}; background-color: ${block.settings.backgroundColor};"></div>`;

        case 'social':
          const socialButtons = block.content.platforms
            .filter(platform => platform.enabled && platform.url)
            .map(platform => {
              const socialIcons = {
                facebook: '📘',
                twitter: '🐦',
                instagram: '📷',
                linkedin: '💼',
                youtube: '📺'
              };
              return `<a href="${platform.url}" style="display: inline-block; margin: 0 ${parseInt(block.settings.spacing)/2}px; text-decoration: none; font-size: ${block.settings.size};">${socialIcons[platform.name] || '🔗'}</a>`;
            }).join('');
          return `<div style="text-align: ${block.settings.alignment}; margin: 20px 0;">${socialButtons}</div>`;

        case 'columns':
          return `
            <table style="width: 100%; border-collapse: collapse;">
              <tr>
                <td style="width: 50%; padding-right: ${parseInt(block.settings.gap)/2}px; vertical-align: top;">
                  ${block.content.column1 || 'Left column content...'}
                </td>
                <td style="width: 50%; padding-left: ${parseInt(block.settings.gap)/2}px; vertical-align: top;">
                  ${block.content.column2 || 'Right column content...'}
                </td>
              </tr>
            </table>
          `;

        default:
          return '';
      }
    }).join('');

    return `
      <html>
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1">
        </head>
        <body style="margin: 0; padding: 20px; font-family: Arial, sans-serif; background-color: #f8f8f8;">
          <div style="max-width: 600px; margin: 0 auto; background-color: white; padding: 30px; border-radius: 8px;">
            ${blockHTML}
            <div style="margin-top: 40px; padding-top: 20px; border-top: 1px solid #eee; font-size: 12px; color: #999; text-align: center;">
              <p>You received this email because you subscribed to our mailing list.</p>
              <p><a href="{UnsubscribeLink}" style="color: #999;">Unsubscribe</a> | <a href="{UpdatePreferencesLink}" style="color: #999;">Update Preferences</a></p>
            </div>
          </div>
        </body>
      </html>
    `;
  };

  const renderContentBlock = (block, index) => {
    const isActive = false; // You could add active block selection later

    return (
      <div
        key={block.id}
        draggable
        onDragStart={(e) => handleDragStart(e, block.id, index)}
        onDragOver={(e) => handleDragOver(e, index)}
        onDrop={(e) => handleDrop(e, index)}
        style={{
          ...styles.contentBlock,
          ...(isActive ? styles.activeBlock : {}),
          ...(dragOverIndex === index ? styles.dragOverBlock : {})
        }}
      >
        <div style={styles.blockHeader}>
          <div style={styles.blockInfo}>
            <FiMove style={styles.dragHandle} />
            <span style={styles.blockType}>{block.type.charAt(0).toUpperCase() + block.type.slice(1)}</span>
          </div>
          <div style={styles.blockActions}>
            <button
              style={styles.blockActionButton}
              onClick={() => duplicateBlock(block.id)}
              title="Duplicate"
            >
              <FiCopy />
            </button>
            <button
              style={styles.blockActionButton}
              onClick={() => removeContentBlock(block.id)}
              title="Delete"
            >
              <FiTrash2 />
            </button>
          </div>
        </div>
        <div style={styles.blockContent}>
          {renderBlockEditor(block, index)}
        </div>
      </div>
    );
  };

  const renderBlockEditor = (block, index) => {
    switch (block.type) {
      case 'text':
        return (
          <div>
            <textarea
              style={styles.textEditor}
              value={block.content || ''}
              onChange={(e) => updateContentBlock(block.id, { content: e.target.value })}
              placeholder="Enter your text content..."
              rows={4}
            />
            <div style={styles.textControls}>
              <div style={styles.dynamicFields}>
                <span style={styles.dynamicFieldsLabel}>Insert:</span>
                {['first_name', 'last_name', 'email'].map(field => (
                  <button
                    key={field}
                    style={styles.dynamicFieldButton}
                    onClick={() => insertDynamicField(block.id, field)}
                  >
                    {field.replace('_', ' ')}
                  </button>
                ))}
              </div>
              <div style={styles.alignmentButtons}>
                <button
                  style={{
                    ...styles.alignmentButton,
                    ...(block.settings.textAlign === 'left' ? styles.activeAlignment : {})
                  }}
                  onClick={() => updateContentBlock(block.id, {
                    settings: { ...block.settings, textAlign: 'left' }
                  })}
                >
                  <FiAlignLeft />
                </button>
                <button
                  style={{
                    ...styles.alignmentButton,
                    ...(block.settings.textAlign === 'center' ? styles.activeAlignment : {})
                  }}
                  onClick={() => updateContentBlock(block.id, {
                    settings: { ...block.settings, textAlign: 'center' }
                  })}
                >
                  <FiAlignCenter />
                </button>
                <button
                  style={{
                    ...styles.alignmentButton,
                    ...(block.settings.textAlign === 'right' ? styles.activeAlignment : {})
                  }}
                  onClick={() => updateContentBlock(block.id, {
                    settings: { ...block.settings, textAlign: 'right' }
                  })}
                >
                  <FiAlignRight />
                </button>
              </div>
            </div>
          </div>
        );

      case 'heading':
        return (
          <div>
            <input
              type="text"
              style={styles.headingEditor}
              value={block.content || ''}
              onChange={(e) => updateContentBlock(block.id, { content: e.target.value })}
              placeholder="Enter heading text..."
            />
            <div style={styles.headingControls}>
              <select
                style={styles.headingLevelSelect}
                value={block.settings.level}
                onChange={(e) => updateContentBlock(block.id, {
                  settings: { ...block.settings, level: e.target.value }
                })}
              >
                <option value="h1">H1 - Large</option>
                <option value="h2">H2 - Medium</option>
                <option value="h3">H3 - Small</option>
              </select>
              <div style={styles.alignmentButtons}>
                <button
                  style={{
                    ...styles.alignmentButton,
                    ...(block.settings.textAlign === 'left' ? styles.activeAlignment : {})
                  }}
                  onClick={() => updateContentBlock(block.id, {
                    settings: { ...block.settings, textAlign: 'left' }
                  })}
                >
                  <FiAlignLeft />
                </button>
                <button
                  style={{
                    ...styles.alignmentButton,
                    ...(block.settings.textAlign === 'center' ? styles.activeAlignment : {})
                  }}
                  onClick={() => updateContentBlock(block.id, {
                    settings: { ...block.settings, textAlign: 'center' }
                  })}
                >
                  <FiAlignCenter />
                </button>
                <button
                  style={{
                    ...styles.alignmentButton,
                    ...(block.settings.textAlign === 'right' ? styles.activeAlignment : {})
                  }}
                  onClick={() => updateContentBlock(block.id, {
                    settings: { ...block.settings, textAlign: 'right' }
                  })}
                >
                  <FiAlignRight />
                </button>
              </div>
            </div>
          </div>
        );

      case 'button':
        return (
          <div style={styles.buttonEditor}>
            <input
              type="text"
              style={styles.input}
              placeholder="Button text"
              value={block.content.text}
              onChange={(e) => updateContentBlock(block.id, {
                content: { ...block.content, text: e.target.value }
              })}
            />
            <input
              type="url"
              style={styles.input}
              placeholder="Button URL (https://...)"
              value={block.content.url}
              onChange={(e) => updateContentBlock(block.id, {
                content: { ...block.content, url: e.target.value }
              })}
            />
            {block.content.url && (
              <div style={styles.testButtonContainer}>
                <button
                  type="button"
                  style={styles.testButton}
                  onClick={() => window.open(block.content.url, '_blank')}
                >
                  <FiLink style={styles.buttonIcon} />
                  Test Button Link
                </button>
              </div>
            )}
          </div>
        );

      case 'image':
        return (
          <div style={styles.imageEditor}>
            <div style={styles.formGroup}>
              <label style={styles.label}>Upload Image</label>
              <ImageUpload
                currentImage={block.content.src}
                onImageSelect={(url, filename) => {
                  updateContentBlock(block.id, {
                    content: {
                      ...block.content,
                      src: url,
                      alt: filename || block.content.alt
                    }
                  });
                }}
                businessId={businessId}
              />
            </div>
            <div style={styles.formGroup}>
              <label style={styles.label}>Alt Text (for accessibility)</label>
              <input
                type="text"
                style={styles.input}
                placeholder="Describe this image..."
                value={block.content.alt}
                onChange={(e) => updateContentBlock(block.id, {
                  content: { ...block.content, alt: e.target.value }
                })}
              />
            </div>
            <div style={styles.formGroup}>
              <label style={styles.label}>Link URL (optional)</label>
              <input
                type="url"
                style={styles.input}
                placeholder="https://example.com (optional)"
                value={block.content.url || ''}
                onChange={(e) => updateContentBlock(block.id, {
                  content: { ...block.content, url: e.target.value }
                })}
              />
            </div>
            <div style={styles.formGroup}>
              <label style={styles.label}>Image Alignment</label>
              <select
                style={styles.select}
                value={block.content.alignment}
                onChange={(e) => updateContentBlock(block.id, {
                  content: { ...block.content, alignment: e.target.value }
                })}
              >
                <option value="left">Left</option>
                <option value="center">Center</option>
                <option value="right">Right</option>
              </select>
            </div>
            <div style={styles.formGroup}>
              <label style={styles.label}>Image Width</label>
              <select
                style={styles.select}
                value={block.content.width}
                onChange={(e) => updateContentBlock(block.id, {
                  content: { ...block.content, width: e.target.value }
                })}
              >
                <option value="100%">Full Width</option>
                <option value="75%">75% Width</option>
                <option value="50%">Half Width</option>
                <option value="25%">Quarter Width</option>
                <option value="200px">Small (200px)</option>
                <option value="400px">Medium (400px)</option>
              </select>
            </div>
            {block.content.src && (
              <div style={styles.imagePreviewContainer}>
                <label style={styles.label}>Preview:</label>
                <div style={{ textAlign: block.content.alignment }}>
                  {block.content.url ? (
                    <div>
                      <img
                        src={block.content.src}
                        alt={block.content.alt || 'Preview'}
                        style={{
                          maxWidth: block.content.width,
                          width: block.content.width,
                          height: 'auto',
                          borderRadius: block.settings.borderRadius || '0px',
                          border: '1px solid #ddd',
                          cursor: 'pointer'
                        }}
                        onClick={() => window.open(block.content.url, '_blank')}
                      />
                      <div style={styles.linkIndicator}>
                        <FiLink style={{ fontSize: '12px', marginRight: '4px' }} />
                        Click image to test link: {block.content.url}
                      </div>
                    </div>
                  ) : (
                    <img
                      src={block.content.src}
                      alt={block.content.alt || 'Preview'}
                      style={{
                        maxWidth: block.content.width,
                        width: block.content.width,
                        height: 'auto',
                        borderRadius: block.settings.borderRadius || '0px',
                        border: '1px solid #ddd'
                      }}
                    />
                  )}
                </div>
              </div>
            )}
          </div>
        );

      case 'divider':
        return (
          <div style={styles.dividerEditor}>
            <select
              style={styles.select}
              value={block.content.style}
              onChange={(e) => updateContentBlock(block.id, {
                content: { ...block.content, style: e.target.value }
              })}
            >
              <option value="solid">Solid Line</option>
              <option value="dashed">Dashed Line</option>
              <option value="dotted">Dotted Line</option>
            </select>
            <input
              type="color"
              style={styles.colorInput}
              value={block.content.color}
              onChange={(e) => updateContentBlock(block.id, {
                content: { ...block.content, color: e.target.value }
              })}
            />
          </div>
        );

      case 'social':
        return (
          <div style={styles.socialEditor}>
            <SocialButtons
              platforms={block.content.platforms}
              size={block.settings.size}
              spacing={block.settings.spacing}
              alignment={block.settings.alignment}
              onPlatformChange={(newPlatforms) => {
                updateContentBlock(block.id, {
                  content: { ...block.content, platforms: newPlatforms }
                });
              }}
              isEditor={true}
            />
            <div style={styles.socialSettings}>
              <div style={styles.formGroup}>
                <label style={styles.label}>Alignment</label>
                <select
                  style={styles.select}
                  value={block.settings.alignment}
                  onChange={(e) => updateContentBlock(block.id, {
                    settings: { ...block.settings, alignment: e.target.value }
                  })}
                >
                  <option value="left">Left</option>
                  <option value="center">Center</option>
                  <option value="right">Right</option>
                </select>
              </div>
              <div style={styles.formGroup}>
                <label style={styles.label}>Button Size</label>
                <select
                  style={styles.select}
                  value={block.settings.size}
                  onChange={(e) => updateContentBlock(block.id, {
                    settings: { ...block.settings, size: e.target.value }
                  })}
                >
                  <option value="24px">Small</option>
                  <option value="32px">Medium</option>
                  <option value="40px">Large</option>
                </select>
              </div>
              <div style={styles.formGroup}>
                <label style={styles.label}>Button Spacing</label>
                <select
                  style={styles.select}
                  value={block.settings.spacing}
                  onChange={(e) => updateContentBlock(block.id, {
                    settings: { ...block.settings, spacing: e.target.value }
                  })}
                >
                  <option value="5px">Tight</option>
                  <option value="10px">Normal</option>
                  <option value="15px">Loose</option>
                </select>
              </div>
            </div>
          </div>
        );

      case 'columns':
        return (
          <div style={styles.columnsEditor}>
            <div style={styles.formGroup}>
              <label style={styles.label}>Two Column Layout</label>
              <div style={styles.columnsContainer}>
                <div style={styles.columnEditor}>
                  <label style={styles.columnLabel}>Left Column</label>
                  <textarea
                    style={styles.columnTextarea}
                    value={block.content.column1 || ''}
                    onChange={(e) => updateContentBlock(block.id, {
                      content: { ...block.content, column1: e.target.value }
                    })}
                    placeholder="Left column content..."
                    rows={4}
                  />
                </div>
                <div style={styles.columnEditor}>
                  <label style={styles.columnLabel}>Right Column</label>
                  <textarea
                    style={styles.columnTextarea}
                    value={block.content.column2 || ''}
                    onChange={(e) => updateContentBlock(block.id, {
                      content: { ...block.content, column2: e.target.value }
                    })}
                    placeholder="Right column content..."
                    rows={4}
                  />
                </div>
              </div>
            </div>
            <div style={styles.formGroup}>
              <label style={styles.label}>Column Gap</label>
              <select
                style={styles.select}
                value={block.settings.gap}
                onChange={(e) => updateContentBlock(block.id, {
                  settings: { ...block.settings, gap: e.target.value }
                })}
              >
                <option value="10px">Small Gap</option>
                <option value="20px">Medium Gap</option>
                <option value="30px">Large Gap</option>
              </select>
            </div>
          </div>
        );

      case 'spacer':
        return (
          <div style={styles.spacerEditor}>
            <label style={styles.label}>Height:</label>
            <input
              type="range"
              min="10"
              max="100"
              value={parseInt(block.content.height)}
              onChange={(e) => updateContentBlock(block.id, {
                content: { ...block.content, height: e.target.value + 'px' }
              })}
              style={styles.rangeInput}
            />
            <span style={styles.rangeValue}>{block.content.height}</span>
          </div>
        );

      default:
        return (
          <div style={styles.placeholderBlock}>
            <p>Block type "{block.type}" editor not implemented yet</p>
          </div>
        );
    }
  };

  const renderPreview = () => {
    return (
      <div style={{
        ...styles.previewContainer,
        ...(previewMode === 'mobile' ? styles.mobilePreview : styles.desktopPreview)
      }}>
        <div style={styles.emailPreview}>
          <div style={styles.emailHeader}>
            <div style={styles.emailSubject}>{campaign.subject_line || 'Subject Line'}</div>
            <div style={styles.emailFrom}>From: {business?.name || 'Your Business'}</div>
            {campaign.preheader_text && (
              <div style={styles.emailPreheader}>{campaign.preheader_text}</div>
            )}
          </div>
          <div style={styles.emailBody}>
            {campaign.content_blocks.map((block, index) => renderPreviewBlock(block, index))}
            {campaign.content_blocks.length === 0 && (
              <p style={styles.previewEmpty}>
                Your email content will appear here. Add content blocks to get started.
              </p>
            )}
          </div>
          <div style={styles.emailFooter}>
            <p style={styles.footerText}>
              You received this email because you subscribed to our mailing list.
            </p>
            <p style={styles.footerText}>
              <a href="#" style={styles.footerLink}>Unsubscribe</a> |
              <a href="#" style={styles.footerLink}>Update Preferences</a>
            </p>
          </div>
        </div>
      </div>
    );
  };

  const renderPreviewBlock = (block, index) => {
    switch (block.type) {
      case 'text':
        return (
          <p key={index} style={{
            fontSize: block.settings.fontSize,
            color: block.settings.color,
            textAlign: block.settings.textAlign,
            lineHeight: block.settings.lineHeight,
            margin: '15px 0'
          }}>
            {block.content || 'Text content will appear here...'}
          </p>
        );

      case 'heading':
        const HeadingTag = block.settings.level;
        return (
          <HeadingTag key={index} style={{
            fontSize: block.settings.fontSize,
            color: block.settings.color,
            textAlign: block.settings.textAlign,
            fontWeight: block.settings.fontWeight,
            margin: '20px 0 10px 0'
          }}>
            {block.content || 'Heading text will appear here...'}
          </HeadingTag>
        );

      case 'button':
        return (
          <div key={index} style={{ textAlign: block.settings.textAlign, margin: '20px 0' }}>
            <a
              href={block.content.url || '#'}
              style={{
                backgroundColor: block.settings.backgroundColor,
                color: block.settings.color,
                padding: block.settings.padding,
                borderRadius: block.settings.borderRadius,
                textDecoration: 'none',
                display: 'inline-block',
                fontWeight: 'bold'
              }}
            >
              {block.content.text || 'Button Text'}
            </a>
          </div>
        );

      case 'image':
        return block.content.src ? (
          <div key={index} style={{
            textAlign: block.content.alignment,
            margin: block.settings.margin || '15px 0'
          }}>
            {block.content.url ? (
              <a href={block.content.url} style={{ textDecoration: 'none' }}>
                <img
                  src={block.content.src}
                  alt={block.content.alt || 'Email image'}
                  style={{
                    maxWidth: block.content.width || '100%',
                    width: block.content.width || '100%',
                    height: 'auto',
                    borderRadius: block.settings.borderRadius || '0px',
                    display: 'block',
                    margin: block.content.alignment === 'center' ? '0 auto' :
                      block.content.alignment === 'right' ? '0 0 0 auto' : '0'
                  }}
                  onError={(e) => {
                    e.target.style.display = 'none';
                    e.target.parentNode.innerHTML = '<div style="padding: 20px; background: #f0f0f0; border: 1px dashed #ccc; text-align: center; color: #666;">Image failed to load</div>';
                  }}
                />
              </a>
            ) : (
              <img
                src={block.content.src}
                alt={block.content.alt || 'Email image'}
                style={{
                  maxWidth: block.content.width || '100%',
                  width: block.content.width || '100%',
                  height: 'auto',
                  borderRadius: block.settings.borderRadius || '0px',
                  display: 'block',
                  margin: block.content.alignment === 'center' ? '0 auto' :
                    block.content.alignment === 'right' ? '0 0 0 auto' : '0'
                }}
                onError={(e) => {
                  e.target.style.display = 'none';
                  e.target.parentNode.innerHTML = '<div style="padding: 20px; background: #f0f0f0; border: 1px dashed #ccc; text-align: center; color: #666;">Image failed to load</div>';
                }}
              />
            )}
          </div>
        ) : (
          <div key={index} style={styles.previewImagePlaceholder}>
            <FiImage style={{ fontSize: '24px', marginBottom: '8px' }} />
            <div>Click "Upload Image" to add an image</div>
          </div>
        );

      case 'divider':
        return (
          <hr key={index} style={{
            border: 'none',
            borderTop: `1px ${block.content.style} ${block.content.color}`,
            width: block.content.width,
            margin: block.settings.margin
          }} />
        );

      case 'social':
        const enabledPlatforms = block.content.platforms.filter(p => p.enabled && p.url);
        return enabledPlatforms.length > 0 ? (
          <SocialButtons
            key={index}
            platforms={block.content.platforms}
            size={block.settings.size}
            spacing={block.settings.spacing}
            alignment={block.settings.alignment}
            isEditor={false}
          />
        ) : (
          <div key={index} style={styles.previewSocialPlaceholder}>
            <FiShare2 style={{ fontSize: '24px', marginBottom: '8px' }} />
            <div>Add social media links to display buttons</div>
          </div>
        );

      case 'columns':
        return (
          <div key={index} style={{ margin: '20px 0' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse' }}>
              <tbody>
                <tr>
                  <td style={{
                    width: '50%',
                    paddingRight: `${parseInt(block.settings.gap)/2}px`,
                    verticalAlign: 'top',
                    borderRight: '1px solid #eee'
                  }}>
                    <div style={{ padding: '10px' }}>
                      {block.content.column1 || 'Left column content...'}
                    </div>
                  </td>
                  <td style={{
                    width: '50%',
                    paddingLeft: `${parseInt(block.settings.gap)/2}px`,
                    verticalAlign: 'top'
                  }}>
                    <div style={{ padding: '10px' }}>
                      {block.content.column2 || 'Right column content...'}
                    </div>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        );

      case 'spacer':
        return (
          <div key={index} style={{
            height: block.content.height,
            backgroundColor: block.settings.backgroundColor
          }} />
        );

      default:
        return null;
    }
  };

  return (
    <div style={styles.container}>
      {/* Header */}
      <div style={styles.header}>
        <h1 style={styles.title}>
          {isEditing ? 'Edit Campaign' : 'Create Campaign'}
        </h1>
        <div style={styles.headerActions}>
          <button
            style={styles.secondaryButton}
            onClick={() => setPreviewMode(previewMode === 'desktop' ? 'mobile' : 'desktop')}
          >
            {previewMode === 'desktop' ? <FiSmartphone /> : <FiMonitor />}
            {previewMode === 'desktop' ? 'Mobile' : 'Desktop'} Preview
          </button>
          <button
            style={styles.secondaryButton}
            onClick={handleSave}
            disabled={saving}
          >
            <FiSave style={styles.buttonIcon} />
            {saving ? 'Saving...' : 'Save'}
          </button>
          <button
            style={styles.secondaryButton}
            onClick={() => {
              setShowDraftsModal(true);
              loadDrafts(); // Load drafts when opening modal
            }}
          >
            <FiFileText style={styles.buttonIcon} />
            Drafts
          </button>
          <button
            style={styles.primaryButton}
            onClick={handleSend}
          >
            <FiSend style={styles.buttonIcon} />
            Send Campaign
          </button>
        </div>
      </div>

      {/* Message */}
      {message && (
        <div style={{
          ...styles.message,
          backgroundColor: message.includes('Error') || message.includes('fix') ? '#ffebee' : '#e8f5e8',
          color: message.includes('Error') || message.includes('fix') ? '#c62828' : '#2e7d32'
        }}>
          {message.split('\n').map((line, index) => (
            <div key={index}>{line}</div>
          ))}
        </div>
      )}

      {/* Main Content */}
      <div style={isMobile ? styles.contentMobile : styles.content}>
        {/* Preview Panel - Show first on mobile */}
        {isMobile && (
          <div style={styles.previewPanel}>
            <div style={styles.previewHeader}>
              <h2 style={styles.sectionTitle}>
                Preview ({previewMode === 'desktop' ? 'Desktop' : 'Mobile'})
              </h2>
            </div>
            {renderPreview()}
          </div>
        )}

        {/* Editor Panel */}
        <div style={styles.editorPanel}>
          {/* Campaign Settings */}
          <div style={styles.campaignSettings}>
            <h2 style={styles.sectionTitle}>Campaign Settings</h2>
            <div style={styles.formGroup}>
              <label style={styles.label}>Campaign Name *</label>
              <input
                type="text"
                style={styles.input}
                value={campaign.name}
                onChange={(e) => handleInputChange('name', e.target.value)}
                placeholder="e.g., Summer Special Offer"
              />
            </div>
            <div style={styles.formGroup}>
              <label style={styles.label}>Subject Line *</label>
              <input
                type="text"
                style={styles.input}
                value={campaign.subject_line}
                onChange={(e) => handleInputChange('subject_line', e.target.value)}
                placeholder="e.g., 🌞 Summer Fun Awaits!"
              />
            </div>
            <div style={styles.formGroup}>
              <label style={styles.label}>Preheader Text</label>
              <input
                type="text"
                style={styles.input}
                value={campaign.preheader_text}
                onChange={(e) => handleInputChange('preheader_text', e.target.value)}
                placeholder="Optional preview text that appears after subject line"
              />
            </div>
          </div>

          {/* Block Library */}
          <div style={styles.blockLibrary}>
            <h2 style={styles.sectionTitle}>Add Content Blocks</h2>
            <div style={styles.blockTypes}>
              {blockTypes.map(blockType => (
                <button
                  key={blockType.type}
                  style={styles.blockTypeButton}
                  onClick={() => addContentBlock(blockType.type)}
                  title={blockType.description}
                >
                  <blockType.icon style={styles.blockTypeIcon} />
                  <span style={styles.blockTypeLabel}>{blockType.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Content Editor */}
          <div style={styles.contentEditor}>
            <h2 style={styles.sectionTitle}>Email Content</h2>
            <div style={styles.contentBlocks}>
              {campaign.content_blocks.map((block, index) => renderContentBlock(block, index))}
              {campaign.content_blocks.length === 0 && (
                <div style={styles.emptyContent}>
                  <FiPlus style={styles.emptyIcon} />
                  <p style={styles.emptyText}>No content blocks yet.</p>
                  <p style={styles.emptySubtext}>Add your first block from the options above to get started.</p>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Preview Panel - Show second on desktop */}
        {!isMobile && (
          <div style={styles.previewPanel}>
            <div style={styles.previewHeader}>
              <h2 style={styles.sectionTitle}>
                Preview ({previewMode === 'desktop' ? 'Desktop' : 'Mobile'})
              </h2>
            </div>
            {renderPreview()}
          </div>
        )}
      </div>

      {/* Drafts Modal */}
      {showDraftsModal && (
        <div style={styles.modalOverlay}>
          <div style={styles.modal}>
            <div style={styles.modalHeader}>
              <h3 style={styles.modalTitle}>Campaign Drafts</h3>
              <button
                style={styles.modalClose}
                onClick={() => setShowDraftsModal(false)}
              >
                <FiX />
              </button>
            </div>
            <div style={styles.modalContent}>
              {loadingDrafts ? (
                <div style={styles.loadingState}>Loading drafts...</div>
              ) : drafts.length === 0 ? (
                <div style={styles.emptyDrafts}>
                  <FiFileText style={styles.emptyIcon} />
                  <p style={styles.emptyText}>No drafts found</p>
                  <p style={styles.emptySubtext}>Create a campaign and save it as a draft to see it here.</p>
                </div>
              ) : (
                <div style={styles.draftsList}>
                  {drafts.map(draft => (
                    <div key={draft.id} style={styles.draftItem}>
                      <div style={styles.draftInfo}>
                        <h4 style={styles.draftName}>{draft.name || 'Untitled Campaign'}</h4>
                        <p style={styles.draftSubject}>{draft.subject_line || 'No subject line'}</p>
                        <p style={styles.draftDate}>
                          Last updated: {new Date(draft.updated_at).toLocaleDateString()}
                        </p>
                      </div>
                      <div style={styles.draftActions}>
                        <button
                          style={styles.draftEditButton}
                          onClick={() => loadDraft(draft.id)}
                        >
                          <FiEdit3 style={styles.buttonIcon} />
                          Edit
                        </button>
                        <button
                          style={styles.draftDeleteButton}
                          onClick={() => deleteDraft(draft.id)}
                        >
                          <FiTrash2 style={styles.buttonIcon} />
                          Delete
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
            <div style={styles.modalActions}>
              <button
                style={styles.modalCancel}
                onClick={() => setShowDraftsModal(false)}
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Contact Selector Modal */}
      {showContactSelector && (
        <div style={styles.modalOverlay}>
          <div style={styles.modal}>
            <div style={styles.modalHeader}>
              <h3 style={styles.modalTitle}>Send Campaign</h3>
              <button
                style={styles.modalClose}
                onClick={() => setShowContactSelector(false)}
              >
                <FiX />
              </button>
            </div>
            <div style={styles.modalContent}>
              <p style={styles.modalText}>
                Campaign: <strong>{campaign.name}</strong><br/>
                Subject: <strong>{campaign.subject_line}</strong>
              </p>
              <div style={styles.recipientOptions}>
                <label style={styles.radioLabel}>
                  <input
                    type="radio"
                    name="recipients"
                    value="all"
                    checked={selectedContacts === 'all'}
                    onChange={(e) => setSelectedContacts(e.target.value)}
                  />
                  All subscribed contacts ({contacts.length})
                </label>
                <label style={styles.radioLabel}>
                  <input
                    type="radio"
                    name="recipients"
                    value="custom"
                    checked={selectedContacts === 'custom'}
                    onChange={(e) => setSelectedContacts(e.target.value)}
                  />
                  Select specific contacts
                </label>
              </div>
              {selectedContacts === 'custom' && (
                <div style={styles.contactSelector}>
                  <p style={styles.selectorNote}>Select contacts to receive this campaign:</p>
                  <div style={styles.contactList}>
                    {contacts.map(contact => (
                      <label key={contact.id} style={styles.contactCheckbox}>
                        <input
                          type="checkbox"
                          checked={customContactIds.includes(contact.id)}
                          onChange={(e) => {
                            if (e.target.checked) {
                              setCustomContactIds(prev => [...prev, contact.id]);
                            } else {
                              setCustomContactIds(prev => prev.filter(id => id !== contact.id));
                            }
                          }}
                        />
                        <span>{contact.first_name} {contact.last_name}</span>
                        <span style={styles.contactEmail}>{contact.email}</span>
                      </label>
                    ))}
                  </div>
                </div>
              )}
            </div>
            <div style={styles.modalActions}>
              <button
                style={styles.modalCancel}
                onClick={() => setShowContactSelector(false)}
              >
                Cancel
              </button>
              <button
                style={styles.modalSend}
                onClick={() => {
                  // TODO: Implement actual sending in next steps
                  alert(`Campaign would be sent to ${selectedContacts === 'all' ? contacts.length : customContactIds.length} contacts`);
                  setShowContactSelector(false);
                }}
              >
                <FiSend style={styles.buttonIcon} />
                Send Now
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default CampaignBuilder;