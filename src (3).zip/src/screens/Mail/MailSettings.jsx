// screens/Mail/MailSettings.jsx
import React from 'react';

const MailSettings = () => {
  return (
    <div style={{
      padding: '20px',
      backgroundColor: '#f8f8f8',
      minHeight: '100vh'
    }}>
      <h1>Mail Settings</h1>
      <p>This is the Mail Settings screen - working!</p>
    </div>
  );
};

export default MailSettings;