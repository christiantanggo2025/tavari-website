// screens/POS/PaymentScreen.jsx
import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { supabase } from '../../supabaseClient';
import { logAction } from '../../helpers/posAudit';

const PaymentScreen = () => {
  const navigate = useNavigate();
  const location = useLocation();
  
  // Authentication state - standardized pattern
  const [authUser, setAuthUser] = useState(null);
  const [selectedBusinessId, setSelectedBusinessId] = useState(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [authError, setAuthError] = useState(null);
  
  const [saleData, setSaleData] = useState(null);
  const [loyaltySettings, setLoyaltySettings] = useState(null);
  const [businessSettings, setBusinessSettings] = useState(null);
  const [payments, setPayments] = useState([]);
  const [currentPayment, setCurrentPayment] = useState({ method: 'cash', amount: '' });
  const [customMethodName, setCustomMethodName] = useState('');
  const [showCustomMethod, setShowCustomMethod] = useState(false);
  const [showManagerOverride, setShowManagerOverride] = useState(false);
  const [managerPin, setManagerPin] = useState('');
  const [overrideReason, setOverrideReason] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [tipAmount, setTipAmount] = useState(0);
  const [overrideError, setOverrideError] = useState('');
  const [autoLoyaltyApplied, setAutoLoyaltyApplied] = useState(0);
  const [availableLoyaltyCredit, setAvailableLoyaltyCredit] = useState(0);

  const receivedSaleData = location.state?.saleData;

  // Authentication and business context setup - standardized pattern
  useEffect(() => {
    const initializeAuth = async () => {
      try {
        console.log('PaymentScreen: Initializing authentication...');
        
        const { data: { session }, error } = await supabase.auth.getSession();
        console.log('PaymentScreen: Session check result:', { session: !!session, error });

        if (error || !session?.user) {
          console.error('PaymentScreen: No valid session, redirecting to login');
          navigate('/login');
          return;
        }

        setAuthUser(session.user);
        console.log('PaymentScreen: Authenticated as:', session.user.email);

        const currentBusinessId = localStorage.getItem('currentBusinessId');
        console.log('PaymentScreen: Business ID from localStorage:', currentBusinessId);

        if (!currentBusinessId) {
          setAuthError('No business selected');
          return;
        }

        setSelectedBusinessId(currentBusinessId);

        // Verify user has access to this business
        const { data: userRole, error: roleError } = await supabase
          .from('user_roles')
          .select('*')
          .eq('user_id', session.user.id)
          .eq('business_id', currentBusinessId)
          .eq('active', true)
          .single();

        if (roleError || !userRole) {
          console.error('PaymentScreen: User not authorized for this business:', roleError);
          setAuthError('Not authorized for this business');
          return;
        }

        console.log('PaymentScreen: User role verified:', userRole.role);
        setAuthLoading(false);

      } catch (err) {
        console.error('PaymentScreen: Authentication error:', err);
        setAuthError(err.message);
        setAuthLoading(false);
      }
    };

    initializeAuth();
  }, [navigate]);

  // Set up sale data immediately when we have business context
  useEffect(() => {
    if (selectedBusinessId && receivedSaleData) {
      console.log('PaymentScreen: Setting up sale data:', receivedSaleData);
      setSaleData(receivedSaleData);
      
      // Set tip if enabled
      if (receivedSaleData.businessSettings?.tip_enabled) {
        const defaultTip = (receivedSaleData.businessSettings.default_tip_percent || 0.15) * receivedSaleData.total_amount;
        setTipAmount(Math.round(defaultTip * 100) / 100);
      }

      logAction({
        action: 'payment_screen_opened',
        context: 'PaymentScreen',
        metadata: {
          sale_total: receivedSaleData.total_amount,
          item_count: receivedSaleData.item_count,
          customer_attached: !!receivedSaleData.loyaltyCustomer
        }
      });
    } else if (selectedBusinessId && !receivedSaleData) {
      setError('No sale data provided - please return to tabs and try again');
    }
  }, [selectedBusinessId, receivedSaleData]);

  // Load settings after authentication
  useEffect(() => {
    if (selectedBusinessId && authUser) {
      loadLoyaltySettings();
      loadBusinessSettings();
    }
  }, [selectedBusinessId, authUser]);

  const loadBusinessSettings = async () => {
    if (!selectedBusinessId) return;

    try {
      console.log('PaymentScreen: Loading business settings for:', selectedBusinessId);
      
      // Get basic business info
      const { data: businessInfo, error: businessError } = await supabase
        .from('businesses')
        .select('name')
        .eq('id', selectedBusinessId)
        .single();

      // Get POS settings if they exist
      const { data: posSettings, error: posError } = await supabase
        .from('pos_settings')
        .select('*')
        .eq('business_id', selectedBusinessId)
        .single();

      if (businessError && businessError.code !== 'PGRST116') {
        console.error('Error loading business info:', businessError);
      }

      const combinedSettings = {
        timezone: 'America/Toronto', // Default timezone
        name: businessInfo?.name || 'Business',
        tip_enabled: posSettings?.tip_enabled || false,
        default_tip_percent: posSettings?.default_tip_percent || 0.15,
        ...posSettings
      };

      console.log('PaymentScreen: Business settings loaded:', combinedSettings);
      setBusinessSettings(combinedSettings);
    } catch (err) {
      console.error('Failed to load business settings:', err);
      // Set defaults if loading fails
      setBusinessSettings({
        timezone: 'America/Toronto',
        name: 'Business',
        tip_enabled: false,
        default_tip_percent: 0.15
      });
    }
  };

  const loadLoyaltySettings = async () => {
    if (!selectedBusinessId) return;

    try {
      console.log('PaymentScreen: Loading loyalty settings for:', selectedBusinessId);
      
      const { data: settings, error } = await supabase
        .from('pos_loyalty_settings')
        .select('*')
        .eq('business_id', selectedBusinessId)
        .single();

      if (error && error.code !== 'PGRST116') {
        console.error('Error loading loyalty settings:', error);
      }

      // Set default settings if none exist
      const defaultSettings = {
        loyalty_mode: 'points',
        earn_rate_percentage: 1.0,
        auto_apply: 'customer_choice',
        max_redemption_per_day: 10000,
        min_redemption: 10000,
        expiry_months: 6,
        is_active: true,
        allow_partial_redemption: true,
        credits_expire: true,
        redemption_rate: 10000
      };

      const finalSettings = { ...defaultSettings, ...settings };
      console.log('PaymentScreen: Loyalty settings loaded:', finalSettings);
      setLoyaltySettings(finalSettings);
    } catch (err) {
      console.error('Failed to load loyalty settings:', err);
      // Set defaults if loading fails
      setLoyaltySettings({
        loyalty_mode: 'points',
        earn_rate_percentage: 1.0,
        auto_apply: 'customer_choice',
        max_redemption_per_day: 10000,
        min_redemption: 10000,
        expiry_months: 6,
        is_active: true,
        allow_partial_redemption: true,
        credits_expire: true,
        redemption_rate: 10000
      });
    }
  };

  // Calculate loyalty credits after saleData, settings, and business settings are loaded
  useEffect(() => {
    if (saleData && loyaltySettings && businessSettings && selectedBusinessId) {
      calculateLoyaltyCredits();
    }
  }, [saleData, loyaltySettings, businessSettings, selectedBusinessId]);

  // Helper function to get today's date in business timezone
  const getTodayInBusinessTimezone = () => {
    const businessTimezone = businessSettings?.timezone || 'America/Toronto';
    const today = new Date();
    
    // Convert to business timezone and get YYYY-MM-DD format
    const todayInBizTz = new Intl.DateTimeFormat('sv-SE', {
      timeZone: businessTimezone,
      year: 'numeric',
      month: '2-digit',
      day: '2-digit'
    }).format(today);
    
    return todayInBizTz;
  };

  const calculateLoyaltyCredits = async () => {
    if (!saleData?.loyaltyCustomer || !loyaltySettings?.is_active) {
      console.log('PaymentScreen: Skipping loyalty calculation - no customer or loyalty inactive');
      return;
    }

    try {
      console.log('Calculating loyalty for customer:', saleData.loyaltyCustomer);
      console.log('Using loyalty settings:', loyaltySettings);
      console.log('Business timezone:', businessSettings?.timezone);
      
      // Get today's date in business timezone
      const today = getTodayInBusinessTimezone();
      console.log('Today in business timezone:', today);
      
      // Get today's usage for this customer (stored in dollars)
      const { data: todayUsage } = await supabase
        .from('pos_loyalty_daily_usage')
        .select('amount_used')
        .eq('loyalty_account_id', saleData.loyaltyCustomer.id)
        .eq('usage_date', today)
        .single();

      const usedToday = todayUsage?.amount_used || 0;
      console.log('Used today:', usedToday);
      
      // Convert daily limit from display format to dollars
      let dailyLimitDollars;
      if (loyaltySettings.loyalty_mode === 'points') {
        // Convert points to dollars: 10,000 points = $10
        dailyLimitDollars = (loyaltySettings.max_redemption_per_day / loyaltySettings.redemption_rate) * 10;
      } else {
        dailyLimitDollars = loyaltySettings.max_redemption_per_day;
      }
      
      const remainingDailyLimit = Math.max(0, dailyLimitDollars - usedToday);
      
      // Customer balance is always stored in dollars
      const customerBalanceDollars = saleData.loyaltyCustomer.balance || 0;
      
      console.log('Customer balance (stored $):', customerBalanceDollars);
      console.log('Used today ($):', usedToday);
      console.log('Daily limit ($):', dailyLimitDollars);
      console.log('Remaining daily limit ($):', remainingDailyLimit);
      
      // Available credit is minimum of: customer balance, remaining daily limit, and sale amount
      const maxUsable = Math.min(customerBalanceDollars, remainingDailyLimit, saleData.total_amount);
      
      console.log('Max usable credit ($):', maxUsable);
      
      setAvailableLoyaltyCredit(Math.max(0, maxUsable));

      // Auto-apply based on settings
      let autoApplyAmount = 0;
      if (loyaltySettings.auto_apply === 'always') {
        // Convert minimum redemption from display format to dollars
        let minRedemptionDollars;
        if (loyaltySettings.loyalty_mode === 'points') {
          minRedemptionDollars = (loyaltySettings.min_redemption / loyaltySettings.redemption_rate) * 10;
        } else {
          minRedemptionDollars = loyaltySettings.min_redemption;
        }
        
        console.log('Min redemption ($):', minRedemptionDollars);
        
        if (maxUsable >= minRedemptionDollars) {
          if (loyaltySettings.allow_partial_redemption) {
            // Use maximum available up to daily limit and sale amount
            autoApplyAmount = Math.min(maxUsable, saleData.total_amount);
          } else {
            // Use minimum redemption amount if customer has enough
            autoApplyAmount = minRedemptionDollars;
          }
          console.log('Will auto-apply ($):', autoApplyAmount);
        } else {
          console.log('Customer balance below minimum redemption, no auto-apply');
        }
      }
      
      console.log('Auto-applying ($):', autoApplyAmount);
      setAutoLoyaltyApplied(autoApplyAmount);

    } catch (err) {
      console.error('Error calculating loyalty credits:', err);
      setAvailableLoyaltyCredit(0);
      setAutoLoyaltyApplied(0);
    }
  };

  // Helper function to display balance in correct format
  const getBalanceDisplay = (dollarAmount) => {
    if (!loyaltySettings) return '$0.00';
    
    if (loyaltySettings.loyalty_mode === 'points') {
      const points = Math.round(dollarAmount * loyaltySettings.redemption_rate / 10);
      return `${points} points`;
    }
    return `$${dollarAmount.toFixed(2)}`;
  };

  // Calculate totals with pre-tax loyalty discount
  const saleSubtotal = saleData?.subtotal || 0;
  const originalTaxAmount = saleData?.tax_amount || 0;
  const taxRate = saleSubtotal > 0 ? originalTaxAmount / saleSubtotal : 0;
  
  // Apply loyalty discount to subtotal first (pre-tax)
  const subtotalAfterLoyalty = Math.max(0, saleSubtotal - autoLoyaltyApplied);
  
  // Recalculate tax on reduced amount
  const recalculatedTax = Math.round(subtotalAfterLoyalty * taxRate * 100) / 100;
  
  const finalTotal = subtotalAfterLoyalty + recalculatedTax + tipAmount;
  const totalPaid = payments.reduce((sum, p) => sum + Number(p.amount), 0);
  const remainingBalance = finalTotal - totalPaid;
  const changeOwed = Math.max(0, totalPaid - finalTotal);

  // Payment method options
  const paymentMethods = [
    { id: 'cash', name: 'Cash', icon: '💵' },
    { id: 'card', name: 'Credit/Debit', icon: '💳' },
    { id: 'helcim', name: 'Helcim QR', icon: '📱' },
    { id: 'gift_card', name: 'Gift Card', icon: '🎁' },
    { id: 'custom', name: 'Custom Method', icon: '⚙️' }
  ];

  const quickCashAmounts = [5, 10, 20, 50, 100];

  const validateManagerPin = async (pin) => {
    if (!authUser || !selectedBusinessId) {
      console.log('No authenticated user or business');
      return false;
    }

    try {
      console.log('Validating PIN for user:', authUser.id, 'business:', selectedBusinessId);

      // Check if current user is a manager for this business using user_roles table
      const { data: userRoles, error } = await supabase
        .from('user_roles')
        .select('role')
        .eq('business_id', selectedBusinessId)
        .eq('user_id', authUser.id)
        .eq('active', true);

      if (error) {
        console.error('Role check error:', error);
        return false;
      }

      console.log('User roles found:', userRoles);

      const isManager = userRoles?.some(r => ['owner', 'manager'].includes(r.role));
      if (!isManager) {
        console.log('User is not a manager or owner');
        return false;
      }

      // Get user's PIN from database
      const { data: userData, error: userError } = await supabase
        .from('users')
        .select('pin')
        .eq('id', authUser.id)
        .single();

      if (userError) {
        console.error('User lookup error:', userError);
        return false;
      }

      console.log('Comparing PIN for validation');
      
      // Check if PIN is hashed (starts with $2b$ for bcrypt)
      const storedPin = userData?.pin;
      if (!storedPin) {
        console.log('No PIN found for user');
        return false;
      }

      if (storedPin.startsWith('$2b$') || storedPin.startsWith('$2a$')) {
        // PIN is bcrypt hashed - need to import bcrypt for comparison
        try {
          // Try to use bcrypt if available
          const bcrypt = await import('bcryptjs');
          const isValid = await bcrypt.compare(pin, storedPin);
          console.log('Bcrypt comparison result:', isValid);
          return isValid;
        } catch (bcryptError) {
          console.error('Bcrypt not available, trying plain comparison:', bcryptError);
          // Fallback to plain comparison (not secure but for testing)
          return String(pin) === String(storedPin);
        }
      } else {
        // PIN is plain text
        console.log('Using plain text PIN comparison');
        return String(pin) === String(storedPin);
      }
      
    } catch (err) {
      console.error('Manager PIN validation error:', err);
      return false;
    }
  };

  const handleAddPayment = async () => {
    const amount = Number(currentPayment.amount);
    
    if (!amount || amount <= 0) {
      setError('Please enter a valid payment amount');
      return;
    }

    if (amount > remainingBalance && currentPayment.method !== 'cash') {
      if (!showManagerOverride) {
        setShowManagerOverride(true);
        setOverrideReason('Overpayment detected - Manager approval required for non-cash overpayment');
        return;
      }
    }

    if (currentPayment.method === 'custom' && !customMethodName.trim()) {
      setError('Please enter a custom payment method name');
      return;
    }

    if (showManagerOverride) {
      const isValidPin = await validateManagerPin(managerPin);
      if (!isValidPin) {
        setOverrideError('Invalid manager PIN. Please try again.');
        return;
      }

      setOverrideError('');
      await logAction({
        action: 'manager_override_payment',
        context: 'PaymentScreen',
        metadata: { reason: overrideReason, amount, method: currentPayment.method }
      });
    }

    const newPayment = {
      id: Date.now(),
      method: currentPayment.method,
      amount,
      custom_method_name: currentPayment.method === 'custom' ? customMethodName : null,
      tip_amount: payments.length === 0 ? tipAmount : 0,
      timestamp: new Date().toISOString()
    };

    setPayments([...payments, newPayment]);
    
    const newRemainingBalance = remainingBalance - amount;
    setCurrentPayment({ 
      method: 'cash', 
      amount: newRemainingBalance > 0 ? newRemainingBalance.toFixed(2) : '' 
    });
    setCustomMethodName('');
    setShowCustomMethod(false);
    setShowManagerOverride(false);
    setManagerPin('');
    setOverrideReason('');
    setOverrideError('');
    setError(null);
  };

  const handleQuickCash = (amount) => {
    setCurrentPayment({ method: 'cash', amount: amount.toString() });
  };

  const handleExactAmount = () => {
    setCurrentPayment({ method: 'cash', amount: remainingBalance.toFixed(2) });
  };

  const handleTipPercentage = (percentage) => {
    const tip = saleSubtotal * percentage;
    setTipAmount(Math.round(tip * 100) / 100);
  };

  const finalizeSale = async () => {
    if (remainingBalance > 0.01) {
      setError('Payment incomplete. Please add more payments to cover the total.');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      if (!authUser) {
        throw new Error('User not authenticated');
      }

      // Create sale record with correct tax amounts
      const saleRecord = {
        business_id: selectedBusinessId,
        user_id: authUser.id,
        customer_id: saleData.loyaltyCustomer?.id || null,
        subtotal: saleSubtotal,
        tax: recalculatedTax,
        discount: saleData.discount_amount || 0,
        loyalty_discount: autoLoyaltyApplied,
        total: finalTotal,
        payment_status: 'completed',
        sale_number: `SALE-${Date.now()}`,
        notes: autoLoyaltyApplied > 0 ? `Auto-applied ${autoLoyaltyApplied.toFixed(2)} loyalty credit (pre-tax)` : null
      };

      const { data: sale, error: saleError } = await supabase
        .from('pos_sales')
        .insert(saleRecord)
        .select()
        .single();

      if (saleError) throw saleError;

      // Process loyalty redemption if applied (always store in dollars)
      if (autoLoyaltyApplied > 0 && saleData.loyaltyCustomer && loyaltySettings) {
        const today = getTodayInBusinessTimezone(); // Use business timezone
        
        // Record loyalty redemption (store in dollars)
        await supabase
          .from('pos_loyalty_transactions')
          .insert({
            business_id: selectedBusinessId,
            loyalty_account_id: saleData.loyaltyCustomer.id,
            transaction_id: sale.id,
            transaction_type: 'redeem',
            amount: autoLoyaltyApplied,
            description: `Redeemed for sale ${sale.sale_number}`,
            processed_by: authUser.id,
            earned_date: today
          });

        // Update daily usage (store in dollars) - USE BUSINESS TIMEZONE
        const { error: usageError } = await supabase
          .from('pos_loyalty_daily_usage')
          .upsert({
            business_id: selectedBusinessId,
            loyalty_account_id: saleData.loyaltyCustomer.id,
            usage_date: today, // This now uses business timezone
            amount_used: autoLoyaltyApplied
          }, {
            onConflict: 'business_id,loyalty_account_id,usage_date',
            ignoreDuplicates: false
          });

        if (usageError) {
          console.error('Daily usage update error:', usageError);
        }
      }

      // Award new loyalty points based on settings (always store in dollars)
      if (saleData.loyaltyCustomer && loyaltySettings?.is_active) {
        const earnRate = loyaltySettings.earn_rate_percentage / 100;
        
        // Always calculate earnings in dollars first
        const dollarCreditsEarned = Math.round((subtotalAfterLoyalty * earnRate) * 100) / 100;
        
        if (dollarCreditsEarned > 0) {
          const tomorrow = new Date();
          tomorrow.setDate(tomorrow.getDate() + 1);
          
          let expiryDate = null;
          if (loyaltySettings.credits_expire) {
            expiryDate = new Date();
            expiryDate.setMonth(expiryDate.getMonth() + loyaltySettings.expiry_months);
          }

          // Store earnings in dollars
          await supabase
            .from('pos_loyalty_transactions')
            .insert({
              business_id: selectedBusinessId,
              loyalty_account_id: saleData.loyaltyCustomer.id,
              transaction_id: sale.id,
              transaction_type: 'earn',
              amount: dollarCreditsEarned,
              description: `Earned from sale ${sale.sale_number}`,
              processed_by: authUser.id,
              earned_date: tomorrow.toISOString().split('T')[0],
              expires_at: expiryDate ? expiryDate.toISOString().split('T')[0] : null
            });

          // Update customer balance (always in dollars)
          const newBalance = (saleData.loyaltyCustomer.balance || 0) + dollarCreditsEarned - autoLoyaltyApplied;
          await supabase
            .from('pos_loyalty_accounts')
            .update({ 
              balance: newBalance,
              last_activity: new Date().toISOString()
            })
            .eq('id', saleData.loyaltyCustomer.id);
        }
      }

      navigate('/dashboard/pos/receipt', {
        state: {
          saleData: {
            ...saleData,
            sale_id: sale.id,
            sale_number: sale.sale_number,
            payments,
            tip_amount: tipAmount,
            change_given: changeOwed,
            final_total: finalTotal,
            loyalty_redeemed: autoLoyaltyApplied
          }
        }
      });

    } catch (err) {
      console.error('Sale finalization error:', err);
      setError(`Failed to complete sale: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  // Calculate earning preview
  const getEarningPreview = () => {
    if (!loyaltySettings?.is_active) return null;
    
    const earnRate = loyaltySettings.earn_rate_percentage / 100;
    const dollarsToEarn = Math.round((subtotalAfterLoyalty * earnRate) * 100) / 100;
    
    if (loyaltySettings.loyalty_mode === 'points') {
      const pointsToEarn = Math.round(dollarsToEarn * loyaltySettings.redemption_rate / 10);
      return `${pointsToEarn} points`;
    } else {
      return `$${dollarsToEarn.toFixed(2)}`;
    }
  };

  // Loading and error states for authentication
  if (authLoading) {
    return (
      <div style={{...styles.container, justifyContent: 'center', alignItems: 'center'}}>
        <h3>Loading Payment Screen...</h3>
        <p>Authenticating user and loading business data...</p>
      </div>
    );
  }

  if (authError) {
    return (
      <div style={{...styles.container, justifyContent: 'center', alignItems: 'center'}}>
        <h3>Authentication Error</h3>
        <p>{authError}</p>
        <button 
          style={styles.backButton}
          onClick={() => navigate('/login')}
        >
          Return to Login
        </button>
      </div>
    );
  }

  if (!receivedSaleData) {
    return (
      <div style={{...styles.container, justifyContent: 'center', alignItems: 'center'}}>
        <h3>No Sale Data</h3>
        <p>No sale data was provided. Please return to tabs and try again.</p>
        <button 
          style={styles.backButton}
          onClick={() => navigate('/dashboard/pos/tabs')}
        >
          Back to Tabs
        </button>
      </div>
    );
  }

  if (!saleData || !loyaltySettings || !businessSettings) {
    return (
      <div style={styles.container}>
        <div style={styles.loading}>
          Loading payment screen...
          <br />
          <small>Business ID: {selectedBusinessId || 'Not found'}</small>
          <br />
          <small>Sale Data: {saleData ? 'Loaded' : 'Missing'}</small>
          <br />
          <small>Loyalty Settings: {loyaltySettings ? 'Loaded' : 'Loading...'}</small>
          <br />
          <small>Business Settings: {businessSettings ? 'Loaded' : 'Loading...'}</small>
        </div>
      </div>
    );
  }

  return (
    <div style={styles.container}>
      <div style={styles.header}>
        <h2>Process Payment</h2>
        <p>Complete the payment for this sale</p>
        {saleData.loyaltyCustomer && loyaltySettings?.is_active && (
          <div style={styles.customerBanner}>
            Customer: {saleData.loyaltyCustomer.customer_name} 
            <br />
            Available: {getBalanceDisplay(availableLoyaltyCredit)} | 
            Total Balance: {getBalanceDisplay(saleData.loyaltyCustomer.balance || 0)}
          </div>
        )}
      </div>

      <div style={styles.content}>
        {/* Sale Summary */}
        <div style={styles.section}>
          <h3 style={styles.sectionTitle}>Payment Summary</h3>
          <div style={styles.summaryGrid}>
            <div style={styles.summaryItem}>
              <span>Subtotal:</span>
              <span>${saleSubtotal.toFixed(2)}</span>
            </div>
            {autoLoyaltyApplied > 0 && (
              <div style={styles.summaryItemLoyalty}>
                <span>Auto Loyalty Credit:</span>
                <span>-${autoLoyaltyApplied.toFixed(2)}</span>
              </div>
            )}
            <div style={styles.summaryItem}>
              <span>Taxable Amount:</span>
              <span>${subtotalAfterLoyalty.toFixed(2)}</span>
            </div>
            <div style={styles.summaryItem}>
              <span>Tax ({(taxRate * 100).toFixed(1)}%):</span>
              <span>${recalculatedTax.toFixed(2)}</span>
            </div>
            {tipAmount > 0 && (
              <div style={styles.summaryItem}>
                <span>Tip:</span>
                <span>${tipAmount.toFixed(2)}</span>
              </div>
            )}
            <div style={styles.summaryItemTotal}>
              <span>Final Total:</span>
              <span>${finalTotal.toFixed(2)}</span>
            </div>
            <div style={styles.summaryItem}>
              <span>Total Paid:</span>
              <span>${totalPaid.toFixed(2)}</span>
            </div>
            <div style={{
              ...styles.summaryItemRemaining,
              color: remainingBalance > 0 ? '#dc2626' : '#059669'
            }}>
              <span>Remaining:</span>
              <span>${remainingBalance.toFixed(2)}</span>
            </div>
            {saleData.loyaltyCustomer && loyaltySettings?.is_active && (
              <div style={styles.summaryItemEarn}>
                <span>Points Earned:</span>
                <span>{getEarningPreview()}</span>
              </div>
            )}
          </div>
        </div>

        {/* Tip Section */}
        <div style={styles.section}>
          <h3 style={styles.sectionTitle}>Tip Amount</h3>
          <div style={styles.tipControls}>
            <button 
              style={styles.tipButton}
              onClick={() => setTipAmount(0)}
            >
              No Tip
            </button>
            <button 
              style={styles.tipButton}
              onClick={() => handleTipPercentage(0.15)}
            >
              15%
            </button>
            <button 
              style={styles.tipButton}
              onClick={() => handleTipPercentage(0.18)}
            >
              18%
            </button>
            <button 
              style={styles.tipButton}
              onClick={() => handleTipPercentage(0.20)}
            >
              20%
            </button>
            <input
              type="number"
              value={tipAmount}
              onChange={(e) => {
                const newTip = Number(e.target.value) || 0;
                setTipAmount(Math.max(0, Math.round(newTip * 100) / 100));
              }}
              style={styles.tipInput}
              placeholder="Custom tip"
              step="0.01"
              min="0"
              onFocus={(e) => e.target.select()}
            />
          </div>
        </div>

        <div style={styles.section}>
          <h3 style={styles.sectionTitle}>Add Payment</h3>
          
          <div style={styles.paymentMethods}>
            {paymentMethods.map(method => (
              <button
                key={method.id}
                style={{
                  ...styles.methodButton,
                  ...(currentPayment.method === method.id ? styles.methodButtonActive : {})
                }}
                onClick={() => {
                  setCurrentPayment({ 
                    method: method.id, 
                    amount: remainingBalance > 0 ? remainingBalance.toFixed(2) : ''
                  });
                  setShowCustomMethod(method.id === 'custom');
                }}
              >
                <span style={styles.methodIcon}>{method.icon}</span>
                <span>{method.name}</span>
              </button>
            ))}
          </div>

          {showCustomMethod && (
            <div style={styles.customMethodInput}>
              <input
                type="text"
                value={customMethodName}
                onChange={(e) => setCustomMethodName(e.target.value)}
                placeholder="Enter payment method name"
                style={styles.input}
              />
            </div>
          )}

          <div style={styles.amountSection}>
            <input
              type="number"
              value={currentPayment.amount}
              onChange={(e) => setCurrentPayment({ ...currentPayment, amount: e.target.value })}
              placeholder={`Payment amount (${remainingBalance.toFixed(2)} remaining)`}
              style={styles.amountInput}
              step="0.01"
              min="0"
              onFocus={(e) => e.target.select()}
            />
            
            {currentPayment.method === 'cash' && (
              <div style={styles.quickCash}>
                {quickCashAmounts.map(amount => (
                  <button
                    key={amount}
                    style={styles.quickCashButton}
                    onClick={() => handleQuickCash(amount)}
                  >
                    ${amount}
                  </button>
                ))}
                <button
                  style={styles.quickCashButton}
                  onClick={handleExactAmount}
                >
                  Exact
                </button>
              </div>
            )}
            
            {currentPayment.method === 'helcim' && (
              <div style={styles.helcimInstructions}>
                <p>Present QR code to customer or enter amount on Helcim terminal</p>
              </div>
            )}
          </div>

          <button
            style={styles.addPaymentButton}
            onClick={handleAddPayment}
            disabled={!currentPayment.amount || Number(currentPayment.amount) <= 0}
          >
            Add Payment
          </button>
        </div>

        {error && (
          <div style={styles.errorBanner}>
            {error}
          </div>
        )}
      </div>

      {/* Manager Override Modal */}
      {showManagerOverride && (
        <div style={styles.modal}>
          <div style={styles.modalContent}>
            <div style={styles.modalHeader}>
              <h3>Manager Override Required</h3>
              <button
                style={styles.closeModalButton}
                onClick={() => {
                  setShowManagerOverride(false);
                  setManagerPin('');
                  setOverrideError('');
                }}
              >
                ×
              </button>
            </div>
            
            <p>{overrideReason}</p>
            
            <div style={styles.form}>
              <div style={styles.formGroup}>
                <label style={styles.label}>Manager PIN</label>
                <input
                  type="password"
                  value={managerPin}
                  onChange={(e) => setManagerPin(e.target.value)}
                  placeholder="Enter manager PIN"
                  style={styles.input}
                  autoFocus
                />
              </div>
              {overrideError && (
                <div style={styles.overrideError}>{overrideError}</div>
              )}
            </div>
            
            <div style={styles.modalActions}>
              <button
                style={styles.cancelButton}
                onClick={() => {
                  setShowManagerOverride(false);
                  setManagerPin('');
                  setOverrideError('');
                }}
              >
                Cancel
              </button>
              <button
                style={styles.submitButton}
                onClick={handleAddPayment}
                disabled={!managerPin}
              >
                Approve Override
              </button>
            </div>
          </div>
        </div>
      )}

      <div style={styles.actions}>
        <button
          style={styles.backButton}
          onClick={() => navigate('/dashboard/pos/tabs')}
          disabled={loading}
        >
          Back to Tabs
        </button>
        
        <button
          style={{
            ...styles.completeButton,
            ...(remainingBalance > 0.01 || loading ? styles.completeButtonDisabled : {})
          }}
          onClick={finalizeSale}
          disabled={remainingBalance > 0.01 || loading}
        >
          {loading ? 'Processing...' : 
           remainingBalance > 0.01 ? `${remainingBalance.toFixed(2)} Remaining` : 
           'Complete Sale'}
        </button>
      </div>
    </div>
  );
};

const styles = {
  container: {
    display: 'flex',
    flexDirection: 'column',
    height: '100vh',
    backgroundColor: '#f8f9fa',
    padding: '20px',
    paddingTop: '100px',
    boxSizing: 'border-box'
  },
  header: {
    marginBottom: '30px',
    textAlign: 'center'
  },
  customerBanner: {
    backgroundColor: '#008080',
    color: 'white',
    padding: '10px',
    borderRadius: '6px',
    marginTop: '10px',
    fontSize: '14px',
    fontWeight: 'bold'
  },
  content: {
    flex: 1,
    overflowY: 'auto',
    marginBottom: '20px'
  },
  section: {
    backgroundColor: 'white',
    borderRadius: '8px',
    padding: '20px',
    marginBottom: '20px',
    border: '1px solid #e5e7eb'
  },
  sectionTitle: {
    margin: '0 0 15px 0',
    fontSize: '18px',
    fontWeight: 'bold',
    color: '#1f2937',
    borderBottom: '2px solid #008080',
    paddingBottom: '8px'
  },
  summaryGrid: {
    display: 'flex',
    flexDirection: 'column',
    gap: '8px'
  },
  summaryItem: {
    display: 'flex',
    justifyContent: 'space-between',
    fontSize: '16px',
    color: '#1f2937'
  },
  summaryItemTotal: {
    display: 'flex',
    justifyContent: 'space-between',
    fontSize: '18px',
    fontWeight: 'bold',
    color: '#1f2937',
    paddingTop: '8px',
    borderTop: '1px solid #e5e7eb'
  },
  summaryItemRemaining: {
    display: 'flex',
    justifyContent: 'space-between',
    fontSize: '16px',
    fontWeight: 'bold'
  },
  summaryItemLoyalty: {
    display: 'flex',
    justifyContent: 'space-between',
    fontSize: '16px',
    fontWeight: 'bold',
    color: '#059669',
    backgroundColor: '#d1fae5',
    padding: '6px 8px',
    borderRadius: '4px'
  },
  summaryItemEarn: {
    display: 'flex',
    justifyContent: 'space-between',
    fontSize: '14px',
    fontWeight: 'bold',
    color: '#f59e0b',
    backgroundColor: '#fef3c7',
    padding: '6px 8px',
    borderRadius: '4px'
  },
  tipControls: {
    display: 'flex',
    gap: '10px',
    flexWrap: 'wrap',
    alignItems: 'center'
  },
  tipButton: {
    padding: '8px 12px',
    backgroundColor: 'white',
    color: '#008080',
    border: '2px solid #008080',
    borderRadius: '6px',
    cursor: 'pointer',
    fontSize: '14px',
    fontWeight: 'bold'
  },
  tipInput: {
    padding: '8px',
    border: '2px solid #008080',
    borderRadius: '6px',
    fontSize: '14px',
    width: '100px'
  },
  paymentMethods: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fit, minmax(150px, 1fr))',
    gap: '10px',
    marginBottom: '15px'
  },
  methodButton: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    padding: '15px',
    backgroundColor: 'white',
    color: '#008080',
    border: '2px solid #008080',
    borderRadius: '8px',
    cursor: 'pointer',
    fontSize: '14px',
    fontWeight: 'bold',
    transition: 'all 0.2s ease'
  },
  methodButtonActive: {
    backgroundColor: '#008080',
    color: 'white'
  },
  methodIcon: {
    fontSize: '24px',
    marginBottom: '8px'
  },
  customMethodInput: {
    marginBottom: '15px'
  },
  amountSection: {
    marginBottom: '15px'
  },
  amountInput: {
    width: '100%',
    padding: '12px',
    border: '2px solid #008080',
    borderRadius: '6px',
    fontSize: '18px',
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: '10px'
  },
  quickCash: {
    display: 'flex',
    gap: '8px',
    flexWrap: 'wrap',
    marginBottom: '10px'
  },
  quickCashButton: {
    padding: '8px 12px',
    backgroundColor: '#f3f4f6',
    color: '#374151',
    border: '1px solid #d1d5db',
    borderRadius: '4px',
    cursor: 'pointer',
    fontSize: '14px',
    fontWeight: 'bold'
  },
  helcimInstructions: {
    backgroundColor: '#e0f2fe',
    padding: '10px',
    borderRadius: '4px',
    fontSize: '14px',
    color: '#0369a1',
    textAlign: 'center'
  },
  addPaymentButton: {
    width: '100%',
    padding: '12px',
    backgroundColor: '#008080',
    color: 'white',
    border: 'none',
    borderRadius: '6px',
    fontSize: '16px',
    fontWeight: 'bold',
    cursor: 'pointer'
  },
  input: {
    width: '100%',
    padding: '12px',
    border: '2px solid #d1d5db',
    borderRadius: '6px',
    fontSize: '16px'
  },
  errorBanner: {
    backgroundColor: '#fee2e2',
    color: '#dc2626',
    padding: '15px',
    borderRadius: '6px',
    marginBottom: '15px',
    border: '1px solid #fecaca'
  },
  modal: {
    position: 'fixed',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0,0,0,0.5)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 1000
  },
  modalContent: {
    backgroundColor: 'white',
    padding: '30px',
    borderRadius: '12px',
    maxWidth: '500px',
    width: '90%',
    maxHeight: '90vh',
    overflowY: 'auto'
  },
  modalHeader: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: '25px',
    paddingBottom: '15px',
    borderBottom: '2px solid #008080'
  },
  closeModalButton: {
    backgroundColor: 'transparent',
    border: 'none',
    fontSize: '24px',
    cursor: 'pointer',
    color: '#6b7280'
  },
  form: {
    display: 'flex',
    flexDirection: 'column',
    gap: '20px'
  },
  formGroup: {
    display: 'flex',
    flexDirection: 'column'
  },
  label: {
    fontSize: '14px',
    fontWeight: 'bold',
    color: '#374151',
    marginBottom: '6px'
  },
  overrideError: {
    backgroundColor: '#fee2e2',
    color: '#dc2626',
    padding: '10px',
    borderRadius: '6px',
    fontSize: '14px'
  },
  modalActions: {
    display: 'flex',
    gap: '15px',
    marginTop: '25px'
  },
  cancelButton: {
    flex: 1,
    padding: '12px',
    backgroundColor: '#6b7280',
    color: 'white',
    border: 'none',
    borderRadius: '6px',
    cursor: 'pointer',
    fontSize: '16px',
    fontWeight: 'bold'
  },
  submitButton: {
    flex: 1,
    padding: '12px',
    backgroundColor: '#008080',
    color: 'white',
    border: 'none',
    borderRadius: '6px',
    cursor: 'pointer',
    fontSize: '16px',
    fontWeight: 'bold'
  },
  actions: {
    display: 'flex',
    gap: '15px',
    justifyContent: 'space-between'
  },
  backButton: {
    flex: 1,
    padding: '15px',
    backgroundColor: '#6b7280',
    color: 'white',
    border: 'none',
    borderRadius: '8px',
    fontSize: '16px',
    fontWeight: 'bold',
    cursor: 'pointer'
  },
  completeButton: {
    flex: 2,
    padding: '15px',
    backgroundColor: '#008080',
    color: 'white',
    border: 'none',
    borderRadius: '8px',
    fontSize: '16px',
    fontWeight: 'bold',
    cursor: 'pointer'
  },
  completeButtonDisabled: {
    backgroundColor: '#ccc',
    cursor: 'not-allowed',
    color: '#666'
  },
  loading: {
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'center',
    alignItems: 'center',
    height: '200px',
    fontSize: '18px',
    color: '#6b7280',
    textAlign: 'center',
    lineHeight: '1.6'
  }
};

export default PaymentScreen;