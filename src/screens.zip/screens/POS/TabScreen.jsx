// screens/POS/TabScreen.jsx
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../../supabaseClient';
import { logAction } from '../../helpers/posAudit';
import BarcodeScanHandler from '../../components/POS/BarcodeScanHandler';
import CreateTabModal from '../../components/POS/CreateTabModal';
import ItemSelectionModal from '../../components/POS/ItemSelectionModal';
import CustomerSelectionModal from '../../components/POS/CustomerSelectionModal';
import { ManagerOverrideModal, TabDetailsModal, QRManualInputModal, QRScannerModal } from '../../components/POS/TabScreenModals';

const TabScreen = () => {
  const navigate = useNavigate();
  
  // Authentication state
  const [authUser, setAuthUser] = useState(null);
  const [selectedBusinessId, setSelectedBusinessId] = useState(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [authError, setAuthError] = useState(null);
  
  const [tabs, setTabs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedTab, setSelectedTab] = useState(null);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showTabDetails, setShowTabDetails] = useState(false);
  const [showItemSelectionModal, setShowItemSelectionModal] = useState(false);
  const [showCustomerSelectionModal, setShowCustomerSelectionModal] = useState(false);
  const [selectedPaymentTab, setSelectedPaymentTab] = useState(null);
  const [selectedItems, setSelectedItems] = useState([]);
  const [paymentCustomer, setPaymentCustomer] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [qrSearchValue, setQrSearchValue] = useState('');
  const [sortBy, setSortBy] = useState('updated_at');
  const [sortOrder, setSortOrder] = useState('desc');
  const [showSearchScanner, setShowSearchScanner] = useState(false);
  const [showQRManualInput, setShowQRManualInput] = useState(false);

  // Manager override for tab operations
  const [showManagerOverride, setShowManagerOverride] = useState(false);
  const [managerPin, setManagerPin] = useState('');
  const [overrideReason, setOverrideReason] = useState('');
  const [pendingAction, setPendingAction] = useState(null);

  // Helper function to format currency
  const formatCurrency = (amount) => {
    return `$${(Number(amount) || 0).toFixed(2)}`;
  };

  // Helper function to format balance display
  const getBalanceDisplay = (balance) => {
    return formatCurrency(balance);
  };

  // Authentication and business context setup
  useEffect(() => {
    const initializeAuth = async () => {
      try {
        console.log('TabScreen: Initializing authentication...');
        
        const { data: { session }, error } = await supabase.auth.getSession();
        console.log('TabScreen: Session check result:', { session: !!session, error });

        if (error || !session?.user) {
          console.error('TabScreen: No valid session, redirecting to login');
          navigate('/login');
          return;
        }

        setAuthUser(session.user);
        console.log('TabScreen: Authenticated as:', session.user.email);

        const currentBusinessId = localStorage.getItem('currentBusinessId');
        console.log('TabScreen: Business ID from localStorage:', currentBusinessId);

        if (!currentBusinessId) {
          setAuthError('No business selected');
          return;
        }

        setSelectedBusinessId(currentBusinessId);

        // Verify user has access to this business
        const { data: userRole, error: roleError } = await supabase
          .from('user_roles')
          .select('*')
          .eq('user_id', session.user.id)
          .eq('business_id', currentBusinessId)
          .eq('active', true)
          .single();

        if (roleError || !userRole) {
          console.error('TabScreen: User not authorized for this business:', roleError);
          setAuthError('Not authorized for this business');
          return;
        }

        console.log('TabScreen: User role verified:', userRole.role);
        setAuthLoading(false);

      } catch (err) {
        console.error('TabScreen: Authentication error:', err);
        setAuthError(err.message);
        setAuthLoading(false);
      }
    };

    initializeAuth();
  }, [navigate]);

  useEffect(() => {
    if (selectedBusinessId) {
      loadTabs();
      // Set up real-time subscription
      const subscription = supabase
        .channel(`pos_tabs_${selectedBusinessId}`)
        .on('postgres_changes', 
          { event: '*', schema: 'public', table: 'pos_tabs', filter: `business_id=eq.${selectedBusinessId}` },
          loadTabs
        )
        .subscribe();

      return () => {
        supabase.removeChannel(subscription);
      };
    }
  }, [selectedBusinessId]);

  const loadTabs = async () => {
    if (!selectedBusinessId) return;

    try {
      setLoading(true);
      setError(null);

      const { data, error: tabError } = await supabase
        .from('pos_tabs')
        .select(`
          *,
          pos_tab_items (
            id, name, quantity, unit_price, total_price, modifiers, notes
          )
        `)
        .eq('business_id', selectedBusinessId)
        .in('status', ['open', 'partial'])
        .order(sortBy, { ascending: sortOrder === 'asc' });

      if (tabError) throw tabError;

      // Load loyalty account information and recalculate totals
      const tabsWithLoyalty = await Promise.all((data || []).map(async (tab) => {
        let updatedTab = { ...tab };

        // Recalculate totals from tab items if items exist but totals are 0
        if (tab.pos_tab_items && tab.pos_tab_items.length > 0) {
          const itemsSubtotal = tab.pos_tab_items.reduce((sum, item) => sum + (Number(item.total_price) || 0), 0);
          
          // If tab shows $0 but has items, recalculate
          if ((Number(tab.subtotal) || 0) === 0 && itemsSubtotal > 0) {
            console.log(`Tab ${tab.tab_number} has items but $0 totals, recalculating...`);
            
            // Calculate tax (assuming 13% HST for now - should get from settings)
            const taxAmount = itemsSubtotal * 0.13;
            const totalAmount = itemsSubtotal + taxAmount;
            const balanceRemaining = totalAmount - (Number(tab.amount_paid) || 0);

            // Update the tab in database
            const { error: updateError } = await supabase
              .from('pos_tabs')
              .update({
                subtotal: itemsSubtotal,
                tax_amount: taxAmount,
                total_amount: totalAmount,
                balance_remaining: balanceRemaining,
                updated_at: new Date().toISOString()
              })
              .eq('id', tab.id);

            if (!updateError) {
              updatedTab = {
                ...tab,
                subtotal: itemsSubtotal,
                tax_amount: taxAmount,
                total_amount: totalAmount,
                balance_remaining: balanceRemaining
              };
            }
          }
        }

        // Load loyalty account if needed
        if (updatedTab.loyalty_customer_id) {
          const { data: loyaltyAccount } = await supabase
            .from('pos_loyalty_accounts')
            .select('id, customer_name, customer_email, customer_phone, balance')
            .eq('id', updatedTab.loyalty_customer_id)
            .eq('business_id', selectedBusinessId)
            .single();
          
          return { ...updatedTab, pos_loyalty_accounts: loyaltyAccount };
        }
        
        return updatedTab;
      }));

      setTabs(tabsWithLoyalty || []);
    } catch (err) {
      console.error('Error loading tabs:', err);
      setError('Failed to load tabs: ' + err.message);
    } finally {
      setLoading(false);
    }
  };

  const validateManagerPin = async (pin) => {
    if (!authUser || !selectedBusinessId) {
      console.log('No authenticated user or business');
      return false;
    }

    try {
      console.log('Validating PIN for user:', authUser.id, 'business:', selectedBusinessId);

      // Check if current user is a manager for this business using user_roles table
      const { data: userRoles, error } = await supabase
        .from('user_roles')
        .select('role')
        .eq('business_id', selectedBusinessId)
        .eq('user_id', authUser.id)
        .eq('active', true);

      if (error) {
        console.error('Role check error:', error);
        return false;
      }

      console.log('User roles found:', userRoles);

      const isManager = userRoles?.some(r => ['owner', 'manager'].includes(r.role));
      if (!isManager) {
        console.log('User is not a manager or owner');
        return false;
      }

      // Get user's PIN from database
      const { data: userData, error: userError } = await supabase
        .from('users')
        .select('pin')
        .eq('id', authUser.id)
        .single();

      if (userError) {
        console.error('User lookup error:', userError);
        return false;
      }

      console.log('Comparing PIN for validation');
      
      // Check if PIN is hashed (starts with $2b$ for bcrypt)
      const storedPin = userData?.pin;
      if (!storedPin) {
        console.log('No PIN found for user');
        return false;
      }

      if (storedPin.startsWith('$2b$') || storedPin.startsWith('$2a$')) {
        // PIN is bcrypt hashed - need to import bcrypt for comparison
        try {
          // Try to use bcrypt if available
          const bcrypt = await import('bcryptjs');
          const isValid = await bcrypt.compare(pin, storedPin);
          console.log('Bcrypt comparison result:', isValid);
          return isValid;
        } catch (bcryptError) {
          console.error('Bcrypt not available, trying plain comparison:', bcryptError);
          // Fallback to plain comparison (not secure but for testing)
          return String(pin) === String(storedPin);
        }
      } else {
        // PIN is plain text
        console.log('Using plain text PIN comparison');
        return String(pin) === String(storedPin);
      }
      
    } catch (err) {
      console.error('Manager PIN validation error:', err);
      return false;
    }
  };

  const handleManagerOverride = async (pin) => {
    const isValidPin = await validateManagerPin(pin);
    if (!isValidPin) {
      setError('Invalid manager PIN');
      return;
    }

    try {
      await logAction({
        action: 'manager_override_tab',
        context: 'TabScreen',
        metadata: {
          reason: overrideReason,
          action: pendingAction?.type,
          tab_id: pendingAction?.tab?.id
        }
      });

      // Execute the pending action
      if (pendingAction?.type === 'close_tab') {
        await executeCloseTab(pendingAction.tab);
      } else if (pendingAction?.type === 'delete_tab') {
        await executeDeleteTab(pendingAction.tab);
      }

      // Reset manager override
      setShowManagerOverride(false);
      setManagerPin('');
      setOverrideReason('');
      setPendingAction(null);
      
    } catch (err) {
      console.error('Manager override error:', err);
      setError('Failed to execute override: ' + err.message);
    }
  };

  // Handle barcode scanner input for QR codes
  const handleBarcodeOrQRScan = (code) => {
    console.log('Barcode/QR scanned:', code);
    
    if (showSearchScanner) {
      handleSearchQRScan(code);
    }
  };

  const handleSearchQRScan = async (qrData) => {
    if (!selectedBusinessId) return;

    try {
      setShowSearchScanner(false);
      setQrSearchValue(''); // Clear QR input after scan
      console.log('Processing search QR code data:', qrData);
      
      let searchValue = '';
      
      // Try to parse as JSON first (loyalty customer QR)
      try {
        const parsed = JSON.parse(qrData);
        if (parsed.type === 'loyalty_customer' && parsed.customer_id) {
          // Look up the customer name from loyalty account
          const { data: loyaltyCustomer, error } = await supabase
            .from('pos_loyalty_accounts')
            .select('customer_name, customer_phone, customer_email')
            .eq('id', parsed.customer_id)
            .eq('business_id', selectedBusinessId)
            .single();

          if (loyaltyCustomer && !error) {
            searchValue = loyaltyCustomer.customer_name;
          }
        }
      } catch (jsonError) {
        console.log('Not valid JSON, trying other formats');
      }

      // Try as direct loyalty account ID (UUID format)
      if (!searchValue && qrData.match(/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i)) {
        const { data: loyaltyCustomer, error } = await supabase
          .from('pos_loyalty_accounts')
          .select('customer_name, customer_phone, customer_email')
          .eq('id', qrData)
          .eq('business_id', selectedBusinessId)
          .single();

        if (loyaltyCustomer && !error) {
          searchValue = loyaltyCustomer.customer_name;
        }
      }

      // Try as phone number
      if (!searchValue && qrData.match(/^\+?[\d\s\-\(\)]+$/)) {
        const cleanPhone = qrData.replace(/\D/g, '');
        searchValue = cleanPhone;
      }

      // Use as direct text if it's reasonable length
      if (!searchValue && qrData.length > 2 && qrData.length < 50 && !qrData.includes('/')) {
        searchValue = qrData;
      }

      if (searchValue) {
        setSearchTerm(searchValue);
        console.log('Search term set to:', searchValue);
      } else {
        setError('Could not determine search term from QR code');
      }

    } catch (err) {
      console.error('Search QR scan error:', err);
      setError('Failed to process QR code for search: ' + err.message);
    }
  };

  const handleManualQRSearch = async () => {
    if (!qrSearchValue.trim()) {
      setError('Please enter a QR code value');
      return;
    }

    await handleSearchQRScan(qrSearchValue.trim());
    setShowQRManualInput(false);
    setQrSearchValue('');
  };

  // Item Selection Modal Functions
  const handleItemToggle = (item) => {
    setSelectedItems(prev => {
      const isSelected = prev.some(selected => selected.id === item.id);
      if (isSelected) {
        return prev.filter(selected => selected.id !== item.id);
      } else {
        return [...prev, item];
      }
    });
  };

  const handleSelectAllItems = () => {
    if (selectedPaymentTab?.pos_tab_items) {
      setSelectedItems([...selectedPaymentTab.pos_tab_items]);
    }
  };

  const handleClearItemSelection = () => {
    setSelectedItems([]);
  };

  const proceedToCustomerSelection = () => {
    if (selectedItems.length === 0) {
      setError('Please select at least one item to pay for');
      return;
    }
    setShowItemSelectionModal(false);
    setShowCustomerSelectionModal(true);
  };

  const proceedToPayment = () => {
    // Calculate totals for selected items
    const selectedSubtotal = selectedItems.reduce((sum, item) => sum + (Number(item.total_price) || 0), 0);
    const taxRate = selectedPaymentTab.subtotal > 0 ? selectedPaymentTab.tax_amount / selectedPaymentTab.subtotal : 0;
    const selectedTax = Math.round(selectedSubtotal * taxRate * 100) / 100;
    const selectedTotal = selectedSubtotal + selectedTax;

    // Navigate to payment screen with selected items and customer
    navigate('/dashboard/pos/payment', {
      state: {
        saleData: {
          ...selectedPaymentTab,
          items: selectedItems,
          loyaltyCustomer: paymentCustomer,
          tab_mode: true,
          payment_type: 'partial',
          subtotal: selectedSubtotal,
          tax_amount: selectedTax,
          total_amount: selectedTotal,
          amount_paid: 0,
          balance_remaining: selectedTotal,
          is_partial_payment: true,
          original_tab_id: selectedPaymentTab.id
        }
      }
    });

    // Reset modal states
    setShowCustomerSelectionModal(false);
    setSelectedPaymentTab(null);
    setSelectedItems([]);
    setPaymentCustomer(null);
  };

  const handleCreateTab = async (tabData) => {
    const { data: tab, error } = await supabase
      .from('pos_tabs')
      .insert(tabData)
      .select()
      .single();

    if (error) throw error;

    await logAction({
      action: 'tab_created',
      context: 'TabScreen',
      metadata: {
        tab_id: tab.id,
        tab_number: tab.tab_number,
        customer_name: tab.customer_name,
        loyalty_customer_id: tab.loyalty_customer_id
      }
    });

    setShowCreateModal(false);

    navigate('/dashboard/pos/register', {
      state: {
        activeTab: tab,
        mode: 'tab',
        justCreated: true
      }
    });
  };

  const handleSelectTab = (tab) => {
    setSelectedTab(tab);
    setShowTabDetails(true);
  };

  const handleAddItemsToTab = (tab) => {
    navigate('/dashboard/pos/register', {
      state: {
        activeTab: tab,
        mode: 'tab'
      }
    });
  };

  const handlePayTab = (tab, paymentType = 'partial') => {
    // Instead of navigating directly, open item selection modal
    setSelectedPaymentTab(tab);
    setSelectedItems([]); // Reset selections
    setPaymentCustomer(null); // Reset customer
    setShowItemSelectionModal(true);
  };

  const handleCloseTab = (tab) => {
    if (tab.balance_remaining > 0.01) {
      setPendingAction({ type: 'close_tab', tab });
      setOverrideReason('Closing tab with remaining balance');
      setShowManagerOverride(true);
    } else {
      executeCloseTab(tab);
    }
  };

  const executeCloseTab = async (tab) => {
    try {
      setLoading(true);
      const { error } = await supabase
        .from('pos_tabs')
        .update({ 
          status: 'closed',
          closed_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        })
        .eq('id', tab.id);

      if (error) throw error;

      await logAction({
        action: 'tab_closed',
        context: 'TabScreen',
        metadata: {
          tab_id: tab.id,
          tab_number: tab.tab_number,
          final_balance: tab.balance_remaining
        }
      });

      loadTabs();
    } catch (err) {
      console.error('Error closing tab:', err);
      setError('Failed to close tab: ' + err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteTab = (tab) => {
    setPendingAction({ type: 'delete_tab', tab });
    setOverrideReason('Deleting tab - requires manager approval');
    setShowManagerOverride(true);
  };

  const executeDeleteTab = async (tab) => {
    try {
      setLoading(true);
      
      // First delete associated tab items
      await supabase
        .from('pos_tab_items')
        .delete()
        .eq('tab_id', tab.id);

      // Then delete the tab
      const { error } = await supabase
        .from('pos_tabs')
        .delete()
        .eq('id', tab.id);

      if (error) throw error;

      await logAction({
        action: 'tab_deleted',
        context: 'TabScreen',
        metadata: {
          tab_id: tab.id,
          tab_number: tab.tab_number,
          customer_name: tab.customer_name
        }
      });

      loadTabs();
    } catch (err) {
      console.error('Error deleting tab:', err);
      setError('Failed to delete tab: ' + err.message);
    } finally {
      setLoading(false);
    }
  };

  const filteredTabs = tabs.filter(tab => {
    if (!searchTerm) return true;
    return (
      tab.customer_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      tab.customer_phone?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      tab.customer_email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      tab.tab_number?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      tab.notes?.toLowerCase().includes(searchTerm.toLowerCase())
    );
  });

  const getTabStatus = (tab) => {
    if (tab.status === 'closed') return 'Closed';
    if (tab.balance_remaining <= 0) return 'Paid in Full';
    if (tab.amount_paid > 0) return 'Partial Payment';
    return 'Open';
  };

  const getStatusColor = (tab) => {
    if (tab.status === 'closed') return '#6b7280';
    if (tab.balance_remaining <= 0) return '#059669';
    if (tab.amount_paid > 0) return '#f59e0b';
    return '#3b82f6';
  };

  // Loading and error states
  if (authLoading) {
    return (
      <div style={{...styles.container, justifyContent: 'center', alignItems: 'center'}}>
        <h3>Loading Tab Management...</h3>
        <p>Authenticating user and loading business data...</p>
      </div>
    );
  }

  if (authError) {
    return (
      <div style={{...styles.container, justifyContent: 'center', alignItems: 'center'}}>
        <h3>Authentication Error</h3>
        <p>{authError}</p>
        <button 
          style={styles.createButton}
          onClick={() => navigate('/login')}
        >
          Return to Login
        </button>
      </div>
    );
  }

  if (loading) {
    return (
      <div style={styles.container}>
        <div style={styles.loading}>Loading tabs...</div>
      </div>
    );
  }

  return (
    <div style={styles.container}>
      <div style={styles.header}>
        <h2>Tab Management</h2>
        <p>Manage customer tabs and open orders</p>
      </div>

      {error && <div style={styles.errorBanner}>{error}</div>}

      {/* Controls */}
      <div style={styles.controls}>
        <div style={styles.searchSection}>
          {/* Text Search */}
          <div style={styles.searchGroup}>
            <label style={styles.searchLabel}>Search Tabs:</label>
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Customer name, phone, or tab number..."
              style={styles.searchInput}
            />
          </div>

          {/* QR Code Search */}
          <div style={styles.qrSearchGroup}>
            <label style={styles.searchLabel}>QR Search:</label>
            <div style={styles.qrButtonGroup}>
              <button
                style={styles.qrScanButton}
                onClick={() => setShowSearchScanner(true)}
                title="Scan customer QR code"
              >
                📱 Scan QR
              </button>
              <button
                style={styles.qrManualButton}
                onClick={() => setShowQRManualInput(true)}
                title="Enter QR code manually"
              >
                ⌨️ Enter QR
              </button>
            </div>
          </div>

          {/* Sort */}
          <div style={styles.sortGroup}>
            <label style={styles.searchLabel}>Sort:</label>
            <select
              value={`${sortBy}-${sortOrder}`}
              onChange={(e) => {
                const [field, order] = e.target.value.split('-');
                setSortBy(field);
                setSortOrder(order);
                loadTabs();
              }}
              style={styles.sortSelect}
            >
              <option value="updated_at-desc">Most Recent</option>
              <option value="updated_at-asc">Oldest First</option>
              <option value="customer_name-asc">Customer A-Z</option>
              <option value="customer_name-desc">Customer Z-A</option>
              <option value="total_amount-desc">Highest Amount</option>
              <option value="total_amount-asc">Lowest Amount</option>
            </select>
          </div>
        </div>
        
        <button
          style={styles.createButton}
          onClick={() => setShowCreateModal(true)}
        >
          + Create New Tab
        </button>
      </div>

      {/* Stats */}
      <div style={styles.stats}>
        <div style={styles.statCard}>
          <div style={styles.statValue}>{filteredTabs.length}</div>
          <div style={styles.statLabel}>Active Tabs</div>
        </div>
        <div style={styles.statCard}>
          <div style={styles.statValue}>
            {formatCurrency(filteredTabs.reduce((sum, tab) => sum + (tab.total_amount || 0), 0))}
          </div>
          <div style={styles.statLabel}>Total Tab Value</div>
        </div>
        <div style={styles.statCard}>
          <div style={styles.statValue}>
            {formatCurrency(filteredTabs.reduce((sum, tab) => sum + (tab.balance_remaining || 0), 0))}
          </div>
          <div style={styles.statLabel}>Outstanding Balance</div>
        </div>
      </div>

      {/* Tab List */}
      <div style={styles.content}>
        {filteredTabs.length === 0 ? (
          <div style={styles.emptyState}>
            <div style={styles.emptyIcon}>📋</div>
            <div style={styles.emptyTitle}>No Active Tabs</div>
            <div style={styles.emptyText}>
              {searchTerm ? 'No tabs match your search criteria' : 'Create a new tab to get started'}
            </div>
            {!searchTerm && (
              <button
                style={styles.createButton}
                onClick={() => setShowCreateModal(true)}
              >
                Create First Tab
              </button>
            )}
          </div>
        ) : (
          <div style={styles.tabGrid}>
            {filteredTabs.map(tab => (
              <div key={tab.id} style={styles.tabCard}>
                <div style={styles.tabHeader}>
                  <div style={styles.tabNumber}>{tab.tab_number}</div>
                  <div 
                    style={{
                      ...styles.tabStatus,
                      color: getStatusColor(tab)
                    }}
                  >
                    {getTabStatus(tab)}
                  </div>
                </div>
                
                <div style={styles.tabBody}>
                  <div style={styles.customerInfo}>
                    <div style={styles.customerName}>{tab.customer_name}</div>
                    {tab.customer_phone && (
                      <div style={styles.customerPhone}>📞 {tab.customer_phone}</div>
                    )}
                    {tab.customer_email && (
                      <div style={styles.customerEmail}>✉️ {tab.customer_email}</div>
                    )}
                    {tab.pos_loyalty_accounts && (
                      <div style={styles.loyaltyBadge}>⭐ Loyalty Member</div>
                    )}
                    {tab.notes && (
                      <div style={styles.tabNotes}>📝 {tab.notes}</div>
                    )}
                  </div>
                  
                  <div style={styles.tabAmounts}>
                    <div style={styles.amountRow}>
                      <span>Total:</span>
                      <span style={styles.totalAmount}>{formatCurrency(tab.total_amount)}</span>
                    </div>
                    <div style={styles.amountRow}>
                      <span>Paid:</span>
                      <span style={styles.paidAmount}>{formatCurrency(tab.amount_paid)}</span>
                    </div>
                    <div style={styles.amountRow}>
                      <span>Balance:</span>
                      <span style={{
                        ...styles.balanceAmount,
                        color: tab.balance_remaining > 0 ? '#dc2626' : '#059669'
                      }}>
                        {formatCurrency(tab.balance_remaining)}
                      </span>
                    </div>
                  </div>
                  
                  <div style={styles.tabMeta}>
                    <div style={styles.tabDate}>
                      Created: {new Date(tab.created_at).toLocaleDateString()}
                    </div>
                    <div style={styles.tabItems}>
                      Items: {tab.pos_tab_items?.length || 0}
                    </div>
                  </div>
                </div>
                
                <div style={styles.tabActions}>
                  <button
                    style={styles.actionButton}
                    onClick={() => handleSelectTab(tab)}
                    title="View Details"
                  >
                    👁️ View
                  </button>
                  <button
                    style={styles.actionButton}
                    onClick={() => handleAddItemsToTab(tab)}
                    title="Add Items"
                  >
                    ➕ Add Items
                  </button>
                  {tab.balance_remaining > 0 ? (
                    <button
                      style={styles.payButton}
                      onClick={() => handlePayTab(tab, 'partial')}
                      title="Make Payment"
                    >
                      💳 Pay
                    </button>
                  ) : (
                    <button
                      style={styles.closeButton}
                      onClick={() => handleCloseTab(tab)}
                      title="Close Tab"
                    >
                      ✅ Close
                    </button>
                  )}
                  <button
                    style={styles.deleteButton}
                    onClick={() => handleDeleteTab(tab)}
                    title="Delete Tab"
                  >
                    🗑️
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Modals */}
      <CreateTabModal
        showModal={showCreateModal}
        onClose={() => setShowCreateModal(false)}
        onCreateTab={handleCreateTab}
        selectedBusinessId={selectedBusinessId}
        authUser={authUser}
      />

      <ItemSelectionModal
        showModal={showItemSelectionModal}
        onClose={() => {
          setShowItemSelectionModal(false);
          setSelectedPaymentTab(null);
          setSelectedItems([]);
        }}
        selectedPaymentTab={selectedPaymentTab}
        selectedItems={selectedItems}
        onItemToggle={handleItemToggle}
        onSelectAllItems={handleSelectAllItems}
        onClearItemSelection={handleClearItemSelection}
        onProceedToCustomerSelection={proceedToCustomerSelection}
        formatCurrency={formatCurrency}
      />

      <CustomerSelectionModal
        showModal={showCustomerSelectionModal}
        onClose={() => {
          setShowCustomerSelectionModal(false);
          setPaymentCustomer(null);
        }}
        onBackToItems={() => {
          setShowCustomerSelectionModal(false);
          setShowItemSelectionModal(true);
        }}
        selectedItems={selectedItems}
        selectedPaymentTab={selectedPaymentTab}
        paymentCustomer={paymentCustomer}
        onCustomerSelected={setPaymentCustomer}
        onProceedToPayment={proceedToPayment}
        formatCurrency={formatCurrency}
        selectedBusinessId={selectedBusinessId}
      />

      <ManagerOverrideModal
        showModal={showManagerOverride}
        onClose={() => {
          setShowManagerOverride(false);
          setPendingAction(null);
          setManagerPin('');
          setError(null);
        }}
        overrideReason={overrideReason}
        onApproveOverride={handleManagerOverride}
        error={error}
      />

      <TabDetailsModal
        showModal={showTabDetails}
        onClose={() => {
          setShowTabDetails(false);
          setSelectedTab(null);
        }}
        selectedTab={selectedTab}
        onAddItems={handleAddItemsToTab}
        onMakePayment={handlePayTab}
        formatCurrency={formatCurrency}
      />

      <QRManualInputModal
        showModal={showQRManualInput}
        onClose={() => {
          setShowQRManualInput(false);
          setQrSearchValue('');
        }}
        onSubmit={handleManualQRSearch}
        value={qrSearchValue}
        onChange={setQrSearchValue}
        title="Enter QR Code Manually"
        instructions="Enter the QR code data from a customer's loyalty card. This can be: Customer UUID, Phone number, Customer name, or JSON loyalty data"
      />

      <QRScannerModal
        showModal={showSearchScanner}
        onClose={() => setShowSearchScanner(false)}
        onScan={handleBarcodeOrQRScan}
        title="Scan Customer QR Code"
        instructions="Scan a customer's loyalty card QR code to search for their open tabs"
      />
    </div>
  );
};

const styles = {
  container: {
    display: 'flex',
    flexDirection: 'column',
    height: '100vh',
    backgroundColor: '#f8f9fa',
    padding: '20px',
    paddingTop: '100px',
    boxSizing: 'border-box'
  },
  header: {
    marginBottom: '30px',
    textAlign: 'center'
  },
  errorBanner: {
    backgroundColor: '#fee2e2',
    color: '#dc2626',
    padding: '15px',
    borderRadius: '6px',
    marginBottom: '20px'
  },
  controls: {
    display: 'flex',
    gap: '20px',
    marginBottom: '20px',
    alignItems: 'flex-end',
    flexWrap: 'wrap'
  },
  searchSection: {
    flex: 1,
    display: 'flex',
    gap: '15px',
    alignItems: 'flex-end',
    flexWrap: 'wrap'
  },
  searchGroup: {
    display: 'flex',
    flexDirection: 'column',
    minWidth: '250px',
    flex: 1
  },
  qrSearchGroup: {
    display: 'flex',
    flexDirection: 'column',
    minWidth: '180px'
  },
  sortGroup: {
    display: 'flex',
    flexDirection: 'column',
    minWidth: '150px'
  },
  searchLabel: {
    fontSize: '14px',
    fontWeight: 'bold',
    color: '#374151',
    marginBottom: '6px'
  },
  searchInput: {
    padding: '12px',
    border: '2px solid #008080',
    borderRadius: '6px',
    fontSize: '16px'
  },
  qrButtonGroup: {
    display: 'flex',
    gap: '8px'
  },
  qrScanButton: {
    flex: 1,
    padding: '10px 12px',
    backgroundColor: '#008080',
    color: 'white',
    border: 'none',
    borderRadius: '6px',
    cursor: 'pointer',
    fontSize: '14px',
    fontWeight: 'bold',
    whiteSpace: 'nowrap'
  },
  qrManualButton: {
    flex: 1,
    padding: '10px 12px',
    backgroundColor: '#6b7280',
    color: 'white',
    border: 'none',
    borderRadius: '6px',
    cursor: 'pointer',
    fontSize: '14px',
    fontWeight: 'bold',
    whiteSpace: 'nowrap'
  },
  sortSelect: {
    padding: '12px',
    border: '2px solid #008080',
    borderRadius: '6px',
    fontSize: '16px',
    minWidth: '150px'
  },
  createButton: {
    padding: '12px 20px',
    backgroundColor: '#008080',
    color: 'white',
    border: 'none',
    borderRadius: '6px',
    fontSize: '16px',
    fontWeight: 'bold',
    cursor: 'pointer',
    whiteSpace: 'nowrap'
  },
  stats: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
    gap: '15px',
    marginBottom: '30px'
  },
  statCard: {
    backgroundColor: 'white',
    padding: '20px',
    borderRadius: '8px',
    textAlign: 'center',
    border: '1px solid #e5e7eb'
  },
  statValue: {
    fontSize: '24px',
    fontWeight: 'bold',
    color: '#008080',
    marginBottom: '8px'
  },
  statLabel: {
    fontSize: '14px',
    color: '#6b7280'
  },
  content: {
    flex: 1,
    overflowY: 'auto'
  },
  emptyState: {
    textAlign: 'center',
    padding: '60px 20px',
    color: '#6b7280'
  },
  emptyIcon: {
    fontSize: '64px',
    marginBottom: '20px'
  },
  emptyTitle: {
    fontSize: '24px',
    fontWeight: 'bold',
    marginBottom: '10px'
  },
  emptyText: {
    fontSize: '16px',
    marginBottom: '30px'
  },
  tabGrid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fill, minmax(350px, 1fr))',
    gap: '20px',
    paddingBottom: '20px'
  },
  tabCard: {
    backgroundColor: 'white',
    borderRadius: '12px',
    padding: '20px',
    border: '2px solid #e5e7eb',
    transition: 'all 0.2s ease',
    boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
  },
  tabHeader: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: '15px',
    paddingBottom: '10px',
    borderBottom: '1px solid #f3f4f6'
  },
  tabNumber: {
    fontSize: '18px',
    fontWeight: 'bold',
    color: '#1f2937'
  },
  tabStatus: {
    fontSize: '14px',
    fontWeight: 'bold',
    padding: '4px 8px',
    borderRadius: '4px',
    backgroundColor: '#f3f4f6'
  },
  tabBody: {
    marginBottom: '15px'
  },
  customerInfo: {
    marginBottom: '15px'
  },
  customerName: {
    fontSize: '16px',
    fontWeight: 'bold',
    color: '#1f2937',
    marginBottom: '4px'
  },
  customerPhone: {
    fontSize: '14px',
    color: '#6b7280',
    marginBottom: '4px'
  },
  customerEmail: {
    fontSize: '14px',
    color: '#6b7280',
    marginBottom: '4px'
  },
  loyaltyBadge: {
    fontSize: '12px',
    color: '#059669',
    fontWeight: 'bold',
    backgroundColor: '#d1fae5',
    padding: '2px 6px',
    borderRadius: '4px',
    display: 'inline-block',
    marginBottom: '4px'
  },
  tabNotes: {
    fontSize: '14px',
    color: '#6b7280',
    fontStyle: 'italic'
  },
  tabAmounts: {
    marginBottom: '15px'
  },
  amountRow: {
    display: 'flex',
    justifyContent: 'space-between',
    marginBottom: '4px',
    fontSize: '14px'
  },
  totalAmount: {
    fontWeight: 'bold',
    color: '#1f2937'
  },
  paidAmount: {
    color: '#059669'
  },
  balanceAmount: {
    fontWeight: 'bold'
  },
  tabMeta: {
    display: 'flex',
    justifyContent: 'space-between',
    fontSize: '12px',
    color: '#9ca3af'
  },
  tabActions: {
    display: 'flex',
    gap: '8px',
    justifyContent: 'space-between'
  },
  actionButton: {
    flex: 1,
    padding: '8px',
    backgroundColor: '#f3f4f6',
    color: '#374151',
    border: '1px solid #d1d5db',
    borderRadius: '4px',
    cursor: 'pointer',
    fontSize: '12px',
    fontWeight: 'bold'
  },
  payButton: {
    flex: 1,
    padding: '8px',
    backgroundColor: '#059669',
    color: 'white',
    border: 'none',
    borderRadius: '4px',
    cursor: 'pointer',
    fontSize: '12px',
    fontWeight: 'bold'
  },
  closeButton: {
    flex: 1,
    padding: '8px',
    backgroundColor: '#008080',
    color: 'white',
    border: 'none',
    borderRadius: '4px',
    cursor: 'pointer',
    fontSize: '12px',
    fontWeight: 'bold'
  },
  deleteButton: {
    padding: '8px',
    backgroundColor: '#dc2626',
    color: 'white',
    border: 'none',
    borderRadius: '4px',
    cursor: 'pointer',
    fontSize: '12px',
    fontWeight: 'bold',
    minWidth: '40px'
  },
  loading: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    height: '200px',
    fontSize: '18px',
    color: '#6b7280'
  }
};

export default TabScreen;