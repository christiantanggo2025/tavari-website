// screens/POS/LoyaltySettings.jsx
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../../supabaseClient';
import { logAction } from '../../helpers/posAudit';

const LoyaltySettings = () => {
  const navigate = useNavigate();
  
  // Authentication state
  const [authUser, setAuthUser] = useState(null);
  const [selectedBusinessId, setSelectedBusinessId] = useState(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [authError, setAuthError] = useState(null);
  
  const [settings, setSettings] = useState({
    // Program Configuration
    loyalty_mode: 'points', // 'points' or 'dollars'
    earn_rate: 10, // 10 points per $1 or $0.10 per $1
    earn_rate_percentage: 1.0, // 1% earn rate
    redemption_rate: 10000, // 10,000 points = $10
    is_active: true,
    
    // Redemption Rules
    auto_apply: 'customer_choice', // 'always', 'never', 'customer_choice'
    min_redemption: 10000, // minimum points/dollars to redeem
    max_redemption_per_transaction: null, // max per single transaction
    max_redemption_per_day: 10000, // daily limit
    allow_partial_redemption: true, // use some points, pay rest cash
    
    // Expiration Settings
    credits_expire: true,
    expiry_months: 6,
    expiry_warning_days: 30, // warn customers X days before expiry
    
    // Earning Restrictions
    max_daily_earn: null, // daily earning cap
    max_total_balance: 100000, // maximum account balance
    blackout_dates: [], // dates when earning is disabled
    excluded_categories: [], // product categories that don't earn points
    
    // Return/Refund Policies
    refund_point_policy: 'deduct_unvested_first', // 'deduct_available_first', 'proportional'
    points_on_tax: false, // earn points on tax portion
    points_on_discounted_items: true, // earn on sale items
    
    // Family/Household Features
    allow_family_pooling: false,
    max_linked_accounts: 5,
    allow_point_transfers: false,
    
    // Bonus & Campaigns
    enable_bonus_campaigns: true,
    welcome_bonus: 500, // points for signing up
    birthday_bonus: 1000, // annual birthday bonus
    review_bonus: 100, // points for leaving reviews
    
    // Security & Fraud Prevention
    require_id_for_large_redemptions: true,
    large_redemption_threshold: 50000, // require ID above this amount
    suspicious_activity_threshold: 10000, // flag unusual earning patterns
    
    // Notifications
    email_point_summaries: true,
    sms_balance_alerts: false,
    push_expiry_warnings: true
  });
  
  const [activeTab, setActiveTab] = useState('basic');
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(false);
  
  // Authentication and business context setup
  useEffect(() => {
    const initializeAuth = async () => {
      try {
        console.log('LoyaltySettings: Initializing authentication...');
        
        const { data: { session }, error } = await supabase.auth.getSession();
        console.log('LoyaltySettings: Session check result:', { session: !!session, error });

        if (error || !session?.user) {
          console.error('LoyaltySettings: No valid session, redirecting to login');
          navigate('/login');
          return;
        }

        setAuthUser(session.user);
        console.log('LoyaltySettings: Authenticated as:', session.user.email);

        const currentBusinessId = localStorage.getItem('currentBusinessId');
        console.log('LoyaltySettings: Business ID from localStorage:', currentBusinessId);

        if (!currentBusinessId) {
          setAuthError('No business selected');
          return;
        }

        setSelectedBusinessId(currentBusinessId);

        // Verify user has access to this business
        const { data: userRole, error: roleError } = await supabase
          .from('user_roles')
          .select('*')
          .eq('user_id', session.user.id)
          .eq('business_id', currentBusinessId)
          .eq('active', true)
          .single();

        if (roleError || !userRole) {
          console.error('LoyaltySettings: User not authorized for this business:', roleError);
          setAuthError('Not authorized for this business');
          return;
        }

        console.log('LoyaltySettings: User role verified:', userRole.role);
        setAuthLoading(false);

      } catch (err) {
        console.error('LoyaltySettings: Authentication error:', err);
        setAuthError(err.message);
        setAuthLoading(false);
      }
    };

    initializeAuth();
  }, [navigate]);

  useEffect(() => {
    if (selectedBusinessId) {
      loadSettings();
    }
  }, [selectedBusinessId]);

  const loadSettings = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('pos_loyalty_settings')
        .select('*')
        .eq('business_id', selectedBusinessId)
        .single();

      if (error && error.code !== 'PGRST116') {
        throw error;
      }

      if (data) {
        setSettings(prevSettings => ({
          ...prevSettings,
          ...data
        }));
      }
    } catch (err) {
      console.error('Error loading loyalty settings:', err);
      setError('Failed to load loyalty settings');
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    try {
      setSaving(true);
      setError(null);
      setSuccess(false);

      const { error } = await supabase
        .from('pos_loyalty_settings')
        .upsert({
          business_id: selectedBusinessId,
          ...settings,
          updated_at: new Date().toISOString()
        });

      if (error) throw error;

      setSuccess(true);
      setTimeout(() => setSuccess(false), 3000);

      await logAction({
        action: 'loyalty_settings_updated',
        context: 'LoyaltySettings',
        metadata: { tab: activeTab, settings }
      });

    } catch (err) {
      console.error('Error saving loyalty settings:', err);
      setError('Failed to save settings');
    } finally {
      setSaving(false);
    }
  };

  const handleInputChange = (field, value) => {
    setSettings(prev => {
      const newSettings = { ...prev, [field]: value };
      
      // Auto-calculate related fields when earn rate changes
      if (field === 'earn_rate_percentage') {
        if (prev.loyalty_mode === 'points') {
          newSettings.earn_rate = Math.round(value * 1000); // 1% = 10 points per $1
        } else {
          newSettings.earn_rate = value / 100; // 1% = $0.01 per $1
        }
      }
      
      return newSettings;
    });
  };

  // Calculate examples for display
  const calculateExamples = () => {
    const rate = settings.earn_rate_percentage;
    if (settings.loyalty_mode === 'points') {
      return {
        five: Math.round(5 * rate * 10),
        ten: Math.round(10 * rate * 10), 
        twenty: Math.round(20 * rate * 10)
      };
    } else {
      return {
        five: (5 * rate / 100).toFixed(2),
        ten: (10 * rate / 100).toFixed(2),
        twenty: (20 * rate / 100).toFixed(2)
      };
    }
  };

  const examples = calculateExamples();

  // Loading and error states for authentication
  if (authLoading) {
    return (
      <div style={{...styles.container, justifyContent: 'center', alignItems: 'center'}}>
        <h3>Loading Loyalty Settings...</h3>
        <p>Authenticating user and loading business data...</p>
      </div>
    );
  }

  if (authError) {
    return (
      <div style={{...styles.container, justifyContent: 'center', alignItems: 'center'}}>
        <h3>Authentication Error</h3>
        <p>{authError}</p>
        <button 
          style={styles.saveButton}
          onClick={() => navigate('/login')}
        >
          Return to Login
        </button>
      </div>
    );
  }

  if (!selectedBusinessId) {
    return (
      <div style={styles.container}>
        <div style={styles.error}>
          <h3>No Business Selected</h3>
          <p>Please select a business to manage loyalty settings.</p>
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div style={styles.container}>
        <div style={styles.loading}>Loading loyalty settings...</div>
      </div>
    );
  }

  return (
    <div style={styles.container}>
      <div style={styles.header}>
        <h2>Advanced Loyalty Program Settings</h2>
        <p>Configure your complete customer loyalty and rewards program</p>
      </div>

      {/* Tab Navigation */}
      <div style={styles.tabNav}>
        {[
          { key: 'basic', label: 'Basic Settings' },
          { key: 'redemption', label: 'Redemption Rules' },
          { key: 'advanced', label: 'Advanced Features' },
          { key: 'security', label: 'Security & Fraud' },
          { key: 'family', label: 'Family Features' },
          { key: 'campaigns', label: 'Bonus Campaigns' }
        ].map(tab => (
          <button
            key={tab.key}
            style={{
              ...styles.tabButton,
              ...(activeTab === tab.key ? styles.tabButtonActive : {})
            }}
            onClick={() => setActiveTab(tab.key)}
          >
            {tab.label}
          </button>
        ))}
      </div>

      <div style={styles.content}>
        {/* Basic Settings Tab */}
        {activeTab === 'basic' && (
          <div style={styles.section}>
            <h3 style={styles.sectionTitle}>Program Configuration</h3>
            
            <div style={styles.formRow}>
              <label style={styles.label}>Program Status</label>
              <div style={styles.buttonGroup}>
                <button
                  style={{
                    ...styles.toggleButton,
                    ...(settings.is_active ? styles.toggleButtonActive : {})
                  }}
                  onClick={() => handleInputChange('is_active', true)}
                >
                  Active
                </button>
                <button
                  style={{
                    ...styles.toggleButton,
                    ...(!settings.is_active ? styles.toggleButtonActive : {})
                  }}
                  onClick={() => handleInputChange('is_active', false)}
                >
                  Inactive
                </button>
              </div>
            </div>

            <div style={styles.formRow}>
              <label style={styles.label}>Reward Type</label>
              <select
                value={settings.loyalty_mode}
                onChange={(e) => handleInputChange('loyalty_mode', e.target.value)}
                style={styles.select}
              >
                <option value="points">Points System (like PC Optimum)</option>
                <option value="dollars">Dollar Credits</option>
              </select>
            </div>

            <div style={styles.formRow}>
              <label style={styles.label}>Earn Rate (%)</label>
              <input
                type="number"
                value={settings.earn_rate_percentage}
                onChange={(e) => handleInputChange('earn_rate_percentage', parseFloat(e.target.value) || 0)}
                step="0.1"
                min="0"
                max="10"
                style={styles.input}
              />
              <div style={styles.helperText}>
                Examples: {settings.loyalty_mode === 'points' ? 
                  `$5 = ${examples.five} pts, $10 = ${examples.ten} pts, $20 = ${examples.twenty} pts` :
                  `$5 = $${examples.five}, $10 = $${examples.ten}, $20 = $${examples.twenty}`
                }
              </div>
            </div>

            {settings.loyalty_mode === 'points' && (
              <div style={styles.formRow}>
                <label style={styles.label}>Redemption Value</label>
                <div style={styles.flexRow}>
                  <input
                    type="number"
                    value={settings.redemption_rate}
                    onChange={(e) => handleInputChange('redemption_rate', parseInt(e.target.value) || 10000)}
                    step="1000"
                    min="1000"
                    style={{...styles.input, width: '120px'}}
                  />
                  <span style={styles.flexText}>points = $10.00</span>
                </div>
                <div style={styles.helperText}>
                  Each point worth: ${(10 / settings.redemption_rate).toFixed(4)}
                </div>
              </div>
            )}

            <div style={styles.formRow}>
              <label style={styles.label}>Earn Points on Tax</label>
              <div style={styles.buttonGroup}>
                <button
                  style={{
                    ...styles.toggleButton,
                    ...(settings.points_on_tax ? styles.toggleButtonActive : {})
                  }}
                  onClick={() => handleInputChange('points_on_tax', true)}
                >
                  Yes
                </button>
                <button
                  style={{
                    ...styles.toggleButton,
                    ...(!settings.points_on_tax ? styles.toggleButtonActive : {})
                  }}
                  onClick={() => handleInputChange('points_on_tax', false)}
                >
                  No
                </button>
              </div>
            </div>

            <div style={styles.formRow}>
              <label style={styles.label}>Earn Points on Discounted Items</label>
              <div style={styles.buttonGroup}>
                <button
                  style={{
                    ...styles.toggleButton,
                    ...(settings.points_on_discounted_items ? styles.toggleButtonActive : {})
                  }}
                  onClick={() => handleInputChange('points_on_discounted_items', true)}
                >
                  Yes
                </button>
                <button
                  style={{
                    ...styles.toggleButton,
                    ...(!settings.points_on_discounted_items ? styles.toggleButtonActive : {})
                  }}
                  onClick={() => handleInputChange('points_on_discounted_items', false)}
                >
                  No
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Redemption Rules Tab */}
        {activeTab === 'redemption' && (
          <div style={styles.section}>
            <h3 style={styles.sectionTitle}>Redemption Configuration</h3>
            
            <div style={styles.formRow}>
              <label style={styles.label}>Auto-Apply Policy</label>
              <select
                value={settings.auto_apply}
                onChange={(e) => handleInputChange('auto_apply', e.target.value)}
                style={styles.select}
              >
                <option value="always">Always auto-apply when minimum reached</option>
                <option value="customer_choice">Let customer choose each time</option>
                <option value="never">Manual redemption only</option>
              </select>
            </div>

            <div style={styles.formRow}>
              <label style={styles.label}>Minimum Redemption Amount</label>
              <input
                type="number"
                value={settings.min_redemption}
                onChange={(e) => handleInputChange('min_redemption', parseInt(e.target.value) || 0)}
                step={settings.loyalty_mode === 'points' ? '1000' : '1'}
                min="0"
                style={styles.input}
              />
              <div style={styles.helperText}>
                {settings.loyalty_mode === 'points' ? 
                  `Minimum ${settings.min_redemption} points (${(settings.min_redemption / settings.redemption_rate * 10).toFixed(2)} value)` :
                  `Minimum $${settings.min_redemption} redemption`
                }
              </div>
            </div>

            <div style={styles.formRow}>
              <label style={styles.label}>Maximum Per Transaction</label>
              <input
                type="number"
                value={settings.max_redemption_per_transaction || ''}
                onChange={(e) => handleInputChange('max_redemption_per_transaction', e.target.value ? parseInt(e.target.value) : null)}
                step={settings.loyalty_mode === 'points' ? '1000' : '1'}
                min="0"
                placeholder="No limit"
                style={styles.input}
              />
            </div>

            <div style={styles.formRow}>
              <label style={styles.label}>Maximum Per Day</label>
              <input
                type="number"
                value={settings.max_redemption_per_day || ''}
                onChange={(e) => handleInputChange('max_redemption_per_day', e.target.value ? parseInt(e.target.value) : null)}
                step={settings.loyalty_mode === 'points' ? '1000' : '1'}
                min="0"
                placeholder="No daily limit"
                style={styles.input}
              />
            </div>

            <div style={styles.formRow}>
              <label style={styles.label}>Partial Redemption</label>
              <div style={styles.buttonGroup}>
                <button
                  style={{
                    ...styles.toggleButton,
                    ...(settings.allow_partial_redemption ? styles.toggleButtonActive : {})
                  }}
                  onClick={() => handleInputChange('allow_partial_redemption', true)}
                >
                  Yes
                </button>
                <button
                  style={{
                    ...styles.toggleButton,
                    ...(!settings.allow_partial_redemption ? styles.toggleButtonActive : {})
                  }}
                  onClick={() => handleInputChange('allow_partial_redemption', false)}
                >
                  No
                </button>
              </div>
            </div>

            <div style={styles.formRow}>
              <label style={styles.label}>Credits Expire</label>
              <div style={styles.buttonGroup}>
                <button
                  style={{
                    ...styles.toggleButton,
                    ...(settings.credits_expire ? styles.toggleButtonActive : {})
                  }}
                  onClick={() => handleInputChange('credits_expire', true)}
                >
                  Yes
                </button>
                <button
                  style={{
                    ...styles.toggleButton,
                    ...(!settings.credits_expire ? styles.toggleButtonActive : {})
                  }}
                  onClick={() => handleInputChange('credits_expire', false)}
                >
                  No
                </button>
              </div>
            </div>

            {settings.credits_expire && (
              <React.Fragment>
                <div style={styles.formRow}>
                  <label style={styles.label}>Expiration Period (Months)</label>
                  <select
                    value={settings.expiry_months}
                    onChange={(e) => handleInputChange('expiry_months', parseInt(e.target.value))}
                    style={styles.select}
                  >
                    <option value={3}>3 months</option>
                    <option value={6}>6 months</option>
                    <option value={12}>12 months</option>
                    <option value={24}>24 months</option>
                  </select>
                </div>

                <div style={styles.formRow}>
                  <label style={styles.label}>Expiry Warning (Days)</label>
                  <input
                    type="number"
                    value={settings.expiry_warning_days}
                    onChange={(e) => handleInputChange('expiry_warning_days', parseInt(e.target.value) || 30)}
                    min="0"
                    max="90"
                    style={styles.input}
                  />
                  <div style={styles.helperText}>
                    Notify customers this many days before expiration
                  </div>
                </div>
              </React.Fragment>
            )}
          </div>
        )}

        {/* Advanced Features Tab */}
        {activeTab === 'advanced' && (
          <div style={styles.section}>
            <h3 style={styles.sectionTitle}>Advanced Configuration</h3>
            
            <div style={styles.formRow}>
              <label style={styles.label}>Daily Earning Limit</label>
              <input
                type="number"
                value={settings.max_daily_earn || ''}
                onChange={(e) => handleInputChange('max_daily_earn', e.target.value ? parseInt(e.target.value) : null)}
                step={settings.loyalty_mode === 'points' ? '100' : '1'}
                min="0"
                placeholder="No daily earning limit"
                style={styles.input}
              />
            </div>

            <div style={styles.formRow}>
              <label style={styles.label}>Maximum Account Balance</label>
              <input
                type="number"
                value={settings.max_total_balance}
                onChange={(e) => handleInputChange('max_total_balance', parseInt(e.target.value) || 100000)}
                step={settings.loyalty_mode === 'points' ? '10000' : '100'}
                min="0"
                style={styles.input}
              />
              <div style={styles.helperText}>
                Prevent unlimited point accumulation for fraud protection
              </div>
            </div>

            <div style={styles.formRow}>
              <label style={styles.label}>Return/Refund Policy</label>
              <select
                value={settings.refund_point_policy}
                onChange={(e) => handleInputChange('refund_point_policy', e.target.value)}
                style={styles.select}
              >
                <option value="deduct_unvested_first">Deduct pending points first, then available</option>
                <option value="deduct_available_first">Deduct available points first</option>
                <option value="proportional">Deduct proportionally from both</option>
              </select>
            </div>

            <div style={styles.formRow}>
              <label style={styles.label}>Email Notifications</label>
              <div style={styles.buttonGroup}>
                <button
                  style={{
                    ...styles.toggleButton,
                    ...(settings.email_point_summaries ? styles.toggleButtonActive : {})
                  }}
                  onClick={() => handleInputChange('email_point_summaries', true)}
                >
                  Yes
                </button>
                <button
                  style={{
                    ...styles.toggleButton,
                    ...(!settings.email_point_summaries ? styles.toggleButtonActive : {})
                  }}
                  onClick={() => handleInputChange('email_point_summaries', false)}
                >
                  No
                </button>
              </div>
              <div style={styles.helperText}>
                Send monthly point summary emails
              </div>
            </div>

            <div style={styles.formRow}>
              <label style={styles.label}>SMS Alerts</label>
              <div style={styles.buttonGroup}>
                <button
                  style={{
                    ...styles.toggleButton,
                    ...(settings.sms_balance_alerts ? styles.toggleButtonActive : {})
                  }}
                  onClick={() => handleInputChange('sms_balance_alerts', true)}
                >
                  Yes
                </button>
                <button
                  style={{
                    ...styles.toggleButton,
                    ...(!settings.sms_balance_alerts ? styles.toggleButtonActive : {})
                  }}
                  onClick={() => handleInputChange('sms_balance_alerts', false)}
                >
                  No
                </button>
              </div>
              <div style={styles.helperText}>
                Send SMS for balance milestones
              </div>
            </div>
          </div>
        )}

        {/* Security & Fraud Tab */}
        {activeTab === 'security' && (
          <div style={styles.section}>
            <h3 style={styles.sectionTitle}>Security & Fraud Prevention</h3>
            
            <div style={styles.formRow}>
              <label style={styles.label}>Require ID for Large Redemptions</label>
              <div style={styles.buttonGroup}>
                <button
                  style={{
                    ...styles.toggleButton,
                    ...(settings.require_id_for_large_redemptions ? styles.toggleButtonActive : {})
                  }}
                  onClick={() => handleInputChange('require_id_for_large_redemptions', true)}
                >
                  Yes
                </button>
                <button
                  style={{
                    ...styles.toggleButton,
                    ...(!settings.require_id_for_large_redemptions ? styles.toggleButtonActive : {})
                  }}
                  onClick={() => handleInputChange('require_id_for_large_redemptions', false)}
                >
                  No
                </button>
              </div>
            </div>

            {settings.require_id_for_large_redemptions && (
              <div style={styles.formRow}>
                <label style={styles.label}>Large Redemption Threshold</label>
                <input
                  type="number"
                  value={settings.large_redemption_threshold}
                  onChange={(e) => handleInputChange('large_redemption_threshold', parseInt(e.target.value) || 50000)}
                  step={settings.loyalty_mode === 'points' ? '10000' : '50'}
                  min="0"
                  style={styles.input}
                />
                <div style={styles.helperText}>
                  Require ID when redeeming above this amount in a single transaction
                </div>
              </div>
            )}

            <div style={styles.formRow}>
              <label style={styles.label}>Suspicious Activity Threshold</label>
              <input
                type="number"
                value={settings.suspicious_activity_threshold}
                onChange={(e) => handleInputChange('suspicious_activity_threshold', parseInt(e.target.value) || 10000)}
                step={settings.loyalty_mode === 'points' ? '1000' : '10'}
                min="0"
                style={styles.input}
              />
              <div style={styles.helperText}>
                Flag unusual earning patterns above this daily amount
              </div>
            </div>
          </div>
        )}

        {/* Family Features Tab */}
        {activeTab === 'family' && (
          <div style={styles.section}>
            <h3 style={styles.sectionTitle}>Family & Household Features</h3>
            
            <div style={styles.formRow}>
              <label style={styles.label}>Family Account Pooling</label>
              <div style={styles.buttonGroup}>
                <button
                  style={{
                    ...styles.toggleButton,
                    ...(settings.allow_family_pooling ? styles.toggleButtonActive : {})
                  }}
                  onClick={() => handleInputChange('allow_family_pooling', true)}
                >
                  Yes
                </button>
                <button
                  style={{
                    ...styles.toggleButton,
                    ...(!settings.allow_family_pooling ? styles.toggleButtonActive : {})
                  }}
                  onClick={() => handleInputChange('allow_family_pooling', false)}
                >
                  No
                </button>
              </div>
              <div style={styles.helperText}>
                Allow families to combine points/credits
              </div>
            </div>

            {settings.allow_family_pooling && (
              <React.Fragment>
                <div style={styles.formRow}>
                  <label style={styles.label}>Maximum Linked Accounts</label>
                  <input
                    type="number"
                    value={settings.max_linked_accounts}
                    onChange={(e) => handleInputChange('max_linked_accounts', parseInt(e.target.value) || 5)}
                    min="2"
                    max="10"
                    style={styles.input}
                  />
                </div>

                <div style={styles.formRow}>
                  <label style={styles.label}>Allow Point Transfers</label>
                  <div style={styles.buttonGroup}>
                    <button
                      style={{
                        ...styles.toggleButton,
                        ...(settings.allow_point_transfers ? styles.toggleButtonActive : {})
                      }}
                      onClick={() => handleInputChange('allow_point_transfers', true)}
                    >
                      Yes
                    </button>
                    <button
                      style={{
                        ...styles.toggleButton,
                        ...(!settings.allow_point_transfers ? styles.toggleButtonActive : {})
                      }}
                      onClick={() => handleInputChange('allow_point_transfers', false)}
                    >
                      No
                    </button>
                  </div>
                  <div style={styles.helperText}>
                    Let family members transfer points between accounts
                  </div>
                </div>
              </React.Fragment>
            )}
          </div>
        )}

        {/* Bonus Campaigns Tab */}
        {activeTab === 'campaigns' && (
          <div style={styles.section}>
            <h3 style={styles.sectionTitle}>Bonus Campaigns & Special Rewards</h3>
            
            <div style={styles.formRow}>
              <label style={styles.label}>Enable Bonus Campaigns</label>
              <div style={styles.buttonGroup}>
                <button
                  style={{
                    ...styles.toggleButton,
                    ...(settings.enable_bonus_campaigns ? styles.toggleButtonActive : {})
                  }}
                  onClick={() => handleInputChange('enable_bonus_campaigns', true)}
                >
                  Yes
                </button>
                <button
                  style={{
                    ...styles.toggleButton,
                    ...(!settings.enable_bonus_campaigns ? styles.toggleButtonActive : {})
                  }}
                  onClick={() => handleInputChange('enable_bonus_campaigns', false)}
                >
                  No
                </button>
              </div>
              <div style={styles.helperText}>
                Allow special promotions and bonus earning events
              </div>
            </div>

            {settings.enable_bonus_campaigns && (
              <React.Fragment>
                <div style={styles.formRow}>
                  <label style={styles.label}>Welcome Bonus</label>
                  <input
                    type="number"
                    value={settings.welcome_bonus}
                    onChange={(e) => handleInputChange('welcome_bonus', parseInt(e.target.value) || 0)}
                    step={settings.loyalty_mode === 'points' ? '100' : '1'}
                    min="0"
                    style={styles.input}
                  />
                  <div style={styles.helperText}>
                    {settings.loyalty_mode === 'points' ? 'Points' : 'Dollars'} awarded for signing up
                  </div>
                </div>

                <div style={styles.formRow}>
                  <label style={styles.label}>Birthday Bonus</label>
                  <input
                    type="number"
                    value={settings.birthday_bonus}
                    onChange={(e) => handleInputChange('birthday_bonus', parseInt(e.target.value) || 0)}
                    step={settings.loyalty_mode === 'points' ? '100' : '1'}
                    min="0"
                    style={styles.input}
                  />
                  <div style={styles.helperText}>
                    Annual birthday reward
                  </div>
                </div>

                <div style={styles.formRow}>
                  <label style={styles.label}>Review Bonus</label>
                  <input
                    type="number"
                    value={settings.review_bonus}
                    onChange={(e) => handleInputChange('review_bonus', parseInt(e.target.value) || 0)}
                    step={settings.loyalty_mode === 'points' ? '10' : '0.5'}
                    min="0"
                    style={styles.input}
                  />
                  <div style={styles.helperText}>
                    Reward for leaving product/service reviews
                  </div>
                </div>
              </React.Fragment>
            )}
          </div>
        )}

        {error && (
          <div style={styles.errorBanner}>
            {error}
          </div>
        )}

        {success && (
          <div style={styles.successBanner}>
            Loyalty settings saved successfully!
          </div>
        )}

        <div style={styles.actions}>
          <button
            style={styles.saveButton}
            onClick={handleSave}
            disabled={saving}
          >
            {saving ? 'Saving...' : 'Save All Settings'}
          </button>
        </div>
      </div>
    </div>
  );
};

const styles = {
  container: {
    display: 'flex',
    flexDirection: 'column',
    height: '100vh',
    backgroundColor: '#f8f9fa',
    padding: '20px',
    paddingTop: '100px',
    boxSizing: 'border-box'
  },
  header: {
    marginBottom: '20px',
    textAlign: 'center'
  },
  tabNav: {
    display: 'flex',
    gap: '5px',
    marginBottom: '20px',
    borderBottom: '2px solid #e5e7eb',
    paddingBottom: '10px',
    flexWrap: 'wrap'
  },
  tabButton: {
    padding: '8px 16px',
    backgroundColor: 'white',
    border: '1px solid #d1d5db',
    borderRadius: '6px 6px 0 0',
    cursor: 'pointer',
    fontSize: '14px',
    fontWeight: 'bold',
    color: '#6b7280'
  },
  tabButtonActive: {
    backgroundColor: '#008080',
    color: 'white',
    borderColor: '#008080'
  },
  content: {
    flex: 1,
    overflowY: 'auto',
    marginBottom: '20px'
  },
  section: {
    backgroundColor: 'white',
    borderRadius: '8px',
    padding: '25px',
    marginBottom: '20px',
    border: '1px solid #e5e7eb'
  },
  sectionTitle: {
    margin: '0 0 20px 0',
    fontSize: '18px',
    fontWeight: 'bold',
    color: '#1f2937',
    borderBottom: '2px solid #008080',
    paddingBottom: '8px'
  },
  formRow: {
    marginBottom: '20px'
  },
  label: {
    display: 'block',
    fontSize: '14px',
    fontWeight: 'bold',
    color: '#374151',
    marginBottom: '8px'
  },
  input: {
    width: '100%',
    padding: '10px',
    border: '2px solid #d1d5db',
    borderRadius: '6px',
    fontSize: '14px',
    boxSizing: 'border-box'
  },
  select: {
    width: '100%',
    padding: '10px',
    border: '2px solid #d1d5db',
    borderRadius: '6px',
    fontSize: '14px',
    boxSizing: 'border-box',
    backgroundColor: 'white'
  },
  buttonGroup: {
    display: 'flex',
    gap: '8px'
  },
  toggleButton: {
    padding: '8px 20px',
    borderWidth: '2px',
    borderStyle: 'solid',
    borderColor: '#d1d5db',
    borderRadius: '6px',
    backgroundColor: 'white',
    color: '#374151',
    fontSize: '14px',
    fontWeight: 'bold',
    cursor: 'pointer',
    minWidth: '60px',
    textAlign: 'center'
  },
  toggleButtonActive: {
    backgroundColor: '#008080',
    borderColor: '#008080',
    color: 'white'
  },
  toggleContainer: {
    display: 'flex',
    alignItems: 'center'
  },
  toggleLabel: {
    display: 'flex',
    alignItems: 'center',
    fontSize: '14px',
    fontWeight: 'normal',
    cursor: 'pointer'
  },
  checkbox: {
    marginRight: '8px',
    transform: 'scale(1.2)'
  },
  flexRow: {
    display: 'flex',
    alignItems: 'center',
    gap: '10px'
  },
  flexText: {
    fontSize: '14px',
    fontWeight: 'bold',
    color: '#374151'
  },
  helperText: {
    fontSize: '12px',
    color: '#6b7280',
    marginTop: '4px',
    fontStyle: 'italic'
  },
  errorBanner: {
    backgroundColor: '#fee2e2',
    color: '#dc2626',
    padding: '15px',
    borderRadius: '6px',
    marginBottom: '20px',
    border: '1px solid #fecaca'
  },
  successBanner: {
    backgroundColor: '#d1fae5',
    color: '#065f46',
    padding: '15px',
    borderRadius: '6px',
    marginBottom: '20px',
    border: '1px solid #a7f3d0'
  },
  actions: {
    display: 'flex',
    justifyContent: 'center',
    paddingTop: '20px'
  },
  saveButton: {
    padding: '15px 40px',
    backgroundColor: '#008080',
    color: 'white',
    border: 'none',
    borderRadius: '8px',
    fontSize: '16px',
    fontWeight: 'bold',
    cursor: 'pointer',
    minWidth: '150px'
  },
  loading: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    height: '200px',
    fontSize: '18px',
    color: '#6b7280'
  },
  error: {
    textAlign: 'center',
    padding: '40px',
    color: '#dc2626'
  }
};

export default LoyaltySettings;