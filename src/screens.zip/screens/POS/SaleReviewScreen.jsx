// screens/POS/SaleReviewScreen.jsx
import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { supabase } from '../../supabaseClient';

const SaleReviewScreen = () => {
  const navigate = useNavigate();
  const location = useLocation();
  
  // Authentication state
  const [authUser, setAuthUser] = useState(null);
  const [selectedBusinessId, setSelectedBusinessId] = useState(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [authError, setAuthError] = useState(null);
  
  const [cartData, setCartData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [businessSettings, setBusinessSettings] = useState({});
  const [loyaltyCustomer, setLoyaltyCustomer] = useState(null);
  const [dailyUsage, setDailyUsage] = useState(null);
  const [showReceiptModal, setShowReceiptModal] = useState(false);
  const [selectedTransaction, setSelectedTransaction] = useState(null);

  // Get cart data from navigation state
  const checkoutData = location.state?.checkoutData;

  // Authentication and business context setup
  useEffect(() => {
    const initializeAuth = async () => {
      try {
        console.log('SaleReviewScreen: Initializing authentication...');
        
        const { data: { session }, error } = await supabase.auth.getSession();
        console.log('SaleReviewScreen: Session check result:', { session: !!session, error });

        if (error || !session?.user) {
          console.error('SaleReviewScreen: No valid session, redirecting to login');
          navigate('/login');
          return;
        }

        setAuthUser(session.user);
        console.log('SaleReviewScreen: Authenticated as:', session.user.email);

        const currentBusinessId = localStorage.getItem('currentBusinessId');
        console.log('SaleReviewScreen: Business ID from localStorage:', currentBusinessId);

        if (!currentBusinessId) {
          setAuthError('No business selected');
          return;
        }

        setSelectedBusinessId(currentBusinessId);

        // Verify user has access to this business
        const { data: userRole, error: roleError } = await supabase
          .from('user_roles')
          .select('*')
          .eq('user_id', session.user.id)
          .eq('business_id', currentBusinessId)
          .eq('active', true)
          .single();

        if (roleError || !userRole) {
          console.error('SaleReviewScreen: User not authorized for this business:', roleError);
          setAuthError('Not authorized for this business');
          return;
        }

        console.log('SaleReviewScreen: User role verified:', userRole.role);
        setAuthLoading(false);

      } catch (err) {
        console.error('SaleReviewScreen: Authentication error:', err);
        setAuthError(err.message);
        setAuthLoading(false);
      }
    };

    initializeAuth();
  }, [navigate]);

  useEffect(() => {
    if (!authLoading && selectedBusinessId) {
      if (!checkoutData) {
        setError('No checkout data provided');
        setLoading(false);
        return;
      }

      console.log('Checkout data received:', checkoutData); // Debug log
      loadSaleData();
    }
  }, [authLoading, selectedBusinessId, checkoutData]);

  const loadSaleData = async () => {
    try {
      setLoading(true);

      // Fetch business settings for tax calculation
      const { data: settings, error: settingsError } = await supabase
        .from('pos_settings')
        .select('*')
        .eq('business_id', selectedBusinessId)
        .single();

      if (settingsError) throw settingsError;

      // Fetch loyalty settings separately from pos_loyalty_settings
      const { data: loyaltySettings, error: loyaltyError } = await supabase
        .from('pos_loyalty_settings')
        .select('*')
        .eq('business_id', selectedBusinessId)
        .single();

      // Combine both settings objects
      const enhancedSettings = {
        ...settings,
        // Loyalty settings from pos_loyalty_settings table
        loyalty_mode: loyaltySettings?.loyalty_mode || 'dollars',
        earn_rate_percentage: loyaltySettings?.earn_rate_percentage || 3,
        redemption_rate: loyaltySettings?.redemption_rate || 0.01,
        min_redemption: loyaltySettings?.min_redemption || 5,
        // Add any other loyalty fields from pos_loyalty_settings
        ...loyaltySettings
      };
      
      setBusinessSettings(enhancedSettings);
      console.log('POS settings:', settings); // Debug log
      console.log('Loyalty settings:', loyaltySettings); // Debug log
      console.log('Combined enhanced settings:', enhancedSettings); // Debug log
      console.log('Final loyalty mode:', enhancedSettings.loyalty_mode); // Debug log

      // If loyalty customer is attached, fetch their details and daily usage
      if (checkoutData.loyalty_customer_id) {
        const { data: customer, error: customerError } = await supabase
          .from('pos_loyalty_accounts')
          .select('*')
          .eq('id', checkoutData.loyalty_customer_id)
          .single();

        if (!customerError && customer) {
          setLoyaltyCustomer(customer);
          console.log('Loyalty customer loaded:', customer); // Debug log
          
          // Fetch today's loyalty transactions for this customer
          await loadDailyLoyaltyUsage(checkoutData.loyalty_customer_id);
        }
      }

      // Set cart data from checkout
      setCartData(checkoutData);

    } catch (err) {
      console.error('Error loading sale data:', err);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const loadDailyLoyaltyUsage = async (customerId) => {
    try {
      const today = new Date().toISOString().split('T')[0]; // YYYY-MM-DD format
      
      // Get today's loyalty transactions (redemptions)
      const { data: loyaltyTransactions, error } = await supabase
        .from('pos_loyalty_transactions')
        .select(`
          *,
          pos_sales!inner(sale_number, created_at, final_total)
        `)
        .eq('customer_id', customerId)
        .eq('transaction_type', 'redeem')
        .gte('created_at', today + 'T00:00:00.000Z')
        .lt('created_at', today + 'T23:59:59.999Z')
        .order('created_at', { ascending: false });

      if (!error && loyaltyTransactions && loyaltyTransactions.length > 0) {
        const totalUsedToday = loyaltyTransactions.reduce((sum, transaction) => {
          return sum + Math.abs(transaction.amount); // amount is negative for redemptions
        }, 0);

        setDailyUsage({
          transactions: loyaltyTransactions,
          totalUsed: totalUsedToday
        });
      }
    } catch (err) {
      console.error('Error loading daily loyalty usage:', err);
    }
  };

  const handleTransactionClick = async (saleNumber) => {
    try {
      // Fetch transaction details
      const { data: saleData, error } = await supabase
        .from('pos_sales')
        .select(`
          *,
          pos_sale_items(
            *,
            inventory(name, price)
          ),
          pos_payments(*),
          pos_loyalty_accounts(customer_name, customer_email, customer_phone)
        `)
        .eq('sale_number', saleNumber)
        .eq('business_id', selectedBusinessId)
        .single();

      if (error) throw error;

      setSelectedTransaction(saleData);
      setShowReceiptModal(true);
    } catch (err) {
      console.error('Error fetching transaction:', err);
      alert('Could not load transaction details');
    }
  };

  const handleBackToRegister = () => {
    navigate('/dashboard/pos/register');
  };

  const handleProceedToPayment = () => {
    // Pass sale data to payment screen
    navigate('/dashboard/pos/payment', {
      state: {
        saleData: {
          ...cartData,
          businessSettings,
          loyaltyCustomer,
          business_id: selectedBusinessId
        }
      }
    });
  };

  const renderLoyaltyBalance = () => {
    if (!loyaltyCustomer) return null;

    // Check if in points mode
    const isPointsMode = businessSettings.loyalty_mode === 'points';
    const dollarBalance = loyaltyCustomer.balance || 0;
    
    // Points conversion: 10,000 points = $10, so 1,000 points = $1
    const pointsPerDollar = 1000;

    console.log('Loyalty mode:', businessSettings.loyalty_mode); // Debug
    console.log('Is points mode:', isPointsMode); // Debug
    console.log('Dollar balance from DB:', dollarBalance); // Debug

    if (isPointsMode) {
      // Calculate points from dollar balance: $20.57 × 1000 = 20,570 points
      const calculatedPoints = Math.round(dollarBalance * pointsPerDollar);
      console.log('Calculated points:', calculatedPoints); // Debug
      return `Balance: ${calculatedPoints.toLocaleString()} points`;
    } else {
      return `Balance: $${dollarBalance.toFixed(2)}`;
    }
  };

  const renderDailyUsage = () => {
    if (!dailyUsage || !dailyUsage.transactions.length) return null;

    const isPointsMode = businessSettings.loyalty_mode === 'points';
    const totalUsedDisplay = isPointsMode 
      ? `${Math.round(dailyUsage.totalUsed * 1000).toLocaleString()} points`
      : `$${dailyUsage.totalUsed.toFixed(2)}`;

    return (
      <div style={styles.dailyUsage}>
        <div style={styles.usageHeader}>
          Used today: {totalUsedDisplay}
        </div>
        {dailyUsage.transactions.map((transaction, index) => (
          <div key={index} style={styles.usageTransaction}>
            <span 
              style={styles.transactionNumber}
              onClick={() => handleTransactionClick(transaction.pos_sales.sale_number)}
            >
              #{transaction.pos_sales.sale_number}
            </span>
            <span style={styles.transactionAmount}>
              {isPointsMode 
                ? `-${Math.round(Math.abs(transaction.amount) * 1000).toLocaleString()} pts`
                : `-$${Math.abs(transaction.amount).toFixed(2)}`
              }
            </span>
            <span style={styles.transactionTime}>
              {new Date(transaction.created_at).toLocaleTimeString()}
            </span>
          </div>
        ))}
      </div>
    );
  };

  // Loading and error states for authentication
  if (authLoading) {
    return (
      <div style={{...styles.container, justifyContent: 'center', alignItems: 'center'}}>
        <h3>Loading Sale Review...</h3>
        <p>Authenticating user and loading business data...</p>
      </div>
    );
  }

  if (authError) {
    return (
      <div style={{...styles.container, justifyContent: 'center', alignItems: 'center'}}>
        <h3>Authentication Error</h3>
        <p>{authError}</p>
        <button 
          style={styles.backButton}
          onClick={() => navigate('/login')}
        >
          Return to Login
        </button>
      </div>
    );
  }

  if (loading) {
    return (
      <div style={styles.container}>
        <div style={styles.loading}>
          <div>Loading sale review...</div>
          <div style={{ fontSize: '14px', marginTop: '10px' }}>
            Business ID: {selectedBusinessId || 'Not selected'}
          </div>
          {checkoutData && (
            <div style={{ fontSize: '14px', marginTop: '5px' }}>
              Items count: {checkoutData.items?.length || 0}
            </div>
          )}
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div style={styles.container}>
        <div style={styles.error}>
          <h3>Error</h3>
          <p>{error}</p>
          <div style={{ fontSize: '14px', marginTop: '10px', color: '#666' }}>
            Debug Info:
            <br />Business ID: {selectedBusinessId || 'Not selected'}
            <br />Checkout Data: {checkoutData ? 'Present' : 'Missing'}
            {checkoutData && (
              <>
                <br />Items: {checkoutData.items?.length || 'No items'}
                <br />Total: ${checkoutData.total_amount?.toFixed(2) || 'No total'}
              </>
            )}
          </div>
          <button style={styles.backButton} onClick={handleBackToRegister}>
            Back to Register
          </button>
        </div>
      </div>
    );
  }

  if (!cartData) {
    return (
      <div style={styles.container}>
        <div style={styles.error}>
          <h3>No Sale Data</h3>
          <p>No items to review</p>
          <button style={styles.backButton} onClick={handleBackToRegister}>
            Back to Register
          </button>
        </div>
      </div>
    );
  }

  return (
    <div style={styles.container}>
      <div style={styles.header}>
        <h2>Review Sale</h2>
        <p>Please review the order details before proceeding to payment</p>
      </div>

      <div style={styles.content}>
        {/* Cart Items Review */}
        <div style={styles.section}>
          <h3 style={styles.sectionTitle}>Items ({cartData.item_count})</h3>
          <div style={styles.itemsList}>
            {cartData.items?.map((item, index) => (
              <div key={index} style={styles.item}>
                <div style={styles.itemInfo}>
                  <div style={styles.itemName}>{item.name}</div>
                  {item.modifiers && item.modifiers.length > 0 && (
                    <div style={styles.modifiers}>
                      {item.modifiers.map((mod, modIndex) => (
                        <div key={modIndex} style={styles.modifier}>
                          {mod.required ? '• ' : '+ '}{mod.name}
                          {mod.price > 0 && <span> (+${Number(mod.price).toFixed(2)})</span>}
                        </div>
                      ))}
                    </div>
                  )}
                  {item.notes && (
                    <div style={styles.notes}>Note: {item.notes}</div>
                  )}
                </div>
                <div style={styles.itemDetails}>
                  <div style={styles.quantity}>Qty: {item.quantity}</div>
                  <div style={styles.price}>${(item.price * item.quantity).toFixed(2)}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Customer Information */}
        {loyaltyCustomer && (
          <div style={styles.section}>
            <h3 style={styles.sectionTitle}>Customer</h3>
            <div style={styles.customerInfo}>
              <div style={styles.customerName}>{loyaltyCustomer.customer_name}</div>
              {loyaltyCustomer.customer_email && (
                <div style={styles.customerDetail}>{loyaltyCustomer.customer_email}</div>
              )}
              {loyaltyCustomer.customer_phone && (
                <div style={styles.customerDetail}>{loyaltyCustomer.customer_phone}</div>
              )}
              <div style={styles.loyaltyBalance}>
                {renderLoyaltyBalance()}
              </div>
              {renderDailyUsage()}
            </div>
          </div>
        )}

        {/* Sale Totals */}
        <div style={styles.section}>
          <h3 style={styles.sectionTitle}>Order Total</h3>
          <div style={styles.totals}>
            <div style={styles.totalRow}>
              <span>Subtotal</span>
              <span>${cartData.subtotal.toFixed(2)}</span>
            </div>

            {cartData.discount_amount > 0 && (
              <div style={styles.totalRowDiscount}>
                <span>Discount</span>
                <span>-${cartData.discount_amount.toFixed(2)}</span>
              </div>
            )}

            {cartData.loyalty_redemption > 0 && (
              <div style={styles.totalRowLoyalty}>
                <span>
                  {businessSettings.loyalty_mode === 'points' ? 'Points Redemption' : 'Loyalty Redemption'}
                </span>
                <span>
                  {businessSettings.loyalty_mode === 'points' 
                    ? `-${Math.round(cartData.loyalty_redemption * 1000).toLocaleString()} pts`
                    : `-$${cartData.loyalty_redemption.toFixed(2)}`
                  }
                </span>
              </div>
            )}

            <div style={styles.totalRow}>
              <span>Tax ({(businessSettings.tax_rate * 100 || 0).toFixed(1)}%)</span>
              <span>${cartData.tax_amount.toFixed(2)}</span>
            </div>

            {businessSettings.service_fee > 0 && (
              <div style={styles.totalRow}>
                <span>Service Fee</span>
                <span>${((cartData.subtotal * businessSettings.service_fee) || 0).toFixed(2)}</span>
              </div>
            )}

            <div style={styles.totalRowFinal}>
              <span>Total</span>
              <span>${cartData.total_amount.toFixed(2)}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Transaction Receipt Modal */}
      {showReceiptModal && selectedTransaction && (
        <div style={styles.modal}>
          <div style={styles.modalContent}>
            <div style={styles.modalHeader}>
              <h3>Transaction #{selectedTransaction.sale_number}</h3>
              <button 
                style={styles.closeButton}
                onClick={() => setShowReceiptModal(false)}
              >
                ×
              </button>
            </div>
            <div style={styles.receiptDetails}>
              <div style={styles.detailRow}>
                <strong>Date:</strong> {new Date(selectedTransaction.created_at).toLocaleString()}
              </div>
              <div style={styles.detailRow}>
                <strong>Total:</strong> ${selectedTransaction.final_total.toFixed(2)}
              </div>
              <div style={styles.detailRow}>
                <strong>Customer:</strong> {selectedTransaction.pos_loyalty_accounts?.customer_name || 'N/A'}
              </div>
              
              <h4 style={styles.itemsHeader}>Items</h4>
              {selectedTransaction.pos_sale_items?.map((item, index) => (
                <div key={index} style={styles.receiptItem}>
                  <span>{item.quantity}x {item.inventory?.name || 'Item'}</span>
                  <span>${(item.price * item.quantity).toFixed(2)}</span>
                </div>
              ))}
              
              <h4 style={styles.itemsHeader}>Payments</h4>
              {selectedTransaction.pos_payments?.map((payment, index) => (
                <div key={index} style={styles.receiptItem}>
                  <span>{payment.method}</span>
                  <span>${payment.amount.toFixed(2)}</span>
                </div>
              ))}
            </div>
            <div style={styles.modalActions}>
              <button 
                style={styles.closeModalButton}
                onClick={() => setShowReceiptModal(false)}
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Action Buttons */}
      <div style={styles.actions}>
        <button style={styles.backButton} onClick={handleBackToRegister}>
          Back to Register
        </button>
        <button style={styles.proceedButton} onClick={handleProceedToPayment}>
          Proceed to Payment - ${cartData.total_amount.toFixed(2)}
        </button>
      </div>
    </div>
  );
};

const styles = {
  container: {
    display: 'flex',
    flexDirection: 'column',
    height: '100vh',
    backgroundColor: '#f8f9fa',
    padding: '20px',
    paddingTop: '100px', // Account for header
    boxSizing: 'border-box'
  },
  header: {
    marginBottom: '30px',
    textAlign: 'center'
  },
  content: {
    flex: 1,
    overflowY: 'auto',
    marginBottom: '20px'
  },
  section: {
    backgroundColor: 'white',
    borderRadius: '8px',
    padding: '20px',
    marginBottom: '20px',
    border: '1px solid #e5e7eb'
  },
  sectionTitle: {
    margin: '0 0 15px 0',
    fontSize: '18px',
    fontWeight: 'bold',
    color: '#1f2937',
    borderBottom: '2px solid #008080',
    paddingBottom: '8px'
  },
  itemsList: {
    display: 'flex',
    flexDirection: 'column',
    gap: '12px'
  },
  item: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    padding: '12px',
    backgroundColor: '#f9fafb',
    borderRadius: '6px',
    border: '1px solid #e5e7eb'
  },
  itemInfo: {
    flex: 1
  },
  itemName: {
    fontSize: '16px',
    fontWeight: '600',
    color: '#1f2937',
    marginBottom: '4px'
  },
  modifiers: {
    marginLeft: '16px',
    fontSize: '14px',
    color: '#6b7280'
  },
  modifier: {
    marginBottom: '2px',
    fontStyle: 'italic'
  },
  notes: {
    marginTop: '8px',
    fontSize: '14px',
    color: '#059669',
    fontStyle: 'italic'
  },
  itemDetails: {
    textAlign: 'right',
    minWidth: '100px'
  },
  quantity: {
    fontSize: '14px',
    color: '#6b7280',
    marginBottom: '4px'
  },
  price: {
    fontSize: '16px',
    fontWeight: '600',
    color: '#1f2937'
  },
  customerInfo: {
    padding: '15px',
    backgroundColor: '#008080',
    color: 'white',
    borderRadius: '6px'
  },
  customerName: {
    fontSize: '18px',
    fontWeight: 'bold',
    marginBottom: '6px'
  },
  customerDetail: {
    fontSize: '14px',
    marginBottom: '4px',
    opacity: 0.9
  },
  loyaltyBalance: {
    fontSize: '14px',
    marginTop: '8px',
    fontWeight: '600',
    backgroundColor: 'rgba(255,255,255,0.2)',
    padding: '6px 10px',
    borderRadius: '4px',
    display: 'inline-block'
  },
  dailyUsage: {
    marginTop: '12px',
    backgroundColor: 'rgba(255,255,255,0.1)',
    padding: '10px',
    borderRadius: '4px',
    borderLeft: '3px solid rgba(255,255,255,0.5)'
  },
  usageHeader: {
    fontSize: '13px',
    fontWeight: '600',
    marginBottom: '8px',
    opacity: 0.9
  },
  usageTransaction: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    fontSize: '12px',
    marginBottom: '4px',
    opacity: 0.9
  },
  transactionNumber: {
    cursor: 'pointer',
    textDecoration: 'underline',
    fontWeight: '600',
    flex: 1
  },
  transactionAmount: {
    fontWeight: '600',
    marginRight: '10px'
  },
  transactionTime: {
    fontSize: '11px',
    opacity: 0.7
  },
  totals: {
    display: 'flex',
    flexDirection: 'column',
    gap: '8px'
  },
  totalRow: {
    display: 'flex',
    justifyContent: 'space-between',
    fontSize: '16px',
    color: '#1f2937'
  },
  totalRowDiscount: {
    display: 'flex',
    justifyContent: 'space-between',
    fontSize: '16px',
    color: '#dc2626',
    fontWeight: '500'
  },
  totalRowLoyalty: {
    display: 'flex',
    justifyContent: 'space-between',
    fontSize: '16px',
    color: '#059669',
    fontWeight: '500'
  },
  totalRowFinal: {
    display: 'flex',
    justifyContent: 'space-between',
    fontSize: '20px',
    fontWeight: 'bold',
    color: '#1f2937',
    paddingTop: '12px',
    borderTop: '2px solid #008080',
    marginTop: '8px'
  },
  actions: {
    display: 'flex',
    gap: '15px',
    justifyContent: 'space-between'
  },
  backButton: {
    flex: 1,
    padding: '15px',
    backgroundColor: '#6b7280',
    color: 'white',
    border: 'none',
    borderRadius: '8px',
    fontSize: '16px',
    fontWeight: 'bold',
    cursor: 'pointer',
    transition: 'all 0.2s ease'
  },
  proceedButton: {
    flex: 2,
    padding: '15px',
    backgroundColor: '#008080',
    color: 'white',
    border: 'none',
    borderRadius: '8px',
    fontSize: '16px',
    fontWeight: 'bold',
    cursor: 'pointer',
    transition: 'all 0.2s ease'
  },
  loading: {
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'center',
    alignItems: 'center',
    height: '200px',
    fontSize: '18px',
    color: '#6b7280'
  },
  error: {
    textAlign: 'center',
    padding: '40px',
    color: '#dc2626'
  },
  modal: {
    position: 'fixed',
    top: 0,
    left: 0,
    width: '100%',
    height: '100%',
    background: 'rgba(0,0,0,0.5)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 1000
  },
  modalContent: {
    background: '#fff',
    padding: '30px',
    borderRadius: '8px',
    maxWidth: '600px',
    width: '90%',
    maxHeight: '80vh',
    overflowY: 'auto'
  },
  modalHeader: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: '20px',
    paddingBottom: '15px',
    borderBottom: '2px solid #008080'
  },
  closeButton: {
    background: 'transparent',
    border: 'none',
    fontSize: '24px',
    cursor: 'pointer',
    color: '#6b7280'
  },
  receiptDetails: {
    marginBottom: '20px'
  },
  detailRow: {
    padding: '8px 0',
    borderBottom: '1px solid #f3f4f6',
    fontSize: '14px'
  },
  itemsHeader: {
    marginTop: '20px',
    marginBottom: '10px',
    fontSize: '16px',
    fontWeight: 'bold',
    color: '#1f2937'
  },
  receiptItem: {
    display: 'flex',
    justifyContent: 'space-between',
    padding: '6px 0',
    fontSize: '14px',
    borderBottom: '1px solid #f9fafb'
  },
  modalActions: {
    display: 'flex',
    justifyContent: 'flex-end'
  },
  closeModalButton: {
    backgroundColor: '#6b7280',
    color: 'white',
    border: 'none',
    padding: '10px 20px',
    borderRadius: '6px',
    cursor: 'pointer',
    fontSize: '14px',
    fontWeight: 'bold'
  }
};

export default SaleReviewScreen;