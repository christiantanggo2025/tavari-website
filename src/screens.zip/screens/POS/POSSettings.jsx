// src/screens/POS/POSSettings.jsx
import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../../supabaseClient';
import { logAction } from '../../helpers/posAudit';

const POSSettings = () => {
  const navigate = useNavigate();

  // Authentication state - STANDARDIZED to match other POS screens
  const [authUser, setAuthUser] = useState(null);
  const [selectedBusinessId, setSelectedBusinessId] = useState(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [authError, setAuthError] = useState(null);

  const [settings, setSettings] = useState({
    terminal_mode: 'manual',
    pin_required: false,
    tip_enabled: true,
    default_tip_percent: 0.15,
    tax_rate: 0,
    service_fee: 0,
    receipt_footer: ''
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [saveSuccess, setSaveSuccess] = useState(false);

  // Authentication and business context setup - STANDARDIZED
  useEffect(() => {
    const initializeAuth = async () => {
      try {
        console.log('POSSettings: Initializing authentication...');
        
        const { data: { session }, error } = await supabase.auth.getSession();
        console.log('POSSettings: Session check result:', { session: !!session, error });

        if (error || !session?.user) {
          console.error('POSSettings: No valid session, redirecting to login');
          navigate('/login');
          return;
        }

        setAuthUser(session.user);
        console.log('POSSettings: Authenticated as:', session.user.email);

        const currentBusinessId = localStorage.getItem('currentBusinessId');
        console.log('POSSettings: Business ID from localStorage:', currentBusinessId);

        if (!currentBusinessId) {
          setAuthError('No business selected');
          return;
        }

        setSelectedBusinessId(currentBusinessId);

        // Verify user has access to this business
        const { data: userRole, error: roleError } = await supabase
          .from('user_roles')
          .select('*')
          .eq('user_id', session.user.id)
          .eq('business_id', currentBusinessId)
          .eq('active', true)
          .single();

        if (roleError || !userRole) {
          console.error('POSSettings: User not authorized for this business:', roleError);
          setAuthError('Not authorized for this business');
          return;
        }

        // Check if user has permission to modify settings
        if (!['owner', 'manager'].includes(userRole.role)) {
          setAuthError('Insufficient permissions to access POS settings');
          return;
        }

        console.log('POSSettings: User role verified:', userRole.role);
        setAuthLoading(false);

      } catch (err) {
        console.error('POSSettings: Authentication error:', err);
        setAuthError(err.message);
        setAuthLoading(false);
      }
    };

    initializeAuth();
  }, [navigate]);

  // Fetch settings on load - only runs after auth is complete
  useEffect(() => {
    if (selectedBusinessId) {
      fetchSettings();
    }
  }, [selectedBusinessId]);

  const fetchSettings = async () => {
    setLoading(true);
    setError(null);
    
    try {
      const { data, error } = await supabase
        .from('pos_settings')
        .select('*')
        .eq('business_id', selectedBusinessId)
        .single();

      if (error && error.code !== 'PGRST116') throw error;

      if (data) {
        setSettings(data);
      } else {
        // No row exists? Insert defaults
        const defaultSettings = {
          business_id: selectedBusinessId,
          terminal_mode: 'manual',
          pin_required: false,
          tip_enabled: true,
          default_tip_percent: 0.15,
          tax_rate: 0.13, // Default to 13% HST for Canada
          service_fee: 0,
          receipt_footer: 'Thank you for your business!',
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        };

        const { data: insertData, error: insertError } = await supabase
          .from('pos_settings')
          .insert([defaultSettings])
          .select()
          .single();

        if (insertError) throw insertError;

        setSettings(insertData);

        await logAction({
          action: 'pos_settings_created',
          context: 'POSSettings',
          metadata: {
            business_id: selectedBusinessId,
            settings: defaultSettings
          }
        });
      }
    } catch (err) {
      console.error('Error loading settings:', err);
      setError('Error loading settings: ' + err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    setError(null);
    setSaveSuccess(false);
    
    try {
      const updatedSettings = {
        terminal_mode: settings.terminal_mode,
        pin_required: settings.pin_required,
        tip_enabled: settings.tip_enabled,
        default_tip_percent: Number(settings.default_tip_percent),
        tax_rate: Number(settings.tax_rate),
        service_fee: Number(settings.service_fee),
        receipt_footer: settings.receipt_footer?.trim() || '',
        updated_at: new Date().toISOString()
      };

      const { error } = await supabase
        .from('pos_settings')
        .update(updatedSettings)
        .eq('business_id', selectedBusinessId);

      if (error) throw error;

      setSaveSuccess(true);
      
      // Clear success message after 3 seconds
      setTimeout(() => setSaveSuccess(false), 3000);

      await logAction({
        action: 'pos_settings_updated',
        context: 'POSSettings',
        metadata: {
          business_id: selectedBusinessId,
          updated_settings: updatedSettings
        }
      });

    } catch (err) {
      console.error('Error saving settings:', err);
      setError('Error saving settings: ' + err.message);
    }
  };

  const handleInputChange = (field, value) => {
    setSettings(prev => ({
      ...prev,
      [field]: value
    }));
    setSaveSuccess(false); // Clear success message when user makes changes
  };

  const resetToDefaults = async () => {
    if (!window.confirm('Are you sure you want to reset all settings to defaults? This cannot be undone.')) {
      return;
    }

    const defaultSettings = {
      terminal_mode: 'manual',
      pin_required: false,
      tip_enabled: true,
      default_tip_percent: 0.15,
      tax_rate: 0.13,
      service_fee: 0,
      receipt_footer: 'Thank you for your business!'
    };

    setSettings(prev => ({ ...prev, ...defaultSettings }));
    
    await logAction({
      action: 'pos_settings_reset',
      context: 'POSSettings',
      metadata: {
        business_id: selectedBusinessId
      }
    });
  };

  // Loading and error states - STANDARDIZED
  if (authLoading) {
    return (
      <div style={styles.container}>
        <div style={styles.loading}>
          <h3>Loading POS Settings...</h3>
          <p>Authenticating user and loading business data...</p>
        </div>
      </div>
    );
  }

  if (authError) {
    return (
      <div style={styles.container}>
        <div style={styles.error}>
          <h3>Authentication Error</h3>
          <p>{authError}</p>
          <button 
            style={styles.button}
            onClick={() => navigate('/login')}
          >
            Return to Login
          </button>
        </div>
      </div>
    );
  }

  return (
    <div style={styles.container}>
      <div style={styles.header}>
        <h2>POS Settings</h2>
        <p>Configure your point-of-sale system settings</p>
      </div>

      {error && <div style={styles.errorBanner}>{error}</div>}
      {saveSuccess && <div style={styles.successBanner}>Settings saved successfully!</div>}

      {loading ? (
        <div style={styles.loadingSettings}>Loading settings...</div>
      ) : (
        <div style={styles.content}>
          <div style={styles.settingsGrid}>
            {/* Terminal Settings */}
            <div style={styles.section}>
              <h3 style={styles.sectionTitle}>Terminal Settings</h3>
              
              <div style={styles.setting}>
                <label style={styles.label}>Terminal Mode:</label>
                <select
                  value={settings.terminal_mode}
                  onChange={(e) => handleInputChange('terminal_mode', e.target.value)}
                  style={styles.select}
                >
                  <option value="manual">Manual</option>
                  <option value="integrated">Integrated</option>
                </select>
                <div style={styles.settingDescription}>
                  Manual: Basic POS functionality. Integrated: Advanced features with payment processing.
                </div>
              </div>

              <div style={styles.setting}>
                <label style={styles.checkboxLabel}>
                  <input
                    type="checkbox"
                    checked={settings.pin_required || false}
                    onChange={(e) => handleInputChange('pin_required', e.target.checked)}
                    style={styles.checkbox}
                  />
                  Require PIN for register access
                </label>
                <div style={styles.settingDescription}>
                  When enabled, employees must enter their PIN to access the register.
                </div>
              </div>
            </div>

            {/* Payment Settings */}
            <div style={styles.section}>
              <h3 style={styles.sectionTitle}>Payment Settings</h3>
              
              <div style={styles.setting}>
                <label style={styles.checkboxLabel}>
                  <input
                    type="checkbox"
                    checked={settings.tip_enabled || false}
                    onChange={(e) => handleInputChange('tip_enabled', e.target.checked)}
                    style={styles.checkbox}
                  />
                  Enable tip prompts
                </label>
                <div style={styles.settingDescription}>
                  Show tip options during checkout process.
                </div>
              </div>

              <div style={styles.setting}>
                <label style={styles.label}>Default Tip Percentage:</label>
                <div style={styles.inputGroup}>
                  <input
                    type="number"
                    step="0.01"
                    min="0"
                    max="1"
                    value={settings.default_tip_percent || 0}
                    onChange={(e) => handleInputChange('default_tip_percent', parseFloat(e.target.value) || 0)}
                    style={styles.input}
                  />
                  <span style={styles.inputSuffix}>({((settings.default_tip_percent || 0) * 100).toFixed(1)}%)</span>
                </div>
                <div style={styles.settingDescription}>
                  Default tip percentage suggested to customers (0.15 = 15%).
                </div>
              </div>
            </div>

            {/* Tax & Fee Settings */}
            <div style={styles.section}>
              <h3 style={styles.sectionTitle}>Tax & Fee Settings</h3>
              
              <div style={styles.setting}>
                <label style={styles.label}>Tax Rate:</label>
                <div style={styles.inputGroup}>
                  <input
                    type="number"
                    step="0.01"
                    min="0"
                    max="1"
                    value={settings.tax_rate || 0}
                    onChange={(e) => handleInputChange('tax_rate', parseFloat(e.target.value) || 0)}
                    style={styles.input}
                  />
                  <span style={styles.inputSuffix}>({((settings.tax_rate || 0) * 100).toFixed(1)}%)</span>
                </div>
                <div style={styles.settingDescription}>
                  Tax rate applied to all sales (0.13 = 13% HST for Canada).
                </div>
              </div>

              <div style={styles.setting}>
                <label style={styles.label}>Service Fee:</label>
                <div style={styles.inputGroup}>
                  <input
                    type="number"
                    step="0.01"
                    min="0"
                    max="1"
                    value={settings.service_fee || 0}
                    onChange={(e) => handleInputChange('service_fee', parseFloat(e.target.value) || 0)}
                    style={styles.input}
                  />
                  <span style={styles.inputSuffix}>({((settings.service_fee || 0) * 100).toFixed(1)}%)</span>
                </div>
                <div style={styles.settingDescription}>
                  Optional service fee added to all transactions.
                </div>
              </div>
            </div>

            {/* Receipt Settings */}
            <div style={styles.section}>
              <h3 style={styles.sectionTitle}>Receipt Settings</h3>
              
              <div style={styles.setting}>
                <label style={styles.label}>Receipt Footer Message:</label>
                <textarea
                  value={settings.receipt_footer || ''}
                  onChange={(e) => handleInputChange('receipt_footer', e.target.value)}
                  placeholder="Thank you for your business!"
                  style={styles.textarea}
                  rows="3"
                />
                <div style={styles.settingDescription}>
                  Custom message printed at the bottom of all receipts.
                </div>
              </div>
            </div>
          </div>

          <div style={styles.actions}>
            <button
              style={styles.resetButton}
              onClick={resetToDefaults}
            >
              Reset to Defaults
            </button>
            <button
              style={styles.saveButton}
              onClick={handleSave}
              disabled={loading}
            >
              {loading ? 'Saving...' : 'Save Settings'}
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

const styles = {
  container: {
    display: 'flex',
    flexDirection: 'column',
    height: '100vh',
    backgroundColor: '#f8f9fa',
    padding: '20px',
    paddingTop: '100px',
    boxSizing: 'border-box'
  },
  header: {
    marginBottom: '30px',
    textAlign: 'center'
  },
  loading: {
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'center',
    alignItems: 'center',
    height: '200px',
    textAlign: 'center'
  },
  error: {
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'center',
    alignItems: 'center',
    height: '200px',
    textAlign: 'center'
  },
  errorBanner: {
    backgroundColor: '#fee2e2',
    color: '#dc2626',
    padding: '15px',
    borderRadius: '6px',
    marginBottom: '20px'
  },
  successBanner: {
    backgroundColor: '#d1fae5',
    color: '#059669',
    padding: '15px',
    borderRadius: '6px',
    marginBottom: '20px'
  },
  loadingSettings: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    height: '200px',
    fontSize: '18px',
    color: '#6b7280'
  },
  content: {
    flex: 1,
    overflowY: 'auto'
  },
  settingsGrid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fit, minmax(400px, 1fr))',
    gap: '20px',
    marginBottom: '30px'
  },
  section: {
    backgroundColor: 'white',
    padding: '20px',
    borderRadius: '8px',
    border: '1px solid #e5e7eb',
    boxShadow: '0 1px 3px rgba(0,0,0,0.1)'
  },
  sectionTitle: {
    fontSize: '18px',
    fontWeight: 'bold',
    color: '#1f2937',
    marginBottom: '20px',
    paddingBottom: '10px',
    borderBottom: '2px solid #008080'
  },
  setting: {
    marginBottom: '20px'
  },
  label: {
    display: 'block',
    fontSize: '14px',
    fontWeight: 'bold',
    color: '#374151',
    marginBottom: '6px'
  },
  checkboxLabel: {
    display: 'flex',
    alignItems: 'center',
    gap: '8px',
    fontSize: '14px',
    fontWeight: 'bold',
    color: '#374151',
    cursor: 'pointer'
  },
  input: {
    padding: '10px',
    border: '2px solid #d1d5db',
    borderRadius: '6px',
    fontSize: '14px',
    width: '120px'
  },
  inputGroup: {
    display: 'flex',
    alignItems: 'center',
    gap: '8px'
  },
  inputSuffix: {
    fontSize: '14px',
    color: '#6b7280'
  },
  select: {
    padding: '10px',
    border: '2px solid #d1d5db',
    borderRadius: '6px',
    fontSize: '14px',
    backgroundColor: 'white',
    minWidth: '150px'
  },
  checkbox: {
    width: '16px',
    height: '16px'
  },
  textarea: {
    width: '100%',
    padding: '10px',
    border: '2px solid #d1d5db',
    borderRadius: '6px',
    fontSize: '14px',
    fontFamily: 'inherit',
    resize: 'vertical',
    minHeight: '60px'
  },
  settingDescription: {
    fontSize: '12px',
    color: '#6b7280',
    marginTop: '4px',
    fontStyle: 'italic'
  },
  actions: {
    display: 'flex',
    gap: '15px',
    justifyContent: 'center',
    paddingTop: '20px',
    borderTop: '1px solid #e5e7eb'
  },
  button: {
    padding: '12px 24px',
    backgroundColor: '#008080',
    color: 'white',
    border: 'none',
    borderRadius: '6px',
    cursor: 'pointer',
    fontSize: '16px',
    fontWeight: 'bold'
  },
  resetButton: {
    padding: '12px 24px',
    backgroundColor: '#6b7280',
    color: 'white',
    border: 'none',
    borderRadius: '6px',
    cursor: 'pointer',
    fontSize: '16px',
    fontWeight: 'bold'
  },
  saveButton: {
    padding: '12px 24px',
    backgroundColor: '#059669',
    color: 'white',
    border: 'none',
    borderRadius: '6px',
    cursor: 'pointer',
    fontSize: '16px',
    fontWeight: 'bold'
  }
};

export default POSSettings;