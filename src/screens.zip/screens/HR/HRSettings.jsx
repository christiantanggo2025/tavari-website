import React, { useState, useEffect } from 'react';
import { supabase } from '../../supabaseClient';
import { useNavigate } from 'react-router-dom';

const HRSettings = () => {
  const [user, setUser] = useState(null);
  const [business, setBusiness] = useState(null);
  const [userRole, setUserRole] = useState(null);
  const [settings, setSettings] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState(null);
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  const defaultSettings = {
    probation_period_days: 90,
    vacation_accrual_rate: 4.00,
    sick_leave_accrual_rate: 2.00,
    auto_generate_employee_numbers: true,
    employee_number_prefix: 'EMP',
    require_manager_approval_writeups: true,
    require_manager_approval_policy_changes: true,
    notification_email: '',
    contract_expiry_warning_days: 30,
    policy_acknowledgment_deadline_days: 14,
    onboarding_completion_required: true,
    document_retention_years: 7,
    allow_employee_self_edit: true,
    require_manager_approval_profile_changes: false
  };

  useEffect(() => {
    checkUserAndBusiness();
  }, []);

  const checkUserAndBusiness = async () => {
    try {
      // Check if user is authenticated
      const { data: { user }, error: userError } = await supabase.auth.getUser();
      
      if (userError || !user) {
        console.error('Authentication error:', userError);
        navigate('/login');
        return;
      }

      setUser(user);

      // Get user's business association and role
      const { data: businessUsers, error: businessError } = await supabase
        .from('business_users')
        .select(`
          business_id, 
          role,
          businesses(id, name)
        `)
        .eq('user_id', user.id)
        .single();

      if (businessError || !businessUsers) {
        console.error('Error loading business:', businessError);
        setError('Unable to load business information. Please contact support.');
        setLoading(false);
        return;
      }

      setBusiness(businessUsers.businesses);
      setUserRole(businessUsers.role);
      
      // Check if user has HR permissions (only owners can access settings)
      const hasSettingsAccess = ['owner'].includes(businessUsers.role.toLowerCase());
      
      if (!hasSettingsAccess) {
        setError('You do not have permission to access HR Settings. Only business owners can modify these settings.');
        setLoading(false);
        return;
      }

      // Load settings
      await loadSettings(businessUsers.business_id);
      
    } catch (error) {
      console.error('Error checking user and business:', error);
      setError('An unexpected error occurred. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const loadSettings = async (businessId) => {
    try {
      // Load settings from hr_settings table
      const { data: existingSettings, error: loadError } = await supabase
        .from('hr_settings')
        .select('*')
        .eq('business_id', businessId)
        .single();

      if (loadError && loadError.code !== 'PGRST116') { // PGRST116 is "no rows returned"
        console.error('Error loading HR settings:', loadError);
        throw loadError;
      }

      if (existingSettings) {
        // Use existing settings from database
        setSettings(existingSettings);
      } else {
        // No settings exist yet, create default settings for this business
        const newSettings = { ...defaultSettings, business_id: businessId };
        
        const { data: createdSettings, error: createError } = await supabase
          .from('hr_settings')
          .insert([newSettings])
          .select()
          .single();

        if (createError) {
          console.error('Error creating default HR settings:', createError);
          // Fall back to local defaults if database creation fails
          setSettings(newSettings);
        } else {
          setSettings(createdSettings);
        }
      }
    } catch (error) {
      console.error('Error in loadSettings:', error);
      // Fall back to local defaults with business ID
      setSettings({ ...defaultSettings, business_id: businessId });
    }
  };

  const handleInputChange = (field, value) => {
    setSettings(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleSave = async () => {
    try {
      setSaving(true);
      setMessage(null);

      // Prepare settings data for database (exclude metadata fields)
      const { id, created_at, updated_at, ...settingsToSave } = settings;

      // Update settings in database
      const { error: updateError } = await supabase
        .from('hr_settings')
        .update(settingsToSave)
        .eq('business_id', settings.business_id);

      if (updateError) {
        console.error('Error saving HR settings:', updateError);
        throw updateError;
      }

      setMessage({ type: 'success', text: 'HR settings saved successfully.' });
      
      // Clear message after 3 seconds
      setTimeout(() => setMessage(null), 3000);
    } catch (error) {
      console.error('Error saving HR settings:', error);
      setMessage({ 
        type: 'error', 
        text: 'Failed to save settings. Please try again.' 
      });
    } finally {
      setSaving(false);
    }
  };

  const handleBackToDashboard = () => {
    navigate('/dashboard/hr');
  };

  if (loading) {
    return (
      <div style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        minHeight: '100vh',
        backgroundColor: '#f9fafb',
        paddingTop: '60px',
        paddingLeft: '20px',
        paddingRight: '20px',
        paddingBottom: '20px'
      }}>
        <div style={{ textAlign: 'center' }}>
          <div style={{
            width: '32px',
            height: '32px',
            border: '3px solid #14B8A6',
            borderTop: '3px solid transparent',
            borderRadius: '50%',
            animation: 'spin 1s linear infinite',
            margin: '0 auto 8px auto'
          }}></div>
          <p style={{ 
            margin: 0, 
            color: '#6b7280',
            fontSize: '16px',
            fontWeight: '500'
          }}>
            Loading HR Settings...
          </p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        minHeight: '100vh',
        backgroundColor: '#f9fafb',
        paddingTop: '60px',
        paddingLeft: '20px',
        paddingRight: '20px',
        paddingBottom: '20px'
      }}>
        <div style={{ 
          textAlign: 'center',
          maxWidth: '500px'
        }}>
          <h2 style={{ 
            fontSize: '24px', 
            fontWeight: '600', 
            color: '#111827', 
            margin: '0 0 8px 0'
          }}>
            Access Denied
          </h2>
          <p style={{ 
            color: '#6b7280', 
            marginBottom: '20px',
            fontSize: '16px',
            lineHeight: '1.5',
            margin: '0 0 20px 0'
          }}>
            {error}
          </p>
          <button 
            onClick={handleBackToDashboard}
            style={{
              padding: '12px 24px',
              backgroundColor: '#14B8A6',
              color: 'white',
              border: 'none',
              borderRadius: '8px',
              fontSize: '16px',
              fontWeight: '600',
              cursor: 'pointer',
              transition: 'background-color 0.2s ease',
              outline: 'none'
            }}
            onMouseOver={(e) => e.target.style.backgroundColor = '#0F766E'}
            onMouseOut={(e) => e.target.style.backgroundColor = '#14B8A6'}
          >
            Return to HR Dashboard
          </button>
        </div>
      </div>
    );
  }

  if (!settings) {
    return (
      <div style={{ textAlign: 'center', padding: '32px' }}>
        <div style={{
          width: '32px',
          height: '32px',
          border: '3px solid #14B8A6',
          borderTop: '3px solid transparent',
          borderRadius: '50%',
          animation: 'spin 1s linear infinite',
          margin: '0 auto 8px auto'
        }}></div>
        <p style={{ 
          margin: 0, 
          color: '#6b7280',
          fontSize: '16px'
        }}>
          Loading settings...
        </p>
      </div>
    );
  }

  return (
    <div style={{
      minHeight: '100vh',
      backgroundColor: '#f9fafb',
      paddingTop: '60px',
      paddingLeft: '20px',
      paddingRight: '20px',
      paddingBottom: '20px'
    }}>
      {/* Add keyframes for spinner animation */}
      <style>
        {`
          @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
          }
        `}
      </style>

      <div style={{ maxWidth: '800px', margin: '0 auto' }}>
        {/* Header */}
        <div style={{ marginBottom: '30px' }}>
          <h1 style={{ 
            fontSize: '32px', 
            fontWeight: 'bold', 
            color: '#111827',
            margin: '0 0 8px 0'
          }}>
            HR Settings
          </h1>
          <p style={{ 
            color: '#6b7280', 
            fontSize: '16px',
            margin: 0
          }}>
            {business?.name}
          </p>
        </div>

        {/* Message */}
        {message && (
          <div style={{
            marginBottom: '30px',
            padding: '16px',
            borderRadius: '8px',
            borderLeft: message.type === 'success' ? '4px solid #10b981' : '4px solid #ef4444',
            backgroundColor: message.type === 'success' ? '#f0fdf4' : '#fef2f2',
            color: message.type === 'success' ? '#065f46' : '#991b1b'
          }}>
            {message.text}
          </div>
        )}

        <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
          {/* Employee Management Settings */}
          <div style={{
            backgroundColor: 'white',
            padding: '24px',
            borderRadius: '12px',
            border: '1px solid #e5e7eb',
            boxShadow: '0 1px 3px 0 rgba(0, 0, 0, 0.1)'
          }}>
            <h2 style={{
              fontSize: '20px',
              fontWeight: '600',
              color: '#111827',
              margin: '0 0 16px 0'
            }}>
              Employee Management
            </h2>
            
            <div style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))',
              gap: '24px'
            }}>
              <div>
                <label style={{
                  display: 'block',
                  fontSize: '14px',
                  fontWeight: '500',
                  color: '#374151',
                  marginBottom: '8px'
                }}>
                  Probation Period (days)
                </label>
                <input
                  type="number"
                  value={settings.probation_period_days}
                  onChange={(e) => handleInputChange('probation_period_days', parseInt(e.target.value))}
                  style={{
                    width: '100%',
                    padding: '8px 12px',
                    border: '1px solid #d1d5db',
                    borderRadius: '8px',
                    fontSize: '14px',
                    outline: 'none'
                  }}
                />
              </div>

              <div>
                <label style={{
                  display: 'block',
                  fontSize: '14px',
                  fontWeight: '500',
                  color: '#374151',
                  marginBottom: '8px'
                }}>
                  Employee Number Prefix
                </label>
                <input
                  type="text"
                  value={settings.employee_number_prefix}
                  onChange={(e) => handleInputChange('employee_number_prefix', e.target.value)}
                  style={{
                    width: '100%',
                    padding: '8px 12px',
                    border: '1px solid #d1d5db',
                    borderRadius: '8px',
                    fontSize: '14px',
                    outline: 'none'
                  }}
                />
              </div>

              <div style={{ gridColumn: '1 / -1' }}>
                <div style={{ marginBottom: '16px' }}>
                  <label style={{
                    display: 'block',
                    fontSize: '14px',
                    fontWeight: '500',
                    color: '#374151',
                    marginBottom: '8px'
                  }}>
                    Auto-generate employee numbers
                  </label>
                  <div style={{ display: 'flex', gap: '8px' }}>
                    <button
                      onClick={() => handleInputChange('auto_generate_employee_numbers', true)}
                      style={{
                        padding: '8px 16px',
                        fontSize: '14px',
                        fontWeight: '500',
                        border: '2px solid #14B8A6',
                        borderRadius: '6px',
                        cursor: 'pointer',
                        transition: 'all 0.2s ease',
                        backgroundColor: settings.auto_generate_employee_numbers ? '#14B8A6' : 'white',
                        color: settings.auto_generate_employee_numbers ? 'white' : '#14B8A6',
                        outline: 'none'
                      }}
                      onMouseOver={(e) => {
                        if (!settings.auto_generate_employee_numbers) {
                          e.target.style.backgroundColor = '#f0fdfa';
                        }
                      }}
                      onMouseOut={(e) => {
                        if (!settings.auto_generate_employee_numbers) {
                          e.target.style.backgroundColor = 'white';
                        }
                      }}
                    >
                      Yes
                    </button>
                    <button
                      onClick={() => handleInputChange('auto_generate_employee_numbers', false)}
                      style={{
                        padding: '8px 16px',
                        fontSize: '14px',
                        fontWeight: '500',
                        border: '2px solid #14B8A6',
                        borderRadius: '6px',
                        cursor: 'pointer',
                        transition: 'all 0.2s ease',
                        backgroundColor: !settings.auto_generate_employee_numbers ? '#14B8A6' : 'white',
                        color: !settings.auto_generate_employee_numbers ? 'white' : '#14B8A6',
                        outline: 'none'
                      }}
                      onMouseOver={(e) => {
                        if (settings.auto_generate_employee_numbers) {
                          e.target.style.backgroundColor = '#f0fdfa';
                        }
                      }}
                      onMouseOut={(e) => {
                        if (settings.auto_generate_employee_numbers) {
                          e.target.style.backgroundColor = 'white';
                        }
                      }}
                    >
                      No
                    </button>
                  </div>
                </div>

                <div style={{ marginBottom: '16px' }}>
                  <label style={{
                    display: 'block',
                    fontSize: '14px',
                    fontWeight: '500',
                    color: '#374151',
                    marginBottom: '8px'
                  }}>
                    Allow employees to edit their own profiles
                  </label>
                  <div style={{ display: 'flex', gap: '8px' }}>
                    <button
                      onClick={() => handleInputChange('allow_employee_self_edit', true)}
                      style={{
                        padding: '8px 16px',
                        fontSize: '14px',
                        fontWeight: '500',
                        border: '2px solid #14B8A6',
                        borderRadius: '6px',
                        cursor: 'pointer',
                        transition: 'all 0.2s ease',
                        backgroundColor: settings.allow_employee_self_edit ? '#14B8A6' : 'white',
                        color: settings.allow_employee_self_edit ? 'white' : '#14B8A6',
                        outline: 'none'
                      }}
                      onMouseOver={(e) => {
                        if (!settings.allow_employee_self_edit) {
                          e.target.style.backgroundColor = '#f0fdfa';
                        }
                      }}
                      onMouseOut={(e) => {
                        if (!settings.allow_employee_self_edit) {
                          e.target.style.backgroundColor = 'white';
                        }
                      }}
                    >
                      Yes
                    </button>
                    <button
                      onClick={() => handleInputChange('allow_employee_self_edit', false)}
                      style={{
                        padding: '8px 16px',
                        fontSize: '14px',
                        fontWeight: '500',
                        border: '2px solid #14B8A6',
                        borderRadius: '6px',
                        cursor: 'pointer',
                        transition: 'all 0.2s ease',
                        backgroundColor: !settings.allow_employee_self_edit ? '#14B8A6' : 'white',
                        color: !settings.allow_employee_self_edit ? 'white' : '#14B8A6',
                        outline: 'none'
                      }}
                      onMouseOver={(e) => {
                        if (settings.allow_employee_self_edit) {
                          e.target.style.backgroundColor = '#f0fdfa';
                        }
                      }}
                      onMouseOut={(e) => {
                        if (settings.allow_employee_self_edit) {
                          e.target.style.backgroundColor = 'white';
                        }
                      }}
                    >
                      No
                    </button>
                  </div>
                </div>

                <div>
                  <label style={{
                    display: 'block',
                    fontSize: '14px',
                    fontWeight: '500',
                    color: '#374151',
                    marginBottom: '8px'
                  }}>
                    Require manager approval for profile changes
                  </label>
                  <div style={{ display: 'flex', gap: '8px' }}>
                    <button
                      onClick={() => handleInputChange('require_manager_approval_profile_changes', true)}
                      style={{
                        padding: '8px 16px',
                        fontSize: '14px',
                        fontWeight: '500',
                        border: '2px solid #14B8A6',
                        borderRadius: '6px',
                        cursor: 'pointer',
                        transition: 'all 0.2s ease',
                        backgroundColor: settings.require_manager_approval_profile_changes ? '#14B8A6' : 'white',
                        color: settings.require_manager_approval_profile_changes ? 'white' : '#14B8A6',
                        outline: 'none'
                      }}
                      onMouseOver={(e) => {
                        if (!settings.require_manager_approval_profile_changes) {
                          e.target.style.backgroundColor = '#f0fdfa';
                        }
                      }}
                      onMouseOut={(e) => {
                        if (!settings.require_manager_approval_profile_changes) {
                          e.target.style.backgroundColor = 'white';
                        }
                      }}
                    >
                      Yes
                    </button>
                    <button
                      onClick={() => handleInputChange('require_manager_approval_profile_changes', false)}
                      style={{
                        padding: '8px 16px',
                        fontSize: '14px',
                        fontWeight: '500',
                        border: '2px solid #14B8A6',
                        borderRadius: '6px',
                        cursor: 'pointer',
                        transition: 'all 0.2s ease',
                        backgroundColor: !settings.require_manager_approval_profile_changes ? '#14B8A6' : 'white',
                        color: !settings.require_manager_approval_profile_changes ? 'white' : '#14B8A6',
                        outline: 'none'
                      }}
                      onMouseOver={(e) => {
                        if (settings.require_manager_approval_profile_changes) {
                          e.target.style.backgroundColor = '#f0fdfa';
                        }
                      }}
                      onMouseOut={(e) => {
                        if (settings.require_manager_approval_profile_changes) {
                          e.target.style.backgroundColor = 'white';
                        }
                      }}
                    >
                      No
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Leave and Benefits Settings */}
          <div style={{
            backgroundColor: 'white',
            padding: '24px',
            borderRadius: '12px',
            border: '1px solid #e5e7eb',
            boxShadow: '0 1px 3px 0 rgba(0, 0, 0, 0.1)'
          }}>
            <h2 style={{
              fontSize: '20px',
              fontWeight: '600',
              color: '#111827',
              margin: '0 0 16px 0'
            }}>
              Leave and Benefits
            </h2>
            
            <div style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))',
              gap: '24px'
            }}>
              <div>
                <label style={{
                  display: 'block',
                  fontSize: '14px',
                  fontWeight: '500',
                  color: '#374151',
                  marginBottom: '8px'
                }}>
                  Vacation Accrual Rate (% per pay period)
                </label>
                <input
                  type="number"
                  step="0.01"
                  value={settings.vacation_accrual_rate}
                  onChange={(e) => handleInputChange('vacation_accrual_rate', parseFloat(e.target.value))}
                  style={{
                    width: '100%',
                    padding: '8px 12px',
                    border: '1px solid #d1d5db',
                    borderRadius: '8px',
                    fontSize: '14px',
                    outline: 'none'
                  }}
                />
              </div>

              <div>
                <label style={{
                  display: 'block',
                  fontSize: '14px',
                  fontWeight: '500',
                  color: '#374151',
                  marginBottom: '8px'
                }}>
                  Sick Leave Accrual Rate (% per pay period)
                </label>
                <input
                  type="number"
                  step="0.01"
                  value={settings.sick_leave_accrual_rate}
                  onChange={(e) => handleInputChange('sick_leave_accrual_rate', parseFloat(e.target.value))}
                  style={{
                    width: '100%',
                    padding: '8px 12px',
                    border: '1px solid #d1d5db',
                    borderRadius: '8px',
                    fontSize: '14px',
                    outline: 'none'
                  }}
                />
              </div>
            </div>
          </div>

          {/* Approval Settings */}
          <div style={{
            backgroundColor: 'white',
            padding: '24px',
            borderRadius: '12px',
            border: '1px solid #e5e7eb',
            boxShadow: '0 1px 3px 0 rgba(0, 0, 0, 0.1)'
          }}>
            <h2 style={{
              fontSize: '20px',
              fontWeight: '600',
              color: '#111827',
              margin: '0 0 16px 0'
            }}>
              Approval Requirements
            </h2>
            
            <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
              <div>
                <label style={{
                  display: 'block',
                  fontSize: '14px',
                  fontWeight: '500',
                  color: '#374151',
                  marginBottom: '8px'
                }}>
                  Require manager approval for disciplinary writeups
                </label>
                <div style={{ display: 'flex', gap: '8px' }}>
                  <button
                    onClick={() => handleInputChange('require_manager_approval_writeups', true)}
                    style={{
                      padding: '8px 16px',
                      fontSize: '14px',
                      fontWeight: '500',
                      border: '2px solid #14B8A6',
                      borderRadius: '6px',
                      cursor: 'pointer',
                      transition: 'all 0.2s ease',
                      backgroundColor: settings.require_manager_approval_writeups ? '#14B8A6' : 'white',
                      color: settings.require_manager_approval_writeups ? 'white' : '#14B8A6',
                      outline: 'none'
                    }}
                    onMouseOver={(e) => {
                      if (!settings.require_manager_approval_writeups) {
                        e.target.style.backgroundColor = '#f0fdfa';
                      }
                    }}
                    onMouseOut={(e) => {
                      if (!settings.require_manager_approval_writeups) {
                        e.target.style.backgroundColor = 'white';
                      }
                    }}
                  >
                    Yes
                  </button>
                  <button
                    onClick={() => handleInputChange('require_manager_approval_writeups', false)}
                    style={{
                      padding: '8px 16px',
                      fontSize: '14px',
                      fontWeight: '500',
                      border: '2px solid #14B8A6',
                      borderRadius: '6px',
                      cursor: 'pointer',
                      transition: 'all 0.2s ease',
                      backgroundColor: !settings.require_manager_approval_writeups ? '#14B8A6' : 'white',
                      color: !settings.require_manager_approval_writeups ? 'white' : '#14B8A6',
                      outline: 'none'
                    }}
                    onMouseOver={(e) => {
                      if (settings.require_manager_approval_writeups) {
                        e.target.style.backgroundColor = '#f0fdfa';
                      }
                    }}
                    onMouseOut={(e) => {
                      if (settings.require_manager_approval_writeups) {
                        e.target.style.backgroundColor = 'white';
                      }
                    }}
                  >
                    No
                  </button>
                </div>
              </div>

              <div>
                <label style={{
                  display: 'block',
                  fontSize: '14px',
                  fontWeight: '500',
                  color: '#374151',
                  marginBottom: '8px'
                }}>
                  Require manager approval for policy changes
                </label>
                <div style={{ display: 'flex', gap: '8px' }}>
                  <button
                    onClick={() => handleInputChange('require_manager_approval_policy_changes', true)}
                    style={{
                      padding: '8px 16px',
                      fontSize: '14px',
                      fontWeight: '500',
                      border: '2px solid #14B8A6',
                      borderRadius: '6px',
                      cursor: 'pointer',
                      transition: 'all 0.2s ease',
                      backgroundColor: settings.require_manager_approval_policy_changes ? '#14B8A6' : 'white',
                      color: settings.require_manager_approval_policy_changes ? 'white' : '#14B8A6',
                      outline: 'none'
                    }}
                    onMouseOver={(e) => {
                      if (!settings.require_manager_approval_policy_changes) {
                        e.target.style.backgroundColor = '#f0fdfa';
                      }
                    }}
                    onMouseOut={(e) => {
                      if (!settings.require_manager_approval_policy_changes) {
                        e.target.style.backgroundColor = 'white';
                      }
                    }}
                  >
                    Yes
                  </button>
                  <button
                    onClick={() => handleInputChange('require_manager_approval_policy_changes', false)}
                    style={{
                      padding: '8px 16px',
                      fontSize: '14px',
                      fontWeight: '500',
                      border: '2px solid #14B8A6',
                      borderRadius: '6px',
                      cursor: 'pointer',
                      transition: 'all 0.2s ease',
                      backgroundColor: !settings.require_manager_approval_policy_changes ? '#14B8A6' : 'white',
                      color: !settings.require_manager_approval_policy_changes ? 'white' : '#14B8A6',
                      outline: 'none'
                    }}
                    onMouseOver={(e) => {
                      if (settings.require_manager_approval_policy_changes) {
                        e.target.style.backgroundColor = '#f0fdfa';
                      }
                    }}
                    onMouseOut={(e) => {
                      if (settings.require_manager_approval_policy_changes) {
                        e.target.style.backgroundColor = 'white';
                      }
                    }}
                  >
                    No
                  </button>
                </div>
              </div>

              <div>
                <label style={{
                  display: 'block',
                  fontSize: '14px',
                  fontWeight: '500',
                  color: '#374151',
                  marginBottom: '8px'
                }}>
                  Require onboarding completion before full access
                </label>
                <div style={{ display: 'flex', gap: '8px' }}>
                  <button
                    onClick={() => handleInputChange('onboarding_completion_required', true)}
                    style={{
                      padding: '8px 16px',
                      fontSize: '14px',
                      fontWeight: '500',
                      border: '2px solid #14B8A6',
                      borderRadius: '6px',
                      cursor: 'pointer',
                      transition: 'all 0.2s ease',
                      backgroundColor: settings.onboarding_completion_required ? '#14B8A6' : 'white',
                      color: settings.onboarding_completion_required ? 'white' : '#14B8A6',
                      outline: 'none'
                    }}
                    onMouseOver={(e) => {
                      if (!settings.onboarding_completion_required) {
                        e.target.style.backgroundColor = '#f0fdfa';
                      }
                    }}
                    onMouseOut={(e) => {
                      if (!settings.onboarding_completion_required) {
                        e.target.style.backgroundColor = 'white';
                      }
                    }}
                  >
                    Yes
                  </button>
                  <button
                    onClick={() => handleInputChange('onboarding_completion_required', false)}
                    style={{
                      padding: '8px 16px',
                      fontSize: '14px',
                      fontWeight: '500',
                      border: '2px solid #14B8A6',
                      borderRadius: '6px',
                      cursor: 'pointer',
                      transition: 'all 0.2s ease',
                      backgroundColor: !settings.onboarding_completion_required ? '#14B8A6' : 'white',
                      color: !settings.onboarding_completion_required ? 'white' : '#14B8A6',
                      outline: 'none'
                    }}
                    onMouseOver={(e) => {
                      if (settings.onboarding_completion_required) {
                        e.target.style.backgroundColor = '#f0fdfa';
                      }
                    }}
                    onMouseOut={(e) => {
                      if (settings.onboarding_completion_required) {
                        e.target.style.backgroundColor = 'white';
                      }
                    }}
                  >
                    No
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Notification Settings */}
          <div style={{
            backgroundColor: 'white',
            padding: '24px',
            borderRadius: '12px',
            border: '1px solid #e5e7eb',
            boxShadow: '0 1px 3px 0 rgba(0, 0, 0, 0.1)'
          }}>
            <h2 style={{
              fontSize: '20px',
              fontWeight: '600',
              color: '#111827',
              margin: '0 0 16px 0'
            }}>
              Notifications
            </h2>
            
            <div style={{
              display: 'grid',
              gridTemplateColumns: '1fr',
              gap: '24px'
            }}>
              <div>
                <label style={{
                  display: 'block',
                  fontSize: '14px',
                  fontWeight: '500',
                  color: '#374151',
                  marginBottom: '8px'
                }}>
                  Notification Email Address
                </label>
                <input
                  type="email"
                  value={settings.notification_email}
                  onChange={(e) => handleInputChange('notification_email', e.target.value)}
                  placeholder="hr@company.com"
                  style={{
                    width: '100%',
                    padding: '8px 12px',
                    border: '1px solid #d1d5db',
                    borderRadius: '8px',
                    fontSize: '14px',
                    outline: 'none'
                  }}
                />
                <p style={{
                  fontSize: '12px',
                  color: '#6b7280',
                  margin: '4px 0 0 0'
                }}>
                  Email address for HR notifications and alerts
                </p>
              </div>

              <div style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))',
                gap: '24px'
              }}>
                <div>
                  <label style={{
                    display: 'block',
                    fontSize: '14px',
                    fontWeight: '500',
                    color: '#374151',
                    marginBottom: '8px'
                  }}>
                    Contract Expiry Warning (days)
                  </label>
                  <input
                    type="number"
                    value={settings.contract_expiry_warning_days}
                    onChange={(e) => handleInputChange('contract_expiry_warning_days', parseInt(e.target.value))}
                    style={{
                      width: '100%',
                      padding: '8px 12px',
                      border: '1px solid #d1d5db',
                      borderRadius: '8px',
                      fontSize: '14px',
                      outline: 'none'
                    }}
                  />
                </div>

                <div>
                  <label style={{
                    display: 'block',
                    fontSize: '14px',
                    fontWeight: '500',
                    color: '#374151',
                    marginBottom: '8px'
                  }}>
                    Policy Acknowledgment Deadline (days)
                  </label>
                  <input
                    type="number"
                    value={settings.policy_acknowledgment_deadline_days}
                    onChange={(e) => handleInputChange('policy_acknowledgment_deadline_days', parseInt(e.target.value))}
                    style={{
                      width: '100%',
                      padding: '8px 12px',
                      border: '1px solid #d1d5db',
                      borderRadius: '8px',
                      fontSize: '14px',
                      outline: 'none'
                    }}
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Document Management */}
          <div style={{
            backgroundColor: 'white',
            padding: '24px',
            borderRadius: '12px',
            border: '1px solid #e5e7eb',
            boxShadow: '0 1px 3px 0 rgba(0, 0, 0, 0.1)'
          }}>
            <h2 style={{
              fontSize: '20px',
              fontWeight: '600',
              color: '#111827',
              margin: '0 0 16px 0'
            }}>
              Document Management
            </h2>
            
            <div>
              <label style={{
                display: 'block',
                fontSize: '14px',
                fontWeight: '500',
                color: '#374151',
                marginBottom: '8px'
              }}>
                Document Retention Period (years)
              </label>
              <input
                type="number"
                value={settings.document_retention_years}
                onChange={(e) => handleInputChange('document_retention_years', parseInt(e.target.value))}
                style={{
                  width: '200px',
                  padding: '8px 12px',
                  border: '1px solid #d1d5db',
                  borderRadius: '8px',
                  fontSize: '14px',
                  outline: 'none'
                }}
              />
              <p style={{
                fontSize: '12px',
                color: '#6b7280',
                margin: '4px 0 0 0'
              }}>
                How long to retain employee documents after termination
              </p>
            </div>
          </div>

          {/* Save Button */}
          <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
            <button
              onClick={handleSave}
              disabled={saving}
              style={{
                padding: '12px 24px',
                backgroundColor: saving ? '#9ca3af' : '#14B8A6',
                color: 'white',
                border: 'none',
                borderRadius: '8px',
                fontSize: '16px',
                fontWeight: '600',
                cursor: saving ? 'not-allowed' : 'pointer',
                transition: 'background-color 0.2s ease',
                outline: 'none'
              }}
              onMouseOver={(e) => {
                if (!saving) {
                  e.target.style.backgroundColor = '#0F766E';
                }
              }}
              onMouseOut={(e) => {
                if (!saving) {
                  e.target.style.backgroundColor = '#14B8A6';
                }
              }}
            >
              {saving ? 'Saving...' : 'Save Settings'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HRSettings;