import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { supabase } from '../../supabaseClient';

const AttendanceTrackingScreen = () => {
  const { sessionId } = useParams();
  const navigate = useNavigate();

  // Authentication state
  const [authUser, setAuthUser] = useState(null);
  const [selectedBusinessId, setSelectedBusinessId] = useState(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [authError, setAuthError] = useState(null);

  // Component state
  const [sessionDetails, setSessionDetails] = useState(null);
  const [attendees, setAttendees] = useState([]);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [filter, setFilter] = useState('all'); // all, registered, confirmed, attended, no_show
  const [bulkAction, setBulkAction] = useState('');
  const [selectedAttendees, setSelectedAttendees] = useState([]);

  // Authentication setup
  useEffect(() => {
    const initializeAuth = async () => {
      try {
        console.log('AttendanceTracking: Initializing authentication...');
        
        const { data: { session }, error } = await supabase.auth.getSession();

        if (error || !session?.user) {
          console.error('AttendanceTracking: No valid session');
          navigate('/login');
          return;
        }

        setAuthUser(session.user);

        const currentBusinessId = localStorage.getItem('currentBusinessId');
        if (!currentBusinessId) {
          setAuthError('No business selected');
          return;
        }

        setSelectedBusinessId(currentBusinessId);

        // Verify user has manager/owner access
        const { data: userRole, error: roleError } = await supabase
          .from('user_roles')
          .select('*')
          .eq('user_id', session.user.id)
          .eq('business_id', currentBusinessId)
          .eq('active', true)
          .single();

        if (roleError || !userRole) {
          console.error('AttendanceTracking: User not authorized for this business:', roleError);
          setAuthError('Not authorized for this business');
          return;
        }

        if (!['owner', 'manager'].includes(userRole.role)) {
          setAuthError('You do not have permission to track attendance');
          return;
        }

        console.log('AttendanceTracking: User role verified:', userRole.role);
        setAuthLoading(false);

      } catch (err) {
        console.error('AttendanceTracking: Authentication error:', err);
        setAuthError(err.message);
        setAuthLoading(false);
      }
    };

    initializeAuth();
  }, [navigate]);

  // Load data when component mounts
  useEffect(() => {
    if (!authUser || !selectedBusinessId || !sessionId) return;
    loadSessionData();
    loadAttendees();
  }, [authUser, selectedBusinessId, sessionId]);

  const loadSessionData = async () => {
    try {
      console.log('Loading session data for:', sessionId);
      
      const { data, error } = await supabase
        .from('orientation_sessions')
        .select('*')
        .eq('id', sessionId)
        .eq('business_id', selectedBusinessId)
        .single();

      if (error) {
        console.error('Error loading session:', error);
        throw error;
      }
      
      console.log('Session data loaded:', data);
      setSessionDetails(data);
    } catch (error) {
      console.error('Error loading session details:', error);
      setAuthError('Session not found or access denied');
    }
  };

  const loadAttendees = async () => {
    setLoading(true);
    try {
      console.log('Loading attendees for session:', sessionId);
      
      const { data, error } = await supabase.rpc('get_orientation_attendees', {
        p_session_id: sessionId,
        p_business_id: selectedBusinessId
      });

      if (error) {
        console.error('Error loading attendees:', error);
        // Don't throw error, just set empty array
        setAttendees([]);
      } else {
        console.log('Attendees loaded:', data?.length);
        setAttendees(data || []);
      }
    } catch (error) {
      console.error('Error loading attendees:', error);
      setAttendees([]);
    } finally {
      setLoading(false);
    }
  };

  const markAttendance = async (attendeeId, status, notes = null) => {
    setSaving(true);
    try {
      console.log('Marking attendance:', attendeeId, status);
      
      const { data, error } = await supabase.rpc('mark_orientation_attendance', {
        p_attendee_id: attendeeId,
        p_attendance_status: status,
        p_marked_by: authUser.id,
        p_notes: notes
      });

      if (error) {
        console.error('Error marking attendance:', error);
        throw error;
      }
      
      console.log('Attendance marked successfully');
      
      // Reload attendees to show updated status
      await loadAttendees();
      
    } catch (error) {
      console.error('Error marking attendance:', error);
      alert('Failed to update attendance. Please try again.');
    } finally {
      setSaving(false);
    }
  };

  const handleBulkAction = async () => {
    if (!bulkAction || selectedAttendees.length === 0) return;

    setSaving(true);
    try {
      console.log(`Applying bulk ${bulkAction} to ${selectedAttendees.length} attendees`);
      
      await Promise.all(
        selectedAttendees.map(attendeeId => 
          supabase.rpc('mark_orientation_attendance', {
            p_attendee_id: attendeeId,
            p_attendance_status: bulkAction,
            p_marked_by: authUser.id,
            p_notes: `Bulk action: ${bulkAction}`
          })
        )
      );

      // Reload attendees and clear selections
      await loadAttendees();
      setSelectedAttendees([]);
      setBulkAction('');
      
      console.log(`Bulk ${bulkAction} applied successfully`);
    } catch (error) {
      console.error('Error applying bulk action:', error);
      alert('Failed to apply bulk action. Please try again.');
    } finally {
      setSaving(false);
    }
  };

  const toggleAttendeeSelection = (attendeeId) => {
    setSelectedAttendees(prev => 
      prev.includes(attendeeId)
        ? prev.filter(id => id !== attendeeId)
        : [...prev, attendeeId]
    );
  };

  const selectAllVisible = () => {
    const visibleAttendeeIds = filteredAttendees.map(a => a.attendee_id);
    setSelectedAttendees(visibleAttendeeIds);
  };

  const clearSelection = () => {
    setSelectedAttendees([]);
  };

  const handleBackToCalendar = () => {
    navigate('/dashboard/hr/orientation');
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'registered': return '#3b82f6';
      case 'confirmed': return '#10b981';
      case 'attended': return '#059669';
      case 'no_show': return '#dc2626';
      case 'cancelled': return '#6b7280';
      default: return '#6b7280';
    }
  };

  const getStatusBadge = (status) => {
    const color = getStatusColor(status);
    return (
      <span style={{
        backgroundColor: color,
        color: 'white',
        padding: '4px 8px',
        borderRadius: '4px',
        fontSize: '12px',
        fontWeight: 'bold',
        textTransform: 'capitalize'
      }}>
        {status.replace('_', ' ')}
      </span>
    );
  };

  const formatDate = (dateStr) => {
    if (!dateStr) return '';
    return new Date(dateStr).toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const formatTime = (timeStr) => {
    if (!timeStr) return '';
    const [hours, minutes] = timeStr.split(':');
    const hour = parseInt(hours);
    const ampm = hour >= 12 ? 'PM' : 'AM';
    const displayHour = hour % 12 || 12;
    return `${displayHour}:${minutes} ${ampm}`;
  };

  const filteredAttendees = attendees.filter(attendee => {
    if (filter === 'all') return true;
    return attendee.registration_status === filter;
  });

  // Loading state
  if (authLoading) {
    return (
      <div style={styles.container}>
        <div style={styles.loadingContainer}>
          <h3>Loading Attendance Tracker...</h3>
          <p>Authenticating user and loading data...</p>
        </div>
      </div>
    );
  }

  // Error state
  if (authError) {
    return (
      <div style={styles.container}>
        <div style={styles.errorContainer}>
          <h3>Access Error</h3>
          <p>{authError}</p>
          <button style={styles.backButton} onClick={handleBackToCalendar}>
            Back to Orientation Calendar
          </button>
        </div>
      </div>
    );
  }

  if (!sessionDetails) {
    return (
      <div style={styles.container}>
        <div style={styles.loadingContainer}>
          <h3>Loading Session...</h3>
          <p>Loading session details...</p>
        </div>
      </div>
    );
  }

  return (
    <div style={styles.container}>
      <div style={styles.header}>
        <div>
          <h1 style={styles.title}>Attendance Tracking</h1>
          <div style={styles.sessionInfo}>
            <span style={styles.sessionTitle}>{sessionDetails.title}</span>
            <span style={styles.sessionDate}>
              {formatDate(sessionDetails.session_date)} • {formatTime(sessionDetails.start_time)} - {formatTime(sessionDetails.end_time)}
            </span>
            {sessionDetails.location && (
              <span style={styles.sessionLocation}>📍 {sessionDetails.location}</span>
            )}
          </div>
        </div>
        <button style={styles.backButton} onClick={handleBackToCalendar}>
          ← Back to Calendar
        </button>
      </div>

      {/* Summary Stats */}
      <div style={styles.summaryCards}>
        <div style={styles.summaryCard}>
          <div style={styles.cardTitle}>Total Registered</div>
          <div style={styles.cardValue}>{attendees.length}</div>
        </div>
        <div style={styles.summaryCard}>
          <div style={styles.cardTitle}>Attended</div>
          <div style={styles.cardValue}>
            {attendees.filter(a => a.registration_status === 'attended').length}
          </div>
        </div>
        <div style={styles.summaryCard}>
          <div style={styles.cardTitle}>No Show</div>
          <div style={styles.cardValue}>
            {attendees.filter(a => a.registration_status === 'no_show').length}
          </div>
        </div>
        <div style={styles.summaryCard}>
          <div style={styles.cardTitle}>Pending</div>
          <div style={styles.cardValue}>
            {attendees.filter(a => ['registered', 'confirmed'].includes(a.registration_status)).length}
          </div>
        </div>
      </div>

      {/* Controls */}
      <div style={styles.controls}>
        <div style={styles.filterSection}>
          <label style={styles.filterLabel}>Filter by status:</label>
          <select 
            style={styles.filterSelect}
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
          >
            <option value="all">All ({attendees.length})</option>
            <option value="registered">Registered ({attendees.filter(a => a.registration_status === 'registered').length})</option>
            <option value="confirmed">Confirmed ({attendees.filter(a => a.registration_status === 'confirmed').length})</option>
            <option value="attended">Attended ({attendees.filter(a => a.registration_status === 'attended').length})</option>
            <option value="no_show">No Show ({attendees.filter(a => a.registration_status === 'no_show').length})</option>
            <option value="cancelled">Cancelled ({attendees.filter(a => a.registration_status === 'cancelled').length})</option>
          </select>
        </div>

        <div style={styles.bulkActions}>
          <div style={styles.selectionControls}>
            <button 
              style={styles.selectButton}
              onClick={selectAllVisible}
              disabled={filteredAttendees.length === 0}
            >
              Select All Visible
            </button>
            <button 
              style={styles.selectButton}
              onClick={clearSelection}
              disabled={selectedAttendees.length === 0}
            >
              Clear Selection ({selectedAttendees.length})
            </button>
          </div>

          {selectedAttendees.length > 0 && (
            <div style={styles.bulkActionSection}>
              <select 
                style={styles.bulkSelect}
                value={bulkAction}
                onChange={(e) => setBulkAction(e.target.value)}
              >
                <option value="">Bulk Action...</option>
                <option value="confirmed">Mark as Confirmed</option>
                <option value="attended">Mark as Attended</option>
                <option value="no_show">Mark as No Show</option>
                <option value="cancelled">Mark as Cancelled</option>
              </select>
              <button 
                style={styles.applyButton}
                onClick={handleBulkAction}
                disabled={!bulkAction || saving}
              >
                {saving ? 'Applying...' : `Apply to ${selectedAttendees.length}`}
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Attendees List */}
      <div style={styles.attendeesContainer}>
        {loading ? (
          <div style={styles.loadingMessage}>Loading attendees...</div>
        ) : filteredAttendees.length === 0 ? (
          <div style={styles.noAttendees}>
            {filter === 'all' ? 'No attendees registered for this session' : `No attendees with status: ${filter}`}
          </div>
        ) : (
          <div style={styles.attendeesList}>
            {filteredAttendees.map((attendee) => (
              <div key={attendee.attendee_id} style={styles.attendeeCard}>
                <div 
                  style={{
                    ...styles.attendeeHeader,
                    backgroundColor: selectedAttendees.includes(attendee.attendee_id) ? '#e0f2fe' : 'transparent',
                    cursor: 'pointer',
                    padding: '8px',
                    borderRadius: '4px',
                    border: selectedAttendees.includes(attendee.attendee_id) ? '2px solid #0284c7' : '2px solid transparent'
                  }}
                  onClick={() => toggleAttendeeSelection(attendee.attendee_id)}
                  title="Click to select/deselect for bulk actions"
                >
                  <div style={styles.attendeeSelectSection}>
                    <div style={{
                      width: '20px',
                      height: '20px',
                      borderRadius: '4px',
                      border: '2px solid #008080',
                      backgroundColor: selectedAttendees.includes(attendee.attendee_id) ? '#008080' : 'white',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      color: 'white',
                      fontSize: '14px',
                      fontWeight: 'bold'
                    }}>
                      {selectedAttendees.includes(attendee.attendee_id) ? '✓' : ''}
                    </div>
                  </div>
                  
                  <div style={styles.attendeeInfo}>
                    <div style={styles.attendeeName}>
                      {attendee.employee_name}
                    </div>
                    <div style={styles.attendeeDetails}>
                      {attendee.department && <span>{attendee.department} • </span>}
                      {attendee.hire_date && (
                        <span>Hired: {new Date(attendee.hire_date).toLocaleDateString()}</span>
                      )}
                    </div>
                  </div>

                  <div style={styles.statusSection}>
                    {getStatusBadge(attendee.registration_status)}
                  </div>
                </div>

                <div style={styles.attendeeActions}>
                  <button
                    style={{...styles.actionButton, backgroundColor: '#10b981'}}
                    onClick={() => markAttendance(attendee.attendee_id, 'confirmed')}
                    disabled={saving || attendee.registration_status === 'confirmed'}
                  >
                    Confirm
                  </button>
                  <button
                    style={{...styles.actionButton, backgroundColor: '#059669'}}
                    onClick={() => markAttendance(attendee.attendee_id, 'attended')}
                    disabled={saving || attendee.registration_status === 'attended'}
                  >
                    Mark Present
                  </button>
                  <button
                    style={{...styles.actionButton, backgroundColor: '#dc2626'}}
                    onClick={() => markAttendance(attendee.attendee_id, 'no_show')}
                    disabled={saving || attendee.registration_status === 'no_show'}
                  >
                    No Show
                  </button>
                  <button
                    style={{...styles.actionButton, backgroundColor: '#6b7280'}}
                    onClick={() => markAttendance(attendee.attendee_id, 'cancelled')}
                    disabled={saving || attendee.registration_status === 'cancelled'}
                  >
                    Cancel
                  </button>
                </div>

                {attendee.notes && (
                  <div style={styles.attendeeNotes}>
                    <strong>Notes:</strong> {attendee.notes}
                  </div>
                )}

                {attendee.attendance_marked_at && (
                  <div style={styles.timestampInfo}>
                    Status updated: {new Date(attendee.attendance_marked_at).toLocaleString()}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

const styles = {
  container: {
    padding: '60px 20px 20px 20px',
    maxWidth: '1200px',
    margin: '0 auto',
    fontFamily: 'system-ui, -apple-system, sans-serif'
  },
  loadingContainer: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    height: '300px',
    textAlign: 'center'
  },
  errorContainer: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    height: '300px',
    textAlign: 'center',
    color: '#dc2626'
  },
  header: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: '30px'
  },
  title: {
    fontSize: '28px',
    fontWeight: 'bold',
    color: '#1f2937',
    margin: '0 0 8px 0'
  },
  sessionInfo: {
    display: 'flex',
    flexDirection: 'column',
    gap: '4px'
  },
  sessionTitle: {
    fontSize: '18px',
    fontWeight: '600',
    color: '#374151'
  },
  sessionDate: {
    fontSize: '14px',
    color: '#6b7280'
  },
  sessionLocation: {
    fontSize: '14px',
    color: '#6b7280'
  },
  backButton: {
    backgroundColor: 'white',
    border: '2px solid #008080',
    borderRadius: '6px',
    padding: '8px 16px',
    color: '#008080',
    cursor: 'pointer',
    fontWeight: 'bold'
  },
  summaryCards: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fit, minmax(150px, 1fr))',
    gap: '15px',
    marginBottom: '30px'
  },
  summaryCard: {
    backgroundColor: 'white',
    padding: '20px',
    borderRadius: '8px',
    border: '1px solid #e5e7eb',
    textAlign: 'center'
  },
  cardTitle: {
    fontSize: '14px',
    color: '#6b7280',
    marginBottom: '8px'
  },
  cardValue: {
    fontSize: '24px',
    fontWeight: 'bold',
    color: '#1f2937'
  },
  controls: {
    backgroundColor: 'white',
    padding: '20px',
    borderRadius: '8px',
    border: '1px solid #e5e7eb',
    marginBottom: '20px'
  },
  filterSection: {
    display: 'flex',
    alignItems: 'center',
    gap: '10px',
    marginBottom: '15px'
  },
  filterLabel: {
    fontSize: '14px',
    fontWeight: 'bold',
    color: '#374151'
  },
  filterSelect: {
    padding: '8px 12px',
    border: '2px solid #008080',
    borderRadius: '6px',
    fontSize: '14px'
  },
  bulkActions: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    flexWrap: 'wrap',
    gap: '15px'
  },
  selectionControls: {
    display: 'flex',
    gap: '10px'
  },
  selectButton: {
    backgroundColor: 'white',
    border: '1px solid #d1d5db',
    borderRadius: '6px',
    padding: '6px 12px',
    fontSize: '14px',
    cursor: 'pointer'
  },
  bulkActionSection: {
    display: 'flex',
    gap: '10px',
    alignItems: 'center'
  },
  bulkSelect: {
    padding: '8px 12px',
    border: '2px solid #008080',
    borderRadius: '6px',
    fontSize: '14px'
  },
  applyButton: {
    backgroundColor: '#008080',
    color: 'white',
    border: 'none',
    borderRadius: '6px',
    padding: '8px 16px',
    fontSize: '14px',
    fontWeight: 'bold',
    cursor: 'pointer'
  },
  attendeesContainer: {
    backgroundColor: 'white',
    borderRadius: '8px',
    border: '1px solid #e5e7eb'
  },
  loadingMessage: {
    padding: '40px',
    textAlign: 'center',
    color: '#6b7280'
  },
  noAttendees: {
    padding: '40px',
    textAlign: 'center',
    color: '#6b7280',
    fontStyle: 'italic'
  },
  attendeesList: {
    padding: '20px'
  },
  attendeeCard: {
    border: '1px solid #e5e7eb',
    borderRadius: '8px',
    padding: '16px',
    marginBottom: '12px',
    backgroundColor: '#f9fafb'
  },
  attendeeHeader: {
    display: 'flex',
    alignItems: 'center',
    marginBottom: '12px'
  },
  attendeeSelectSection: {
    marginRight: '12px'
  },
  attendeeCheckbox: {
    width: '18px',
    height: '18px',
    cursor: 'pointer'
  },
  attendeeInfo: {
    flex: 1
  },
  attendeeName: {
    fontSize: '16px',
    fontWeight: 'bold',
    color: '#1f2937'
  },
  attendeeDetails: {
    fontSize: '14px',
    color: '#6b7280',
    marginTop: '2px'
  },
  statusSection: {
    marginLeft: '12px'
  },
  attendeeActions: {
    display: 'flex',
    gap: '8px',
    flexWrap: 'wrap'
  },
  actionButton: {
    color: 'white',
    border: 'none',
    borderRadius: '4px',
    padding: '6px 12px',
    fontSize: '12px',
    fontWeight: 'bold',
    cursor: 'pointer',
    minWidth: '80px'
  },
  attendeeNotes: {
    fontSize: '14px',
    color: '#374151',
    marginTop: '10px',
    padding: '8px',
    backgroundColor: '#f3f4f6',
    borderRadius: '4px'
  },
  timestampInfo: {
    fontSize: '12px',
    color: '#9ca3af',
    marginTop: '8px',
    fontStyle: 'italic'
  }
};

export default AttendanceTrackingScreen;