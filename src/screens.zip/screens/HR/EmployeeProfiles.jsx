import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Users, Search, Filter, Plus, Edit, Eye, Trash2, AlertCircle, X, Clock } from 'lucide-react';
import { supabase } from '../../supabaseClient';
import AddEmployeeModal from '../../components/HR/AddEmployeeModal';
import EmployeeEditModal from '../../components/HR/EmployeeEditModal';
import EmployeeAuditHistory from '../../components/HR/EmployeeAuditHistory';

const EmployeeProfiles = () => {
  const navigate = useNavigate();
  
  // Authentication state (inline like TabScreen)
  const [authUser, setAuthUser] = useState(null);
  const [selectedBusinessId, setSelectedBusinessId] = useState(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [authError, setAuthError] = useState(null);
  const [userRole, setUserRole] = useState(null);

  // Component state
  const [employees, setEmployees] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [departmentFilter, setDepartmentFilter] = useState('all');
  const [showAddModal, setShowAddModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showAuditHistory, setShowAuditHistory] = useState(false);
  const [selectedEmployee, setSelectedEmployee] = useState(null);
  const [error, setError] = useState(null);

  // Available departments for filtering
  const [departments, setDepartments] = useState([]);

  // User context for child components
  const userContext = {
    user: authUser,
    businessId: selectedBusinessId,
    role: userRole
  };

  // Authentication and business context setup (copied from TabScreen pattern)
  useEffect(() => {
    const initializeAuth = async () => {
      try {
        console.log('EmployeeProfiles: Initializing authentication...');
        
        const { data: { session }, error } = await supabase.auth.getSession();
        console.log('EmployeeProfiles: Session check result:', { session: !!session, error });

        if (error || !session?.user) {
          console.error('EmployeeProfiles: No valid session, redirecting to login');
          navigate('/login');
          return;
        }

        setAuthUser(session.user);
        console.log('EmployeeProfiles: Authenticated as:', session.user.email);

        const currentBusinessId = localStorage.getItem('currentBusinessId');
        console.log('EmployeeProfiles: Business ID from localStorage:', currentBusinessId);

        if (!currentBusinessId) {
          setAuthError('No business selected');
          return;
        }

        setSelectedBusinessId(currentBusinessId);

        // Verify user has access to this business and get role
        const { data: userRole, error: roleError } = await supabase
          .from('user_roles')
          .select('role')
          .eq('user_id', session.user.id)
          .eq('business_id', currentBusinessId)
          .eq('active', true)
          .single();

        if (roleError || !userRole) {
          console.error('EmployeeProfiles: User not authorized for this business:', roleError);
          setAuthError('Not authorized for this business');
          return;
        }

        setUserRole(userRole.role);
        console.log('EmployeeProfiles: User role verified:', userRole.role);
        setAuthLoading(false);

      } catch (err) {
        console.error('EmployeeProfiles: Authentication error:', err);
        setAuthError(err.message);
        setAuthLoading(false);
      }
    };

    initializeAuth();
  }, [navigate]);

  // Load employees
  useEffect(() => {
    if (selectedBusinessId && !authLoading) {
      loadEmployees();
    }
  }, [selectedBusinessId, authLoading]);

  const loadEmployees = async () => {
    try {
      setLoading(true);
      
      // Load from users table using business_users relationship
      const { data, error } = await supabase
        .from('users')
        .select(`
          id, 
          first_name,
          last_name,
          full_name, 
          email,
          phone,
          position,
          department,
          employment_status,
          hire_date,
          wage,
          employee_number,
          created_at,
          business_users!inner(business_id)
        `)
        .eq('business_users.business_id', selectedBusinessId)
        .order('first_name');

      if (error) throw error;

      // Transform the data to match expected format
      const transformedEmployees = (data || []).map(user => ({
        id: user.id,
        first_name: user.first_name || user.full_name?.split(' ')[0] || 'Unknown',
        last_name: user.last_name || user.full_name?.split(' ').slice(1).join(' ') || '',
        full_name: user.full_name || `${user.first_name || ''} ${user.last_name || ''}`.trim(),
        email: user.email,
        phone: user.phone,
        position: user.position,
        department: user.department,
        employment_status: user.employment_status || 'active',
        hire_date: user.hire_date,
        wage: user.wage,
        employee_number: user.employee_number,
        created_at: user.created_at,
        tenure: user.hire_date ? calculateTenure(user.hire_date) : null
      }));
      
      setEmployees(transformedEmployees);

      // Extract unique departments for filtering
      const uniqueDepartments = [...new Set(
        transformedEmployees
          .map(emp => emp.department)
          .filter(dept => dept && dept.trim())
      )].sort();
      setDepartments(uniqueDepartments);

      console.log('Loaded employees:', transformedEmployees);
    } catch (error) {
      console.error('Error loading employees:', error);
      setError('Failed to load employees: ' + error.message);
      setEmployees([]);
    } finally {
      setLoading(false);
    }
  };

  const calculateTenure = (hireDate) => {
    if (!hireDate) return null;
    
    const hire = new Date(hireDate);
    const now = new Date();
    const diffTime = Math.abs(now - hire);
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays < 30) {
      return `${diffDays} days`;
    } else if (diffDays < 365) {
      const months = Math.floor(diffDays / 30);
      return `${months} month${months !== 1 ? 's' : ''}`;
    } else {
      const years = Math.floor(diffDays / 365);
      const remainingMonths = Math.floor((diffDays % 365) / 30);
      return `${years} year${years !== 1 ? 's' : ''}${remainingMonths > 0 ? `, ${remainingMonths} month${remainingMonths !== 1 ? 's' : ''}` : ''}`;
    }
  };

  const handleEmployeeCreated = (newEmployee) => {
    setShowAddModal(false);
    loadEmployees(); // Refresh the employee list
    console.log('New employee created:', newEmployee);
  };

  const handleEditEmployee = (employee) => {
    setSelectedEmployee(employee);
    setShowEditModal(true);
    console.log('Edit employee:', employee.id);
  };

  const handleEmployeeSaved = (updatedEmployee) => {
    setShowEditModal(false);
    setSelectedEmployee(null);
    loadEmployees(); // Refresh the employee list
    console.log('Employee updated:', updatedEmployee);
  };

  const handleViewAuditHistory = (employee) => {
    setSelectedEmployee(employee);
    setShowAuditHistory(true);
    console.log('View audit history for employee:', employee.id);
  };

  const handleViewEmployee = (employee) => {
    console.log('View employee details:', employee.id);
    // TODO: Implement view modal/page or just open edit modal in read-only mode
    handleEditEmployee(employee);
  };

  const handleDeleteEmployee = (employee) => {
    if (confirm(`Are you sure you want to delete ${employee.full_name}? This action cannot be undone.`)) {
      console.log('Delete employee:', employee.id);
      // TODO: Implement delete functionality
    }
  };

  const canManageEmployees = () => {
    return userRole && ['owner', 'manager', 'admin'].includes(userRole);
  };

  const canViewAuditHistory = () => {
    return userRole && ['owner', 'manager', 'admin'].includes(userRole);
  };

  // Filter employees
  const filteredEmployees = employees.filter(employee => {
    const matchesSearch = !searchTerm || 
      employee.full_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      employee.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      employee.position?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      employee.employee_number?.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = statusFilter === 'all' || employee.employment_status === statusFilter;
    const matchesDepartment = departmentFilter === 'all' || employee.department === departmentFilter;
    
    return matchesSearch && matchesStatus && matchesDepartment;
  });

  const getStatusColor = (status) => {
    switch (status) {
      case 'active': return '#059669';
      case 'probation': return '#f59e0b';
      case 'suspended': return '#dc2626';
      case 'terminated': return '#6b7280';
      case 'on_leave': return '#3b82f6';
      default: return '#6b7280';
    }
  };

  // Get employee statistics
  const stats = {
    total: employees.length,
    active: employees.filter(e => e.employment_status === 'active').length,
    probation: employees.filter(e => e.employment_status === 'probation').length,
    recent: employees.filter(e => e.hire_date && new Date(e.hire_date) >= new Date(Date.now() - 30 * 24 * 60 * 60 * 1000)).length
  };

  // Loading and error states (same pattern as TabScreen)
  if (authLoading) {
    return (
      <div style={{...styles.container, justifyContent: 'center', alignItems: 'center'}}>
        <h3>Loading Employee Profiles...</h3>
        <p>Authenticating user and loading business data...</p>
      </div>
    );
  }

  if (authError) {
    return (
      <div style={{...styles.container, justifyContent: 'center', alignItems: 'center'}}>
        <h3>Authentication Error</h3>
        <p>{authError}</p>
        <button 
          style={styles.createButton}
          onClick={() => navigate('/login')}
        >
          Return to Login
        </button>
      </div>
    );
  }

  if (loading) {
    return (
      <div style={styles.container}>
        <div style={styles.loading}>Loading employee profiles...</div>
      </div>
    );
  }

  return (
    <div style={styles.container}>
      {/* Header */}
      <div style={styles.header}>
        <h2>Employee Profiles</h2>
        <p>Manage employee information and view change history</p>
      </div>

      {/* Error Message */}
      {error && (
        <div style={styles.errorBanner}>
          <AlertCircle size={20} style={{ marginRight: '8px' }} />
          {error}
          <button
            onClick={() => setError(null)}
            style={styles.errorClose}
          >
            <X size={16} />
          </button>
        </div>
      )}

      {/* Statistics */}
      <div style={styles.stats}>
        <div style={styles.statCard}>
          <div style={styles.statValue}>{stats.total}</div>
          <div style={styles.statLabel}>Total Employees</div>
        </div>
        <div style={styles.statCard}>
          <div style={{...styles.statValue, color: '#059669'}}>{stats.active}</div>
          <div style={styles.statLabel}>Active</div>
        </div>
        <div style={styles.statCard}>
          <div style={{...styles.statValue, color: '#f59e0b'}}>{stats.probation}</div>
          <div style={styles.statLabel}>On Probation</div>
        </div>
        <div style={styles.statCard}>
          <div style={{...styles.statValue, color: '#3b82f6'}}>{stats.recent}</div>
          <div style={styles.statLabel}>Hired (Last 30 Days)</div>
        </div>
      </div>

      {/* Controls */}
      <div style={styles.controls}>
        <div style={styles.searchSection}>
          <div style={styles.searchGroup}>
            <Search size={20} style={styles.searchIcon} />
            <input
              type="text"
              placeholder="Search employees by name, email, position, or employee #..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              style={styles.searchInput}
            />
          </div>
          
          <div style={styles.filterGroup}>
            <Filter size={20} style={styles.filterIcon} />
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              style={styles.filterSelect}
            >
              <option value="all">All Status</option>
              <option value="active">Active</option>
              <option value="probation">Probation</option>
              <option value="suspended">Suspended</option>
              <option value="terminated">Terminated</option>
              <option value="on_leave">On Leave</option>
            </select>
          </div>

          <div style={styles.filterGroup}>
            <select
              value={departmentFilter}
              onChange={(e) => setDepartmentFilter(e.target.value)}
              style={styles.filterSelect}
            >
              <option value="all">All Departments</option>
              {departments.map(dept => (
                <option key={dept} value={dept}>
                  {dept}
                </option>
              ))}
            </select>
          </div>
        </div>
        
        {canManageEmployees() && (
          <button
            onClick={() => setShowAddModal(true)}
            style={styles.createButton}
          >
            <Plus size={20} style={{ marginRight: '8px' }} />
            Add Employee
          </button>
        )}
      </div>

      {/* Employee Grid */}
      <div style={styles.content}>
        {filteredEmployees.length === 0 ? (
          <div style={styles.emptyState}>
            <Users size={64} style={styles.emptyIcon} />
            <h3 style={styles.emptyTitle}>No employees found</h3>
            <p style={styles.emptyText}>
              {searchTerm || statusFilter !== 'all' || departmentFilter !== 'all'
                ? 'Try adjusting your search filters.'
                : 'Get started by adding your first employee.'
              }
            </p>
            {canManageEmployees() && !searchTerm && statusFilter === 'all' && departmentFilter === 'all' && (
              <button
                onClick={() => setShowAddModal(true)}
                style={styles.createButton}
              >
                Add First Employee
              </button>
            )}
          </div>
        ) : (
          <div style={styles.employeeGrid}>
            {filteredEmployees.map((employee) => (
              <div key={employee.id} style={styles.employeeCard}>
                <div style={styles.employeeHeader}>
                  <div style={styles.employeeTitle}>
                    <div style={styles.employeeName}>
                      {employee.full_name}
                    </div>
                    <div style={styles.employeeNumber}>
                      #{employee.employee_number}
                    </div>
                  </div>
                  <div 
                    style={{
                      ...styles.statusBadge,
                      backgroundColor: `${getStatusColor(employee.employment_status)}20`,
                      color: getStatusColor(employee.employment_status),
                      border: `1px solid ${getStatusColor(employee.employment_status)}40`
                    }}
                  >
                    {employee.employment_status?.toUpperCase() || 'UNKNOWN'}
                  </div>
                </div>

                <div style={styles.employeeBody}>
                  <div style={styles.employeeInfo}>
                    <div style={styles.infoRow}>
                      <strong>Email:</strong> {employee.email}
                    </div>
                    {employee.phone && (
                      <div style={styles.infoRow}>
                        <strong>Phone:</strong> {employee.phone}
                      </div>
                    )}
                    {employee.position && (
                      <div style={styles.infoRow}>
                        <strong>Position:</strong> {employee.position}
                      </div>
                    )}
                    {employee.department && (
                      <div style={styles.infoRow}>
                        <strong>Department:</strong> {employee.department}
                      </div>
                    )}
                    {employee.hire_date && (
                      <div style={styles.infoRow}>
                        <strong>Hire Date:</strong> {new Date(employee.hire_date).toLocaleDateString()}
                      </div>
                    )}
                    {employee.tenure && (
                      <div style={styles.infoRow}>
                        <strong>Tenure:</strong> {employee.tenure}
                      </div>
                    )}
                    {employee.wage && (
                      <div style={styles.infoRow}>
                        <strong>Wage:</strong> ${employee.wage}/hour
                      </div>
                    )}
                  </div>
                </div>

                <div style={styles.employeeActions}>
                  <button
                    onClick={() => handleViewEmployee(employee)}
                    style={styles.actionButton}
                    title="View Employee"
                  >
                    <Eye size={16} />
                    View
                  </button>
                  
                  {canViewAuditHistory() && (
                    <button
                      onClick={() => handleViewAuditHistory(employee)}
                      style={styles.auditButton}
                      title="View Change History"
                    >
                      <Clock size={16} />
                      History
                    </button>
                  )}
                  
                  {canManageEmployees() && (
                    <>
                      <button
                        onClick={() => handleEditEmployee(employee)}
                        style={styles.actionButton}
                        title="Edit Employee"
                      >
                        <Edit size={16} />
                        Edit
                      </button>
                      <button
                        onClick={() => handleDeleteEmployee(employee)}
                        style={styles.deleteButton}
                        title="Delete Employee"
                      >
                        <Trash2 size={16} />
                      </button>
                    </>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Add Employee Modal */}
      <AddEmployeeModal
        isOpen={showAddModal}
        onClose={() => setShowAddModal(false)}
        businessId={selectedBusinessId}
        onEmployeeCreated={handleEmployeeCreated}
        userContext={userContext}
        mode="create"
      />

      {/* Edit Employee Modal */}
      <EmployeeEditModal
        isOpen={showEditModal}
        employee={selectedEmployee}
        userContext={userContext}
        onClose={() => {
          setShowEditModal(false);
          setSelectedEmployee(null);
        }}
        onSave={handleEmployeeSaved}
        mode="edit"
      />

      {/* Audit History Modal */}
      <EmployeeAuditHistory
        isOpen={showAuditHistory}
        employee={selectedEmployee}
        userContext={userContext}
        onClose={() => {
          setShowAuditHistory(false);
          setSelectedEmployee(null);
        }}
      />
    </div>
  );
};

const styles = {
  container: {
    display: 'flex',
    flexDirection: 'column',
    height: '100vh',
    backgroundColor: '#f8f9fa',
    padding: '20px',
    paddingTop: '100px',
    boxSizing: 'border-box'
  },
  header: {
    marginBottom: '30px',
    textAlign: 'center'
  },
  errorBanner: {
    display: 'flex',
    alignItems: 'center',
    backgroundColor: '#fee2e2',
    color: '#dc2626',
    padding: '15px',
    borderRadius: '8px',
    marginBottom: '20px',
    position: 'relative'
  },
  errorClose: {
    position: 'absolute',
    right: '15px',
    background: 'none',
    border: 'none',
    color: '#dc2626',
    cursor: 'pointer'
  },
  stats: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
    gap: '15px',
    marginBottom: '30px'
  },
  statCard: {
    backgroundColor: 'white',
    padding: '20px',
    borderRadius: '8px',
    textAlign: 'center',
    border: '1px solid #e5e7eb'
  },
  statValue: {
    fontSize: '24px',
    fontWeight: 'bold',
    color: '#008080',
    marginBottom: '8px'
  },
  statLabel: {
    fontSize: '14px',
    color: '#6b7280'
  },
  controls: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: '30px',
    gap: '20px',
    flexWrap: 'wrap'
  },
  searchSection: {
    display: 'flex',
    gap: '15px',
    flex: 1,
    flexWrap: 'wrap'
  },
  searchGroup: {
    position: 'relative',
    flex: 1,
    minWidth: '300px'
  },
  searchIcon: {
    position: 'absolute',
    left: '12px',
    top: '50%',
    transform: 'translateY(-50%)',
    color: '#6b7280'
  },
  searchInput: {
    width: '100%',
    paddingLeft: '40px',
    paddingRight: '12px',
    paddingTop: '12px',
    paddingBottom: '12px',
    border: '2px solid #008080',
    borderRadius: '8px',
    fontSize: '16px',
    boxSizing: 'border-box'
  },
  filterGroup: {
    position: 'relative',
    minWidth: '150px'
  },
  filterIcon: {
    position: 'absolute',
    left: '12px',
    top: '50%',
    transform: 'translateY(-50%)',
    color: '#6b7280',
    zIndex: 1
  },
  filterSelect: {
    width: '100%',
    paddingLeft: '40px',
    paddingRight: '12px',
    paddingTop: '12px',
    paddingBottom: '12px',
    border: '2px solid #008080',
    borderRadius: '8px',
    fontSize: '16px',
    backgroundColor: 'white',
    boxSizing: 'border-box'
  },
  createButton: {
    display: 'flex',
    alignItems: 'center',
    padding: '12px 20px',
    backgroundColor: '#008080',
    color: 'white',
    border: 'none',
    borderRadius: '8px',
    fontSize: '16px',
    fontWeight: 'bold',
    cursor: 'pointer',
    whiteSpace: 'nowrap'
  },
  content: {
    flex: 1,
    overflowY: 'auto'
  },
  emptyState: {
    textAlign: 'center',
    padding: '60px 20px',
    color: '#6b7280'
  },
  emptyIcon: {
    color: '#9ca3af',
    marginBottom: '20px'
  },
  emptyTitle: {
    fontSize: '24px',
    fontWeight: 'bold',
    marginBottom: '10px',
    color: '#374151'
  },
  emptyText: {
    fontSize: '16px',
    marginBottom: '30px'
  },
  employeeGrid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fill, minmax(400px, 1fr))',
    gap: '20px',
    paddingBottom: '20px'
  },
  employeeCard: {
    backgroundColor: 'white',
    borderRadius: '12px',
    padding: '20px',
    border: '2px solid #e5e7eb',
    boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
    transition: 'all 0.2s ease'
  },
  employeeHeader: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: '15px',
    paddingBottom: '15px',
    borderBottom: '1px solid #f3f4f6'
  },
  employeeTitle: {
    flex: 1
  },
  employeeName: {
    fontSize: '18px',
    fontWeight: 'bold',
    color: '#1f2937',
    marginBottom: '4px'
  },
  employeeNumber: {
    fontSize: '14px',
    color: '#6b7280',
    fontWeight: '500'
  },
  statusBadge: {
    padding: '4px 8px',
    borderRadius: '4px',
    fontSize: '12px',
    fontWeight: 'bold'
  },
  employeeBody: {
    marginBottom: '15px'
  },
  employeeInfo: {
    display: 'flex',
    flexDirection: 'column',
    gap: '6px'
  },
  infoRow: {
    fontSize: '14px',
    color: '#374151'
  },
  employeeActions: {
    display: 'flex',
    gap: '8px',
    paddingTop: '15px',
    borderTop: '1px solid #f3f4f6',
    flexWrap: 'wrap'
  },
  actionButton: {
    display: 'flex',
    alignItems: 'center',
    gap: '6px',
    flex: 1,
    minWidth: '80px',
    padding: '8px 12px',
    backgroundColor: '#f3f4f6',
    color: '#374151',
    border: '1px solid #d1d5db',
    borderRadius: '6px',
    cursor: 'pointer',
    fontSize: '14px',
    fontWeight: '500',
    justifyContent: 'center'
  },
  auditButton: {
    display: 'flex',
    alignItems: 'center',
    gap: '6px',
    flex: 1,
    minWidth: '80px',
    padding: '8px 12px',
    backgroundColor: '#eff6ff',
    color: '#1d4ed8',
    border: '1px solid #bfdbfe',
    borderRadius: '6px',
    cursor: 'pointer',
    fontSize: '14px',
    fontWeight: '500',
    justifyContent: 'center'
  },
  deleteButton: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    padding: '8px 12px',
    backgroundColor: '#fee2e2',
    color: '#dc2626',
    border: '1px solid #fecaca',
    borderRadius: '6px',
    cursor: 'pointer',
    fontSize: '14px',
    fontWeight: '500'
  },
  loading: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    height: '200px',
    fontSize: '18px',
    color: '#6b7280'
  }
};

export default EmployeeProfiles;