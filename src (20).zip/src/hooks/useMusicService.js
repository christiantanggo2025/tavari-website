// src/hooks/useMusicService.js - SIMPLE WORKING VERSION
import { useEffect } from 'react';
import { globalMusicService } from '../services/GlobalMusicService';
import { useBusiness } from '../contexts/BusinessContext';

export const useMusicService = () => {
  const { business } = useBusiness();

  useEffect(() => {
    console.log('MUSIC SERVICE HOOK - Business ID:', business?.id);
    
    if (business?.id) {
      console.log('INITIALIZING MUSIC SERVICE...');
      
      // Simple direct initialization
      globalMusicService.initialize(business.id).then(() => {
        console.log('MUSIC SERVICE READY');
      }).catch(error => {
        console.error('MUSIC SERVICE INITIALIZATION FAILED:', error);
        
        // Retry once after 2 seconds
        setTimeout(() => {
          console.log('RETRYING MUSIC SERVICE INITIALIZATION...');
          globalMusicService.initialize(business.id);
        }, 2000);
      });
    }
  }, [business?.id]);

  return globalMusicService;
};