// services/GlobalMusicService.js - COMPLETE WORKING VERSION
import { supabase } from '../supabaseClient';

class GlobalMusicService {
  constructor() {
    // Core audio state
    this.audio = null;
    this.currentTrack = null;
    this.playlist = [];
    this.currentIndex = 0;
    this.isPlaying = false;
    this.volume = 0.7;
    this.businessId = null;
    this.isInitialized = false;
    this.listeners = [];
    this.readyToPlay = false;
	
	// UI mode flags
	this.isShuffleAllMode = true;
	this.shuffleMode = true;
	this.currentPlaylistId = null;
	this.playlistInfo = null;

    // Schedule monitoring
    this.scheduleInterval = null;
    this.activeSchedule = null;
    this.schedules = [];
    this.checkFrequency = 10000; // 10 seconds

    // Auto-play handling
    this.userInteracted = false;
    this.autoPlayEnabled = true;

    this.setupAudio();
    this.setupUserInteraction();
    
    console.log('GlobalMusicService constructed');
  }

  setupAudio() {
    this.audio = document.getElementById('global-audio-element') || new Audio();
    if (!document.getElementById('global-audio-element')) {
      this.audio.id = 'global-audio-element';
      this.audio.style.display = 'none';  // keep it hidden
      document.body.appendChild(this.audio);
    }

    this.audio.volume = this.volume;
    this.audio.preload = 'auto';

    this.audio.addEventListener('play', () => {
      this.isPlaying = true;
      this.notifyListeners();
    });

    this.audio.addEventListener('pause', () => {
      this.isPlaying = false;
      this.notifyListeners();
    });

    this.audio.addEventListener('ended', () => {
      this.next();
    });

    this.audio.addEventListener('error', () => {
      console.error('Audio error, skipping track');
      this.next();
    });
  }

  setupUserInteraction() {
    const handleInteraction = () => {
      if (!this.userInteracted) {
        this.userInteracted = true;
        console.log('USER INTERACTION DETECTED - ENABLING AUDIO');
        
        if (!this.isPlaying && this.playlist.length > 0) {
          this.play();
        }
      }
    };

    ['click', 'keydown', 'touchstart'].forEach(event => {
      document.addEventListener(event, handleInteraction, { once: true });
    });
  }

  async initialize(businessId) {
    console.log('INITIALIZING MUSIC SERVICE FOR BUSINESS:', businessId);

    if (!businessId) {
      console.error('NO BUSINESS ID PROVIDED');
      return;
    }

    // If already initialized for this business, skip re-init
    if (this.isInitialized && this.businessId === businessId) {
      console.log('MUSIC SERVICE ALREADY INITIALIZED FOR THIS BUSINESS — SKIPPING REINIT');
      return;
    }

    // If switching businesses, fully reset
    if (this.isInitialized && this.businessId && this.businessId !== businessId) {
      console.log('BUSINESS CHANGED — RESETTING MUSIC SERVICE');
      this.destroy();
    }

    this.businessId = businessId;

    try {
      await this.loadTracks();
      await this.loadSchedules();
      this.startScheduleMonitoring();

      if (this.playlist.length > 0) {
        await this.loadFirstTrack();
        this.attemptAutoPlay();
      }

      this.isInitialized = true;
      console.log('MUSIC SERVICE INITIALIZED SUCCESSFULLY');
    } catch (error) {
      console.error('MUSIC SERVICE INITIALIZATION FAILED:', error);
    }
  }

  async loadTracks() {
    console.log('LOADING TRACKS...');
    
    const { data, error } = await supabase
      .from('music_tracks')
      .select('*')
      .eq('business_id', this.businessId)
      .eq('include_in_shuffle', true);

    if (error) {
      console.error('ERROR LOADING TRACKS:', error);
      return;
    }

    this.playlist = data || [];
    console.log('LOADED', this.playlist.length, 'TRACKS');

    // Reset to global shuffle mode
    this.isShuffleAllMode = true;
    this.shuffleMode = true;
    this.currentPlaylistId = null;
    this.playlistInfo = null;

    // Shuffle the playlist
    this.shufflePlaylist();
    this.notifyListeners();
  }

  async loadSchedules() {
    console.log('LOADING SCHEDULES...');
    
    const { data, error } = await supabase
      .from('music_playlist_schedules')
      .select(`
        *,
        playlist:music_playlists(id, name, playlist_type)
      `)
      .eq('business_id', this.businessId)
      .eq('active', true);

    if (error) {
      console.error('ERROR LOADING SCHEDULES:', error);
      return;
    }

    this.schedules = data || [];
    console.log('LOADED', this.schedules.length, 'SCHEDULES');
  }

  startScheduleMonitoring() {
    if (this.scheduleInterval) {
      clearInterval(this.scheduleInterval);
    }

    console.log('STARTING SCHEDULE MONITORING - CHECKING EVERY', this.checkFrequency / 1000, 'SECONDS');

    this.scheduleInterval = setInterval(() => {
      this.checkSchedules();
    }, this.checkFrequency);

    // Check immediately
    this.checkSchedules();
  }

  checkSchedules() {
    const now = new Date();
    const currentTime = now.getHours() * 60 + now.getMinutes();
    const currentDate = now.toISOString().split('T')[0];
    const currentDay = now.getDay();

    console.log('CHECKING SCHEDULES AT', now.toTimeString().split(' ')[0]);

    // Gather all schedules that are active at this moment
    const activeSchedules = (this.schedules || []).filter(schedule =>
      this.isScheduleActive(schedule, currentTime, currentDate, currentDay)
    );

    if (activeSchedules.length === 0) {
      // No active schedule → return to shuffle if we were on one
      if (this.activeSchedule) {
        console.log('NO ACTIVE SCHEDULE - RETURNING TO SHUFFLE');
        this.activeSchedule = null;
        this.switchToShuffle();
      }
      return;
    }

    // Choose the highest priority (default to 1 if null), tie-break by latest created_at
    const bestSchedule = activeSchedules
      .slice()
      .sort((a, b) => {
        const pa = a.priority ?? 1;
        const pb = b.priority ?? 1;
        if (pb !== pa) return pb - pa;
        const aCreated = a.created_at ? new Date(a.created_at).getTime() : 0;
        const bCreated = b.created_at ? new Date(b.created_at).getTime() : 0;
        return bCreated - aCreated;
      })[0];

    // Switch only if the chosen schedule changed
    if (!this.activeSchedule || this.activeSchedule.id !== bestSchedule.id) {
      console.log(
        'SWITCHING TO SCHEDULED PLAYLIST:',
        bestSchedule.playlist?.name,
        '(priority:', bestSchedule.priority, ')'
      );
      this.activeSchedule = bestSchedule;
      this.switchToScheduledPlaylist(bestSchedule.playlist_id);
    }
  }

  isScheduleActive(schedule, currentTime, currentDate, currentDay) {
    // Convert schedule times to minutes
    const startTime = this.timeToMinutes(schedule.start_time);
    const endTime = this.timeToMinutes(schedule.end_time);

    // Check if current time is in range
    let timeMatch = false;
    if (startTime === endTime) {
      // Same start/end time - 30 minute window
      timeMatch = Math.abs(currentTime - startTime) <= 30;
    } else if (startTime < endTime) {
      // Normal range
      timeMatch = currentTime >= startTime && currentTime <= endTime;
    } else {
      // Overnight range
      timeMatch = currentTime >= startTime || currentTime <= endTime;
    }

    if (!timeMatch) return false;

    // Check date conditions
    if (schedule.schedule_date) {
      if (schedule.repeat_type === 'once') {
        return schedule.schedule_date === currentDate;
      } else if (schedule.repeat_type === 'daily') {
        return new Date(currentDate) >= new Date(schedule.schedule_date);
      } else if (schedule.repeat_type === 'weekly') {
        const scheduleDate = new Date(schedule.schedule_date);
        return new Date(currentDate) >= scheduleDate && currentDay === scheduleDate.getDay();
      }
    }

    if (schedule.day_of_week !== null) {
      return currentDay === schedule.day_of_week;
    }

    return true; // No date restrictions
  }

  timeToMinutes(timeString) {
    const [hours, minutes] = timeString.split(':').map(Number);
    return hours * 60 + minutes;
  }

  async switchToScheduledPlaylist(playlistId) {
    console.log('SWITCHING TO PLAYLIST:', playlistId);

    try {
      // Get playlist info
      const { data: playlist, error: playlistError } = await supabase
        .from('music_playlists')
        .select('*')
        .eq('id', playlistId)
        .single();

      if (playlistError) throw playlistError;

      // Get tracks for this playlist
      let tracks = [];
      
      if (playlist.playlist_type === 'shuffle') {
        // Get all shuffle tracks
        const { data, error } = await supabase
          .from('music_tracks')
          .select('*')
          .eq('business_id', this.businessId)
          .eq('include_in_shuffle', true);

        if (error) throw error;
        tracks = data || [];
        this.shuffleArray(tracks);
      } else {
        // Get ordered playlist tracks
        const { data, error } = await supabase
          .from('music_playlist_tracks')
          .select('music_tracks(*)')
          .eq('playlist_id', playlistId)
          .order('sort_order');

        if (error) throw error;
        tracks = data?.map(pt => pt.music_tracks) || [];
      }

      this.playlist = tracks;
      this.currentIndex = 0;

      if (tracks.length > 0) {
        await this.loadTrack(tracks[0]);
        if (this.userInteracted) {
          this.play();
        }
      }
	  
	  // Update mode/playlist info for UI
      this.currentPlaylistId = playlistId;
      this.playlistInfo = {
        id: playlist.id,
        name: playlist.name,
        description: playlist.description || '',
      };
      this.isShuffleAllMode = false;
      this.shuffleMode = playlist.playlist_type === 'shuffle';

      this.notifyListeners();
      console.log('SWITCHED TO PLAYLIST SUCCESS');

    } catch (error) {
      console.error('ERROR SWITCHING PLAYLIST:', error);
    }
  }
  
  /**
   * Manually switch to a specific playlist (ordered or shuffle).
   * Used by ManagerControls and PlaylistManager.
   */
  async switchToPlaylist(playlistId) {
    return this.switchToScheduledPlaylist(playlistId);
  }

  /**
   * Return to business-wide shuffle (all tracks marked include_in_shuffle).
   * Used by ManagerControls' Shuffle mode and when schedules end.
   */
  async switchToShuffle() {
    try {
      await this.loadTracks();        // repopulates this.playlist with global shuffle
      this.currentIndex = 0;

      if (this.playlist.length > 0) {
        await this.loadTrack(this.playlist[0]);
        if (this.userInteracted) {
          this.play();
        }
      }

      // Clear any active schedule/playlist context
      this.activeSchedule = null;
      this.currentPlaylistId = null;
      this.playlistInfo = null;
      this.isShuffleAllMode = true;
      this.shuffleMode = true;

      this.notifyListeners();
      console.log('SWITCHED TO GLOBAL SHUFFLE');
    } catch (err) {
      console.error('ERROR SWITCHING TO SHUFFLE:', err);
    }
  }

  shufflePlaylist() {
    this.shuffleArray(this.playlist);
  }

  shuffleArray(array) {
    for (let i = array.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [array[i], array[j]] = [array[j], array[i]];
    }
  }

  async loadFirstTrack() {
    if (this.playlist.length > 0) {
      this.currentIndex = Math.floor(Math.random() * this.playlist.length);
      await this.loadTrack(this.playlist[this.currentIndex]);
    }
  }

  async loadTrack(track) {
    console.log('LOADING TRACK:', track.title);

    try {
      const { data } = supabase.storage
        .from('music-files')
        .getPublicUrl(track.file_path);

      this.audio.src = data.publicUrl;
      this.currentTrack = track;
      this.readyToPlay = true;
      this.notifyListeners();

    } catch (error) {
      console.error('ERROR LOADING TRACK:', error);
    }
  }

  attemptAutoPlay() {
    if (!this.userInteracted) {
      console.log('WAITING FOR USER INTERACTION TO START PLAYBACK');
      return;
    }

    this.play();
  }

  async play() {
    if (!this.readyToPlay || !this.currentTrack) {
      await this.loadFirstTrack();
    }

    try {
      await this.audio.play();
      console.log('PLAYING:', this.currentTrack?.title);
    } catch (error) {
      console.log('PLAY BLOCKED - WAITING FOR USER INTERACTION');
    }
  }

  pause() {
    this.audio.pause();
  }

  togglePlay() {
    if (this.isPlaying) {
      this.pause();
    } else {
      this.play();
    }
  }

  async next() {
    if (this.playlist.length === 0) return;
    
    this.currentIndex = (this.currentIndex + 1) % this.playlist.length;
    await this.loadTrack(this.playlist[this.currentIndex]);
    
    if (this.isPlaying) {
      this.play();
    }
  }

  async previous() {
    if (this.playlist.length === 0) return;
    
    this.currentIndex = this.currentIndex === 0 ? this.playlist.length - 1 : this.currentIndex - 1;
    await this.loadTrack(this.playlist[this.currentIndex]);
    
    if (this.isPlaying) {
      this.play();
    }
  }

  setVolume(volume) {
    this.volume = Math.max(0, Math.min(1, volume));
    this.audio.volume = this.volume;
    this.notifyListeners();
  }

  getState() {
    return {
      currentTrack: this.currentTrack,
      playlist: this.playlist,
      currentIndex: this.currentIndex,
      isPlaying: this.isPlaying,
      volume: this.volume,
      currentTime: this.audio?.currentTime || 0,
      duration: this.audio?.duration || 0,
      isInitialized: this.isInitialized,
      readyToPlay: this.readyToPlay,
      userInteracted: this.userInteracted,
      activeSchedule: this.activeSchedule,
      schedulesCount: this.schedules.length,

      // NEW: UI-friendly fields
      currentTrackNumber: this.playlist.length ? this.currentIndex + 1 : 0,
      totalTracks: this.playlist.length,
      isShuffleAllMode: this.isShuffleAllMode || false,
      shuffleMode: this.shuffleMode || false,
      currentPlaylistId: this.currentPlaylistId || null,
      playlistInfo: this.playlistInfo || null,
    };
  }

  addListener(callback) {
    this.listeners.push(callback);
    return () => {
      const index = this.listeners.indexOf(callback);
      if (index > -1) this.listeners.splice(index, 1);
    };
  }

  notifyListeners() {
    const state = this.getState();
    this.listeners.forEach(callback => {
      try {
        callback(state);
      } catch (error) {
        console.error('Listener error:', error);
      }
    });
  }

  destroy() {
    if (this.scheduleInterval) {
      clearInterval(this.scheduleInterval);
    }
    this.pause();
    if (this.audio) {
      this.audio.src = '';
    }
    this.listeners = [];
  }

  // Public controls for external UI
  controls() {
    return {
      play: () => this.play(),
      pause: () => this.pause(),
      toggle: () => this.togglePlay(),
      next: () => this.next(),
      previous: () => this.previous(),
      setVolume: (v) => this.setVolume(v),
    };
  }
}

export const globalMusicService = new GlobalMusicService();
if (typeof window !== 'undefined') {
  window.globalMusicService = globalMusicService;
}
export default globalMusicService;