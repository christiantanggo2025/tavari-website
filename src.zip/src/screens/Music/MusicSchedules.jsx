import React, { useState, useEffect } from 'react';
import { supabase } from '../../supabaseClient';
import { FiPlus, FiTrash, FiClock, FiCalendar, FiAlertTriangle } from 'react-icons/fi';
import { useBusiness } from '../../contexts/BusinessContext';

const MusicSchedules = () => {
  const [activeTab, setActiveTab] = useState('calendar');
  const [schedules, setSchedules] = useState([]);
  const [playlists, setPlaylists] = useState([]);
  const [loading, setLoading] = useState(true);
  const { business } = useBusiness();

  // Calendar state
  const [selectedTimeSlot, setSelectedTimeSlot] = useState(null);
  const [calendarSchedules, setCalendarSchedules] = useState([]);

  // Modal states
  const [showCreateSchedule, setShowCreateSchedule] = useState(false);
  const [showCalendarScheduleModal, setShowCalendarScheduleModal] = useState(false);
  const [showEditSchedule, setShowEditSchedule] = useState(null);

  // Form states
  const [scheduleForm, setScheduleForm] = useState({
    playlist_id: '',
    days_of_week: [],
    start_time: '',
    end_time: '',
    priority: 1,
    active: true,
    immediate_switch: false,
    loop_playlist: true,
    stop_when_complete: false,
    schedule_date: null,
    repeat_type: 'weekly',
    repeat_until: null
  });

  // Time slots for calendar (24-hour format)
  const timeSlots = [];
  for (let hour = 0; hour < 24; hour++) {
    timeSlots.push(`${hour.toString().padStart(2, '0')}:00`);
  }

  // Days of week
  const daysOfWeek = [
    { id: 0, name: 'Sunday', short: 'Sun' },
    { id: 1, name: 'Monday', short: 'Mon' },
    { id: 2, name: 'Tuesday', short: 'Tue' },
    { id: 3, name: 'Wednesday', short: 'Wed' },
    { id: 4, name: 'Thursday', short: 'Thu' },
    { id: 5, name: 'Friday', short: 'Fri' },
    { id: 6, name: 'Saturday', short: 'Sat' }
  ];

  // Quick day selections
  const quickDaySelections = [
    { name: 'Weekdays', days: [1, 2, 3, 4, 5] },
    { name: 'Weekend', days: [0, 6] },
    { name: 'All Week', days: [0, 1, 2, 3, 4, 5, 6] }
  ];

  // Load schedules
  const loadSchedules = async () => {
    if (!business?.id) return;
    
    try {
      const { data, error } = await supabase
        .from('music_playlist_schedules')
        .select(`
          *,
          playlist:music_playlists(name, color_code)
        `)
        .eq('business_id', business.id)
        .eq('active', true)
        .order('day_of_week', { ascending: true });

      if (error) throw error;
      
      // Process schedules for calendar view
      const processedSchedules = data.map(schedule => ({
        ...schedule,
        playlist_name: schedule.playlist?.name,
        playlist_color: schedule.playlist?.color_code || '#14B8A6'
      }));
      
      setSchedules(processedSchedules);
      setCalendarSchedules(processedSchedules);
    } catch (error) {
      console.error('Error loading schedules:', error);
    }
  };

  // Load playlists
  const loadPlaylists = async () => {
    if (!business?.id) return;
    
    try {
      const { data, error } = await supabase
        .from('music_playlists')
        .select('*')
        .eq('business_id', business.id)
        .order('name', { ascending: true });

      if (error) throw error;
      setPlaylists(data || []);
    } catch (error) {
      console.error('Error loading playlists:', error);
    }
  };

  // Load all data
  useEffect(() => {
    if (business?.id) {
      setLoading(true);
      Promise.all([loadSchedules(), loadPlaylists()])
        .finally(() => setLoading(false));
    }
  }, [business?.id]);

  // Reload schedules when playlists change (for real-time updates)
  useEffect(() => {
    if (business?.id && playlists.length > 0) {
      loadSchedules();
    }
  }, [playlists.length, business?.id]);

  // Check schedule conflicts
  const checkScheduleConflicts = (newSchedule) => {
    const conflicts = [];
    const newStart = new Date(`2000-01-01T${newSchedule.start_time}`);
    const newEnd = new Date(`2000-01-01T${newSchedule.end_time}`);

    newSchedule.days_of_week.forEach(dayOfWeek => {
      const existingOnDay = schedules.filter(s => s.day_of_week === dayOfWeek);
      
      existingOnDay.forEach(existing => {
        const existingStart = new Date(`2000-01-01T${existing.start_time}`);
        const existingEnd = new Date(`2000-01-01T${existing.end_time}`);
        
        // Check for time overlap
        if ((newStart < existingEnd && newEnd > existingStart)) {
          conflicts.push(existing);
        }
      });
    });

    return conflicts;
  };

  // Create schedule (supports multi-day)
  const createSchedule = async (e) => {
    e.preventDefault();
    if (!business?.id || !scheduleForm.playlist_id || scheduleForm.days_of_week.length === 0) return;

    try {
      // Check for conflicts
      const conflicts = checkScheduleConflicts(scheduleForm);
      if (conflicts.length > 0) {
        const confirmCreate = confirm(`Warning: This schedule conflicts with ${conflicts.length} existing schedule(s). Continue anyway?`);
        if (!confirmCreate) return;
      }

      // Create schedule for each selected day
      const { data: userData } = await supabase.auth.getUser();
      const userId = userData?.user?.id || null;

      const scheduleInserts = scheduleForm.days_of_week.map(dayOfWeek => ({
        playlist_id: scheduleForm.playlist_id,
        day_of_week: dayOfWeek,
        start_time: scheduleForm.start_time,
        end_time: scheduleForm.end_time,
        priority: scheduleForm.priority,
        active: scheduleForm.active,
        immediate_switch: scheduleForm.immediate_switch,
        loop_playlist: scheduleForm.loop_playlist,
        stop_when_complete: scheduleForm.stop_when_complete,
        schedule_date: scheduleForm.schedule_date,
        repeat_type: scheduleForm.repeat_type,
        repeat_until: scheduleForm.repeat_until,
        business_id: business.id,
        created_by: userId
      }));

      const { error } = await supabase
        .from('music_playlist_schedules')
        .insert(scheduleInserts);

      if (error) throw error;

      await loadSchedules();
      setShowCreateSchedule(false);
      setShowCalendarScheduleModal(false);
      setSelectedTimeSlot(null);
      setScheduleForm({
        playlist_id: '',
        days_of_week: [],
        start_time: '',
        end_time: '',
        priority: 1,
        active: true,
        immediate_switch: false,
        loop_playlist: true,
        stop_when_complete: false,
        schedule_date: null,
        repeat_type: 'weekly',
        repeat_until: null
      });
    } catch (error) {
      console.error('Error creating schedule:', error);
      alert('Error creating schedule: ' + error.message);
    }
  };

  // Edit schedule
  const editSchedule = async (e) => {
    e.preventDefault();
    if (!business?.id || !scheduleForm.playlist_id || scheduleForm.days_of_week.length === 0) return;

    try {
      // Check for conflicts (excluding current schedule)
      const conflictsToCheck = schedules.filter(s => s.id !== showEditSchedule.id);
      const tempSchedules = schedules;
      setSchedules(conflictsToCheck); // Temporarily remove current schedule for conflict check
      const conflicts = checkScheduleConflicts(scheduleForm);
      setSchedules(tempSchedules); // Restore full schedule list

      if (conflicts.length > 0) {
        const confirmUpdate = confirm(`Warning: This schedule conflicts with ${conflicts.length} existing schedule(s). Continue anyway?`);
        if (!confirmUpdate) return;
      }

      const { error } = await supabase
        .from('music_playlist_schedules')
        .update({
          playlist_id: scheduleForm.playlist_id,
          day_of_week: scheduleForm.days_of_week[0], // Edit only supports single day for now
          start_time: scheduleForm.start_time,
          end_time: scheduleForm.end_time,
          priority: scheduleForm.priority,
          active: scheduleForm.active
        })
        .eq('id', showEditSchedule.id);

      if (error) throw error;

      await loadSchedules();
      setShowEditSchedule(null);
      setScheduleForm({
        playlist_id: '',
        days_of_week: [],
        start_time: '',
        end_time: '',
        priority: 1,
        active: true,
        immediate_switch: false,
        loop_playlist: true,
        stop_when_complete: false,
        schedule_date: null,
        repeat_type: 'weekly',
        repeat_until: null
      });
    } catch (error) {
      console.error('Error updating schedule:', error);
      alert('Error updating schedule: ' + error.message);
    }
  };

  // Open edit modal with schedule data
  const openEditSchedule = (schedule) => {
    setScheduleForm({
      playlist_id: schedule.playlist_id,
      days_of_week: [schedule.day_of_week],
      start_time: schedule.start_time,
      end_time: schedule.end_time,
      priority: schedule.priority,
      active: schedule.active,
      immediate_switch: schedule.immediate_switch || false,
      loop_playlist: schedule.loop_playlist || true,
      stop_when_complete: schedule.stop_when_complete || false,
      schedule_date: schedule.schedule_date,
      repeat_type: schedule.repeat_type || 'weekly',
      repeat_until: schedule.repeat_until
    });
    setShowEditSchedule(schedule);
  };
  const deleteSchedule = async (scheduleId) => {
    if (!confirm('Are you sure you want to delete this schedule?')) return;

    try {
      const { error } = await supabase
        .from('music_playlist_schedules')
        .delete()
        .eq('id', scheduleId);

      if (error) throw error;
      await loadSchedules();
    } catch (error) {
      console.error('Error deleting schedule:', error);
      alert('Error deleting schedule: ' + error.message);
    }
  };

  // Format time for display
  const formatTime = (timeString) => {
    if (!timeString) return '';
    const [hours, minutes] = timeString.split(':');
    const hour12 = hours % 12 || 12;
    const ampm = hours < 12 ? 'AM' : 'PM';
    return `${hour12}:${minutes} ${ampm}`;
  };

  // Format day of week
  const formatDayOfWeek = (dayNum) => {
    const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    return days[dayNum] || 'Unknown';
  };

  // Handle calendar time slot click
  const handleTimeSlotClick = (day, time) => {
    setSelectedTimeSlot({ day, time });
    setScheduleForm(prev => ({
      ...prev,
      days_of_week: [day],
      start_time: time,
      end_time: addHourToTime(time)
    }));
    setShowCalendarScheduleModal(true);
  };

  // Add hour to time string
  const addHourToTime = (timeString) => {
    const [hours, minutes] = timeString.split(':');
    const newHour = (parseInt(hours) + 1) % 24;
    return `${newHour.toString().padStart(2, '0')}:${minutes}`;
  };

  // Get schedule for specific day and time
  const getScheduleForTimeSlot = (day, time) => {
    // Normalize time strings to HH:MM and compare by minutes
    const toMinutes = (t) => {
      if (!t) return 0;
      // Accept "HH:MM" or "HH:MM:SS"
      const [hh, mm] = t.split(':');
      return parseInt(hh, 10) * 60 + parseInt(mm, 10);
    };

    const normalize = (t) => (t && t.length > 5 ? t.slice(0, 5) : t);
    const slotMins = toMinutes(normalize(time));

    return calendarSchedules.find((schedule) => {
      if (schedule.day_of_week !== day) return false;

      const startMins = toMinutes(normalize(schedule.start_time));
      const endMins   = toMinutes(normalize(schedule.end_time));

      return slotMins >= startMins && slotMins < endMins;
    });
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64 p-5">
        <div className="text-lg font-bold text-gray-700">Loading schedules...</div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto p-5">
      {/* Header */}
      <div className="mb-6">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Music Schedules</h1>
        <p className="text-gray-600">Schedule playlists to play automatically</p>
      </div>

      {/* Tab Navigation */}
      <div className="border-b-2 border-teal-500 mb-6">
        <nav className="-mb-px flex space-x-8">
          <button
            onClick={() => setActiveTab('calendar')}
            className={`py-3 px-4 border-b-2 font-bold text-sm transition-colors ${
              activeTab === 'calendar'
                ? 'border-teal-500 text-teal-600 bg-white'
                : 'border-transparent text-gray-700 hover:text-teal-600 hover:border-teal-300'
            }`}
          >
            <FiCalendar className="inline mr-2" />
            Schedule Calendar
          </button>
          <button
            onClick={() => setActiveTab('schedules')}
            className={`py-3 px-4 border-b-2 font-bold text-sm transition-colors ${
              activeTab === 'schedules'
                ? 'border-teal-500 text-teal-600 bg-white'
                : 'border-transparent text-gray-700 hover:text-teal-600 hover:border-teal-300'
            }`}
          >
            <FiClock className="inline mr-2" />
            Schedule List
          </button>
        </nav>
      </div>

      {/* Calendar Tab */}
      {activeTab === 'calendar' && (
        <div>
          <div className="mb-6">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Weekly Schedule Calendar</h2>
            <p className="text-gray-700 mb-4 font-medium">Click on any time slot to create a new schedule</p>
          </div>

          {/* Calendar Grid */}
          <div 
            className="bg-white rounded-lg border-2 border-teal-200 overflow-hidden shadow-lg"
            style={{ 
              display: 'grid',
              gridTemplateColumns: '120px repeat(7, minmax(140px, 1fr))',
              minWidth: '100%'
            }}
          >
            {/* Header with days */}
            <div 
              className="col-span-8 bg-teal-500 sticky top-0 z-20 shadow"
              style={{ 
                display: 'grid',
                gridTemplateColumns: '120px repeat(7, minmax(140px, 1fr))'
              }}
            >
              <div 
                className="p-4 text-center font-bold text-white border-r-2 border-teal-400 sticky left-0 z-30 bg-teal-500"
                style={{ gridColumn: '1' }}
              >
                <FiClock className="inline mr-2" />
                Time
              </div>
              {daysOfWeek.map((day, index) => (
                <div 
                  key={day.id} 
                  className="p-4 text-center font-bold text-white border-r-2 border-teal-400 last:border-r-0"
                  style={{ gridColumn: `${index + 2}` }}
                >
                  <FiCalendar className="inline mr-2 text-sm" />
                  {day.name}
                </div>
              ))}
            </div>

            {/* Time slots container */}
            <div 
              className="col-span-8 h-[640px] overflow-auto"
              style={{ 
                display: 'grid',
                gridTemplateColumns: '120px repeat(7, minmax(140px, 1fr))'
              }}
            >
              {timeSlots.map((time, timeIndex) => (
                <React.Fragment key={time}>
                  {/* Time label */}
                  <div 
                    className="p-4 text-center font-bold text-gray-900 bg-teal-50 border-r-2 border-teal-200 border-b border-teal-100 min-h-[72px] flex items-center justify-center sticky left-0 z-10"
                    style={{ 
                      gridColumn: '1',
                      gridRow: `${timeIndex + 1}`
                    }}
                  >
                    <span className="text-sm">{formatTime(time)}</span>
                  </div>
                  
                  {/* Day columns */}
                  {daysOfWeek.map((day, dayIndex) => {
                    const schedule = getScheduleForTimeSlot(day.id, time);
                    return (
                      <div
                        key={`${day.id}-${time}`}
                        className="border-r border-teal-100 border-b border-teal-100 last:border-r-0 min-h-[72px] cursor-pointer hover:bg-teal-50 transition-all relative p-2 flex items-center justify-center"
                        style={{ 
                          gridColumn: `${dayIndex + 2}`,
                          gridRow: `${timeIndex + 1}`,
                          backgroundColor: schedule ? `${schedule.playlist_color}20` : 'transparent',
                          borderLeft: schedule ? `4px solid ${schedule.playlist_color}` : 'none'
                        }}
                        onClick={() => handleTimeSlotClick(day.id, time)}
                        title={schedule ? `${schedule.playlist_name} (${formatTime(schedule.start_time)} - ${formatTime(schedule.end_time)})` : 'Click to create schedule'}
                      >
                        {schedule ? (
                          <div 
                            className="w-full text-center p-2 rounded-md text-white shadow-sm font-bold text-xs"
                            style={{ backgroundColor: schedule.playlist_color }}
                          >
                            <div className="truncate">{schedule.playlist_name}</div>
                            <div className="text-xs opacity-90 mt-1">
                              {formatTime(schedule.start_time)} - {formatTime(schedule.end_time)}
                            </div>
                          </div>
                        ) : (
                          <div className="w-full h-full flex items-center justify-center text-gray-400 hover:text-teal-600 transition-colors">
                            <FiPlus className="text-lg" />
                          </div>
                        )}
                      </div>
                    );
                  })}
                </React.Fragment>
              ))}
            </div>
          </div>

          {/* Calendar Legend */}
          <div className="mt-6 bg-white border-2 border-teal-200 rounded-lg p-4">
            <h3 className="font-bold text-gray-900 mb-3">Schedule Legend</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {playlists.slice(0, 8).map(playlist => (
                <div key={playlist.id} className="flex items-center">
                  <div 
                    className="w-4 h-4 rounded mr-2 border border-gray-300"
                    style={{ backgroundColor: playlist.color_code }}
                  ></div>
                  <span className="text-sm font-medium text-gray-700 truncate">{playlist.name}</span>
                </div>
              ))}
              {playlists.length > 8 && (
                <div className="text-sm text-gray-500 font-medium">
                  +{playlists.length - 8} more playlists
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Schedules Tab */}
      {activeTab === 'schedules' && (
        <div>
          {/* Create Schedule Button - Updated to Tavari Standards */}
          <div className="grid grid-cols-3 gap-4 mb-6">
            <button
              onClick={() => setShowCreateSchedule(true)}
              className="bg-white border-2 border-teal-500 text-gray-700 font-bold py-6 px-4 rounded-lg hover:bg-teal-50 transition-colors flex flex-col items-center justify-center min-h-[120px]"
            >
              <FiPlus className="text-3xl mb-3 text-teal-600" />
              <span className="text-lg">Create Schedule</span>
            </button>
            <button
              disabled
              className="bg-white border-2 border-gray-300 text-gray-400 font-bold py-6 px-4 rounded-lg flex flex-col items-center justify-center min-h-[120px] cursor-not-allowed"
            >
              <FiClock className="text-3xl mb-3" />
              <span className="text-lg">Bulk Edit</span>
            </button>
            <button
              disabled
              className="bg-white border-2 border-gray-300 text-gray-400 font-bold py-6 px-4 rounded-lg flex flex-col items-center justify-center min-h-[120px] cursor-not-allowed"
            >
              <FiCalendar className="text-3xl mb-3" />
              <span className="text-lg">Import Schedule</span>
            </button>
          </div>

          {/* Schedules List */}
          <div className="space-y-4">
            {schedules.map((schedule) => (
              <div
                key={schedule.id}
                className="bg-white rounded-lg border-2 border-teal-200 p-6 hover:shadow-lg hover:border-teal-400 transition-all"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <div
                      className="w-6 h-6 rounded mr-4 border-2 border-gray-300"
                      style={{ backgroundColor: schedule.playlist_color }}
                    ></div>
                    <div>
                      <h3 className="font-bold text-lg text-gray-900">{schedule.playlist_name}</h3>
                      <div className="flex items-center text-sm text-gray-700 font-medium">
                        <FiClock className="mr-2 text-teal-600" />
                        {formatDayOfWeek(schedule.day_of_week)} • 
                        {formatTime(schedule.start_time)} - {formatTime(schedule.end_time)}
                        {schedule.repeat_type !== 'weekly' && (
                          <span className="ml-2 text-teal-600">• {schedule.repeat_type}</span>
                        )}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3">
                    <span className={`px-3 py-1 rounded font-bold text-sm ${
                      schedule.active 
                        ? 'bg-teal-100 text-teal-800 border border-teal-300' 
                        : 'bg-gray-100 text-gray-800 border border-gray-300'
                    }`}>
                      {schedule.active ? 'Active' : 'Inactive'}
                    </span>
                    <button
                      onClick={() => openEditSchedule(schedule)}
                      className="bg-white border-2 border-teal-500 text-teal-600 p-2 rounded hover:bg-teal-50 transition-colors"
                      title="Edit Schedule"
                    >
                      <FiClock />
                    </button>
                    <button
                      onClick={() => deleteSchedule(schedule.id)}
                      className="bg-white border-2 border-red-500 text-red-600 p-2 rounded hover:bg-red-50 transition-colors"
                    >
                      <FiTrash />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {schedules.length === 0 && (
            <div className="text-center py-12 bg-white border-2 border-teal-200 rounded-lg">
              <FiCalendar className="mx-auto text-teal-400 text-6xl mb-4" />
              <h3 className="text-xl font-bold text-gray-900 mb-2">No schedules yet</h3>
              <p className="text-gray-600 mb-6 font-medium">Create your first schedule to automate playlist playback</p>
              <button
                onClick={() => setShowCreateSchedule(true)}
                className="bg-teal-500 text-white font-bold py-3 px-6 rounded-lg hover:bg-teal-600 transition-colors"
              >
                Create Schedule
              </button>
            </div>
          )}
        </div>
      )}

      {/* Edit Schedule Modal */}
      {showEditSchedule && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-5">
          <div className="bg-white rounded-lg border-2 border-teal-200 p-6 w-full max-w-md">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Edit Schedule</h2>
            <form onSubmit={editSchedule}>
              <div className="mb-4">
                <label className="block text-sm font-bold text-gray-700 mb-2">
                  Playlist
                </label>
                <select
                  value={scheduleForm.playlist_id}
                  onChange={(e) => setScheduleForm(prev => ({ ...prev, playlist_id: e.target.value }))}
                  className="w-full border-2 border-teal-300 rounded-lg px-3 py-2 font-medium"
                  required
                >
                  <option value="">Select a playlist</option>
                  {playlists.map((playlist) => (
                    <option key={playlist.id} value={playlist.id}>
                      {playlist.name}
                    </option>
                  ))}
                </select>
              </div>

              <div className="mb-4">
                <label className="block text-sm font-bold text-gray-700 mb-2">
                  Day of Week
                </label>
                <select
                  value={scheduleForm.days_of_week[0] || ''}
                  onChange={(e) => setScheduleForm(prev => ({ ...prev, days_of_week: [parseInt(e.target.value)] }))}
                  className="w-full border-2 border-teal-300 rounded-lg px-3 py-2 font-medium"
                  required
                >
                  <option value="">Select a day</option>
                  {daysOfWeek.map(day => (
                    <option key={day.id} value={day.id}>
                      {day.name}
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-4 mb-4">
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-2">
                    Start Time
                  </label>
                  <input
                    type="time"
                    value={scheduleForm.start_time}
                    onChange={(e) => setScheduleForm(prev => ({ ...prev, start_time: e.target.value }))}
                    className="w-full border-2 border-teal-300 rounded-lg px-3 py-2 font-medium"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-2">
                    End Time
                  </label>
                  <input
                    type="time"
                    value={scheduleForm.end_time}
                    onChange={(e) => setScheduleForm(prev => ({ ...prev, end_time: e.target.value }))}
                    className="w-full border-2 border-teal-300 rounded-lg px-3 py-2 font-medium"
                    required
                  />
                </div>
              </div>

              <div className="mb-4">
                <label className="block text-sm font-bold text-gray-700 mb-2">
                  Priority (1-10)
                </label>
                <input
                  type="number"
                  min="1"
                  max="10"
                  value={scheduleForm.priority}
                  onChange={(e) => setScheduleForm(prev => ({ ...prev, priority: parseInt(e.target.value) }))}
                  className="w-full border-2 border-teal-300 rounded-lg px-3 py-2 font-medium"
                />
              </div>

              <div className="mb-4">
                <label className="flex items-center">
                  <input
                    type="checkbox"
                    checked={scheduleForm.active}
                    onChange={(e) => setScheduleForm(prev => ({ ...prev, active: e.target.checked }))}
                    className="mr-3"
                  />
                  <span className="font-bold text-gray-700">Schedule is active</span>
                </label>
              </div>

              {/* Conflict warning */}
              {scheduleForm.playlist_id && scheduleForm.days_of_week.length > 0 && scheduleForm.start_time && scheduleForm.end_time && (
                (() => {
                  // Temporarily exclude current schedule for conflict check
                  const otherSchedules = schedules.filter(s => s.id !== showEditSchedule.id);
                  const tempSchedules = schedules;
                  setSchedules(otherSchedules);
                  const conflicts = checkScheduleConflicts(scheduleForm);
                  setSchedules(tempSchedules);
                  
                  return conflicts.length > 0 && (
                    <div className="mb-4 p-4 bg-yellow-50 border-2 border-yellow-300 rounded-lg">
                      <div className="flex items-center">
                        <FiAlertTriangle className="text-yellow-600 mr-3 text-lg" />
                        <span className="text-sm font-bold text-yellow-800">
                          Warning: This schedule conflicts with {conflicts.length} existing schedule(s)
                        </span>
                      </div>
                    </div>
                  );
                })()
              )}

              <div className="flex space-x-3">
                <button
                  type="button"
                  onClick={() => {
                    setShowEditSchedule(null);
                    setScheduleForm({
                      playlist_id: '',
                      days_of_week: [],
                      start_time: '',
                      end_time: '',
                      priority: 1,
                      active: true,
                      immediate_switch: false,
                      loop_playlist: true,
                      stop_when_complete: false,
                      schedule_date: null,
                      repeat_type: 'weekly',
                      repeat_until: null
                    });
                  }}
                  className="flex-1 bg-white border-2 border-gray-400 text-gray-700 font-bold py-3 px-4 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 bg-teal-500 text-white font-bold py-3 px-4 rounded-lg hover:bg-teal-600 transition-colors"
                >
                  Update Schedule
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Create Schedule Modal */}
      {(showCreateSchedule || showCalendarScheduleModal) && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-5">
          <div className="bg-white rounded-lg border-2 border-teal-200 p-6 w-full max-w-md">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">
              {showCalendarScheduleModal ? 'Create Schedule for Time Slot' : 'Create New Schedule'}
            </h2>
            <form onSubmit={createSchedule}>
              <div className="mb-4">
                <label className="block text-sm font-bold text-gray-700 mb-2">
                  Playlist
                </label>
                <select
                  value={scheduleForm.playlist_id}
                  onChange={(e) => setScheduleForm(prev => ({ ...prev, playlist_id: e.target.value }))}
                  className="w-full border-2 border-teal-300 rounded-lg px-3 py-2 font-medium"
                  required
                >
                  <option value="">Select a playlist</option>
                  {playlists.map((playlist) => (
                    <option key={playlist.id} value={playlist.id}>
                      {playlist.name}
                    </option>
                  ))}
                </select>
              </div>

              <div className="mb-4">
                <label className="block text-sm font-bold text-gray-700 mb-2">
                  Days of Week
                </label>
                
                {/* Quick selections */}
                <div className="mb-3">
                  {quickDaySelections.map(selection => (
                    <button
                      key={selection.name}
                      type="button"
                      onClick={() => setScheduleForm(prev => ({ ...prev, days_of_week: selection.days }))}
                      className="mr-2 mb-2 px-3 py-2 text-sm bg-white border-2 border-teal-400 text-gray-700 font-bold rounded hover:bg-teal-50 transition-colors"
                    >
                      {selection.name}
                    </button>
                  ))}
                </div>

                {/* Individual days */}
                <div className="grid grid-cols-4 gap-2">
                  {daysOfWeek.map(day => (
                    <label key={day.id} className="flex items-center">
                      <input
                        type="checkbox"
                        checked={scheduleForm.days_of_week.includes(day.id)}
                        onChange={(e) => {
                          if (e.target.checked) {
                            setScheduleForm(prev => ({
                              ...prev,
                              days_of_week: [...prev.days_of_week, day.id]
                            }));
                          } else {
                            setScheduleForm(prev => ({
                              ...prev,
                              days_of_week: prev.days_of_week.filter(d => d !== day.id)
                            }));
                          }
                        }}
                        className="mr-2"
                      />
                      <span className="text-sm font-bold text-gray-700">{day.short}</span>
                    </label>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 mb-4">
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-2">
                    Start Time
                  </label>
                  <input
                    type="time"
                    value={scheduleForm.start_time}
                    onChange={(e) => setScheduleForm(prev => ({ ...prev, start_time: e.target.value }))}
                    className="w-full border-2 border-teal-300 rounded-lg px-3 py-2 font-medium"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-2">
                    End Time
                  </label>
                  <input
                    type="time"
                    value={scheduleForm.end_time}
                    onChange={(e) => setScheduleForm(prev => ({ ...prev, end_time: e.target.value }))}
                    className="w-full border-2 border-teal-300 rounded-lg px-3 py-2 font-medium"
                    required
                  />
                </div>
              </div>

              <div className="mb-4">
                <label className="block text-sm font-bold text-gray-700 mb-2">
                  Priority (1-10)
                </label>
                <input
                  type="number"
                  min="1"
                  max="10"
                  value={scheduleForm.priority}
                  onChange={(e) => setScheduleForm(prev => ({ ...prev, priority: parseInt(e.target.value) }))}
                  className="w-full border-2 border-teal-300 rounded-lg px-3 py-2 font-medium"
                />
              </div>

              {/* Conflict warning */}
              {scheduleForm.playlist_id && scheduleForm.days_of_week.length > 0 && scheduleForm.start_time && scheduleForm.end_time && (
                (() => {
                  const conflicts = checkScheduleConflicts(scheduleForm);
                  return conflicts.length > 0 && (
                    <div className="mb-4 p-4 bg-yellow-50 border-2 border-yellow-300 rounded-lg">
                      <div className="flex items-center">
                        <FiAlertTriangle className="text-yellow-600 mr-3 text-lg" />
                        <span className="text-sm font-bold text-yellow-800">
                          Warning: This schedule conflicts with {conflicts.length} existing schedule(s)
                        </span>
                      </div>
                    </div>
                  );
                })()
              )}

              <div className="flex space-x-3">
                <button
                  type="button"
                  onClick={() => {
                    setShowCreateSchedule(false);
                    setShowCalendarScheduleModal(false);
                    setSelectedTimeSlot(null);
                    setScheduleForm({
                      playlist_id: '',
                      days_of_week: [],
                      start_time: '',
                      end_time: '',
                      priority: 1,
                      active: true,
                      immediate_switch: false,
                      loop_playlist: true,
                      stop_when_complete: false,
                      schedule_date: null,
                      repeat_type: 'weekly',
                      repeat_until: null
                    });
                  }}
                  className="flex-1 bg-white border-2 border-gray-400 text-gray-700 font-bold py-3 px-4 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 bg-teal-500 text-white font-bold py-3 px-4 rounded-lg hover:bg-teal-600 transition-colors"
                >
                  Create
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default MusicSchedules;