import React, { useState, useEffect } from 'react';
import { supabase } from '../../supabaseClient';
import { FiPlus, FiEdit, FiTrash, FiMusic, FiShuffle, FiList, FiX } from 'react-icons/fi';
import { useBusiness } from '../../contexts/BusinessContext';

const PlaylistManager = () => {
  const [playlists, setPlaylists] = useState([]);
  const [tracks, setTracks] = useState([]);
  const [loading, setLoading] = useState(true);
  const { business } = useBusiness();

  // Modal states
  const [showCreatePlaylist, setShowCreatePlaylist] = useState(false);
  const [showTrackManager, setShowTrackManager] = useState(null);

  // Form states
  const [playlistForm, setPlaylistForm] = useState({
    name: '',
    description: '',
    playlist_type: 'ordered',
    color_code: '#14B8A6',
    shuffle_include_new_uploads: true
  });

  // Track management state
  const [playlistTracks, setPlaylistTracks] = useState([]);
  const [availableTracks, setAvailableTracks] = useState([]);
  const [trackSearchTerm, setTrackSearchTerm] = useState('');

  // Helper function to get random color for playlists
  const getRandomColor = () => {
    const colors = [
      '#14B8A6', '#10B981', '#0D9488', '#059669', 
      '#047857', '#065F46', '#064E3B', '#022C22'
    ];
    return colors[Math.floor(Math.random() * colors.length)];
  };

  // Load playlists
  const loadPlaylists = async () => {
    if (!business?.id) return;
    
    try {
      const { data, error } = await supabase
        .from('music_playlists')
        .select(`
          *,
          track_count:music_playlist_tracks(count)
        `)
        .eq('business_id', business.id)
        .order('created_at', { ascending: false });

      if (error) throw error;
      
      // Process track counts
      const processedPlaylists = data.map(playlist => ({
        ...playlist,
        track_count: playlist.track_count?.[0]?.count || 0
      }));
      
      setPlaylists(processedPlaylists);
    } catch (error) {
      console.error('Error loading playlists:', error);
    }
  };

  // Load tracks for playlist creation
  const loadTracks = async () => {
    if (!business?.id) return;
    
    try {
      const { data, error } = await supabase
        .from('music_tracks')
        .select('*')
        .eq('business_id', business.id)
        .order('title', { ascending: true });

      if (error) throw error;
      setTracks(data || []);
      setAvailableTracks(data || []);
    } catch (error) {
      console.error('Error loading tracks:', error);
    }
  };

  // Load playlist tracks
  const loadPlaylistTracks = async (playlistId) => {
    if (!playlistId) return;
    
    try {
      const { data, error } = await supabase
        .from('music_playlist_tracks')
        .select(`
          *,
          track:music_tracks(*)
        `)
        .eq('playlist_id', playlistId)
        .order('sort_order', { ascending: true });

      if (error) throw error;
      setPlaylistTracks(data || []);
    } catch (error) {
      console.error('Error loading playlist tracks:', error);
    }
  };

  // Load all data
  useEffect(() => {
    if (business?.id) {
      setLoading(true);
      Promise.all([loadPlaylists(), loadTracks()])
        .finally(() => setLoading(false));
    }
  }, [business?.id]);

  // Create playlist
  const createPlaylist = async (e) => {
    e.preventDefault();
    if (!business?.id) return;

    try {
      const { data, error } = await supabase
        .from('music_playlists')
        .insert([{
          ...playlistForm,
          business_id: business.id,
          color_code: playlistForm.color_code || getRandomColor()
        }])
        .select()
        .single();

      if (error) throw error;

      setPlaylists(prev => [data, ...prev]);
      setShowCreatePlaylist(false);
      setPlaylistForm({
        name: '',
        description: '',
        playlist_type: 'ordered',
        color_code: '#14B8A6',
        shuffle_include_new_uploads: true
      });
    } catch (error) {
      console.error('Error creating playlist:', error);
      alert('Error creating playlist: ' + error.message);
    }
  };

  // Add track to playlist
  const addTrackToPlaylist = async (trackId, playlistId) => {
    try {
      // Get current max sort order
      const { data: maxOrder } = await supabase
        .from('music_playlist_tracks')
        .select('sort_order')
        .eq('playlist_id', playlistId)
        .order('sort_order', { ascending: false })
        .limit(1);

      const nextOrder = (maxOrder?.[0]?.sort_order || 0) + 1;

      const { error } = await supabase
        .from('music_playlist_tracks')
        .insert([{
          playlist_id: playlistId,
          track_id: trackId,
          sort_order: nextOrder
        }]);

      if (error) throw error;
      
      await loadPlaylistTracks(playlistId);
      await loadPlaylists(); // Update track counts
    } catch (error) {
      console.error('Error adding track to playlist:', error);
      alert('Error adding track: ' + error.message);
    }
  };

  // Remove track from playlist
  const removeTrackFromPlaylist = async (playlistTrackId, playlistId) => {
    try {
      const { error } = await supabase
        .from('music_playlist_tracks')
        .delete()
        .eq('playlist_id', playlistId)
        .eq('track_id', playlistTrackId);

      if (error) throw error;
      
      await loadPlaylistTracks(playlistId);
      await loadPlaylists(); // Update track counts
    } catch (error) {
      console.error('Error removing track from playlist:', error);
      alert('Error removing track: ' + error.message);
    }
  };

  // Delete playlist
  const deletePlaylist = async (playlistId) => {
    if (!confirm('Are you sure you want to delete this playlist?')) return;

    try {
      const { error } = await supabase
        .from('music_playlists')
        .delete()
        .eq('id', playlistId);

      if (error) throw error;
      setPlaylists(prev => prev.filter(p => p.id !== playlistId));
    } catch (error) {
      console.error('Error deleting playlist:', error);
      alert('Error deleting playlist: ' + error.message);
    }
  };

  // Filter available tracks based on search
  const filteredAvailableTracks = availableTracks.filter(track => 
    !playlistTracks.some(pt => pt.track.id === track.id) &&
    (track.title.toLowerCase().includes(trackSearchTerm.toLowerCase()) ||
     track.artist?.toLowerCase().includes(trackSearchTerm.toLowerCase()))
  );

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64" style={{ padding: '20px' }}>
        <div className="text-lg font-bold text-gray-700">Loading playlists...</div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto" style={{ padding: '20px' }}>
      {/* Header */}
      <div className="mb-6">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Playlist Manager</h1>
        <p className="text-gray-600">Create and manage playlists for your music system</p>
      </div>

      {/* Action Buttons - Updated to Tavari 3x Grid Standard */}
      <div className="grid grid-cols-3 gap-4 mb-6">
        <button
          onClick={() => setShowCreatePlaylist(true)}
          className="bg-white border-2 border-teal-500 text-gray-700 font-bold py-6 px-4 rounded-lg hover:bg-teal-50 transition-colors flex flex-col items-center justify-center min-h-[120px]"
        >
          <FiPlus className="text-3xl mb-3 text-teal-600" />
          <span className="text-lg">Create Playlist</span>
        </button>
        <button
          disabled
          className="bg-white border-2 border-gray-300 text-gray-400 font-bold py-6 px-4 rounded-lg flex flex-col items-center justify-center min-h-[120px] cursor-not-allowed"
        >
          <FiMusic className="text-3xl mb-3" />
          <span className="text-lg">Import Playlist</span>
        </button>
        <button
          disabled
          className="bg-white border-2 border-gray-300 text-gray-400 font-bold py-6 px-4 rounded-lg flex flex-col items-center justify-center min-h-[120px] cursor-not-allowed"
        >
          <FiEdit className="text-3xl mb-3" />
          <span className="text-lg">Bulk Edit</span>
        </button>
      </div>

      {/* Playlists Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {playlists.map((playlist) => (
          <div
            key={playlist.id}
            className="bg-white rounded-lg border-2 border-teal-200 p-6 hover:shadow-lg hover:border-teal-400 transition-all"
          >
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center">
                <div
                  className="w-6 h-6 rounded mr-3 border-2 border-gray-300"
                  style={{ backgroundColor: playlist.color_code }}
                ></div>
                <div>
                  <h3 className="font-bold text-lg text-gray-900">{playlist.name}</h3>
                  <p className="text-sm text-gray-600 flex items-center font-medium">
                    {playlist.playlist_type === 'shuffle' ? (
                      <><FiShuffle className="mr-1 text-teal-600" /> Shuffle</>
                    ) : (
                      <><FiList className="mr-1 text-teal-600" /> Ordered</>
                    )}
                    <span className="ml-2 text-teal-600">• {playlist.track_count} tracks</span>
                  </p>
                </div>
              </div>
              <div className="flex space-x-2">
                <button
                  onClick={() => {
                    setShowTrackManager(playlist);
                    loadPlaylistTracks(playlist.id);
                  }}
                  className="bg-white border-2 border-teal-500 text-teal-600 p-2 rounded hover:bg-teal-50 transition-colors"
                  title="Manage Tracks"
                >
                  <FiMusic />
                </button>
                <button
                  onClick={() => deletePlaylist(playlist.id)}
                  className="bg-white border-2 border-red-500 text-red-600 p-2 rounded hover:bg-red-50 transition-colors"
                >
                  <FiTrash />
                </button>
              </div>
            </div>
            
            {playlist.description && (
              <p className="text-gray-700 text-sm mb-4 font-medium">{playlist.description}</p>
            )}
            
            <div className="text-xs text-gray-500 font-medium">
              Created {new Date(playlist.created_at).toLocaleDateString()}
            </div>
          </div>
        ))}
      </div>

      {playlists.length === 0 && (
        <div className="text-center py-12 bg-white border-2 border-teal-200 rounded-lg">
          <FiMusic className="mx-auto text-teal-400 text-6xl mb-4" />
          <h3 className="text-xl font-bold text-gray-900 mb-2">No playlists yet</h3>
          <p className="text-gray-600 mb-6 font-medium">Create your first playlist to get started</p>
          <button
            onClick={() => setShowCreatePlaylist(true)}
            className="bg-teal-500 text-white font-bold py-3 px-6 rounded-lg hover:bg-teal-600 transition-colors"
          >
            Create Playlist
          </button>
        </div>
      )}

      {/* Track Manager Modal */}
      {showTrackManager && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50" style={{ padding: '20px' }}>
          <div className="bg-white rounded-lg border-2 border-teal-200 p-6 w-full max-w-4xl max-h-[80vh] overflow-hidden">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold text-gray-900">Manage Tracks: {showTrackManager.name}</h2>
              <button
                onClick={() => setShowTrackManager(null)}
                className="bg-white border-2 border-gray-400 text-gray-600 p-2 rounded hover:bg-gray-50 transition-colors"
              >
                <FiX />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-6 h-96">
              {/* Current Playlist Tracks */}
              <div>
                <h3 className="font-bold text-lg text-gray-900 mb-3">Current Tracks ({playlistTracks.length})</h3>
                <div className="border-2 border-teal-200 rounded-lg p-4 h-full overflow-y-auto">
                  {playlistTracks.map((playlistTrack, index) => (
                    <div key={playlistTrack.track.id} className="flex items-center justify-between p-3 hover:bg-teal-50 rounded transition-colors">
                      <div className="flex items-center">
                        <span className="text-sm text-teal-600 font-bold mr-4">{index + 1}.</span>
                        <div>
                          <div className="font-bold text-gray-900">{playlistTrack.track.title}</div>
                          <div className="text-sm text-gray-600 font-medium">{playlistTrack.track.artist}</div>
                        </div>
                      </div>
                      <button
                        onClick={() => removeTrackFromPlaylist(playlistTrack.track.id, showTrackManager.id)}
                        className="bg-white border-2 border-red-500 text-red-600 p-2 rounded hover:bg-red-50 transition-colors"
                      >
                        <FiTrash />
                      </button>
                    </div>
                  ))}
                  {playlistTracks.length === 0 && (
                    <div className="text-center text-gray-500 py-8">
                      <FiMusic className="mx-auto text-4xl mb-2 text-teal-400" />
                      <p className="font-medium">No tracks in this playlist yet</p>
                    </div>
                  )}
                </div>
              </div>

              {/* Available Tracks */}
              <div>
                <div className="flex items-center justify-between mb-3">
                  <h3 className="font-bold text-lg text-gray-900">Available Tracks</h3>
                  <input
                    type="text"
                    placeholder="Search tracks..."
                    value={trackSearchTerm}
                    onChange={(e) => setTrackSearchTerm(e.target.value)}
                    className="text-sm border-2 border-teal-300 rounded px-3 py-2 font-medium"
                  />
                </div>
                <div className="border-2 border-teal-200 rounded-lg p-4 h-full overflow-y-auto">
                  {filteredAvailableTracks.map((track) => (
                    <div key={track.id} className="flex items-center justify-between p-3 hover:bg-teal-50 rounded transition-colors">
                      <div>
                        <div className="font-bold text-gray-900">{track.title}</div>
                        <div className="text-sm text-gray-600 font-medium">{track.artist}</div>
                      </div>
                      <button
                        onClick={() => addTrackToPlaylist(track.id, showTrackManager.id)}
                        className="bg-white border-2 border-teal-500 text-teal-600 p-2 rounded hover:bg-teal-50 transition-colors"
                      >
                        <FiPlus />
                      </button>
                    </div>
                  ))}
                  {filteredAvailableTracks.length === 0 && (
                    <div className="text-center text-gray-500 py-8">
                      <FiMusic className="mx-auto text-4xl mb-2 text-teal-400" />
                      <p className="font-medium">
                        {trackSearchTerm ? 'No tracks match your search' : 'All tracks already added'}
                      </p>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Create Playlist Modal */}
      {showCreatePlaylist && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50" style={{ padding: '20px' }}>
          <div className="bg-white rounded-lg border-2 border-teal-200 p-6 w-full max-w-md">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Create New Playlist</h2>
            <form onSubmit={createPlaylist}>
              <div className="mb-4">
                <label className="block text-sm font-bold text-gray-700 mb-2">
                  Playlist Name
                </label>
                <input
                  type="text"
                  value={playlistForm.name}
                  onChange={(e) => setPlaylistForm(prev => ({ ...prev, name: e.target.value }))}
                  className="w-full border-2 border-teal-300 rounded-lg px-3 py-2 font-medium"
                  required
                />
              </div>
              
              <div className="mb-4">
                <label className="block text-sm font-bold text-gray-700 mb-2">
                  Description
                </label>
                <textarea
                  value={playlistForm.description}
                  onChange={(e) => setPlaylistForm(prev => ({ ...prev, description: e.target.value }))}
                  className="w-full border-2 border-teal-300 rounded-lg px-3 py-2 font-medium"
                  rows="3"
                />
              </div>

              <div className="mb-4">
                <label className="block text-sm font-bold text-gray-700 mb-2">
                  Playlist Type
                </label>
                <select
                  value={playlistForm.playlist_type}
                  onChange={(e) => setPlaylistForm(prev => ({ ...prev, playlist_type: e.target.value }))}
                  className="w-full border-2 border-teal-300 rounded-lg px-3 py-2 font-medium"
                >
                  <option value="ordered">Ordered</option>
                  <option value="shuffle">Shuffle</option>
                </select>
              </div>

              <div className="mb-4">
                <label className="block text-sm font-bold text-gray-700 mb-2">
                  Color
                </label>
                <input
                  type="color"
                  value={playlistForm.color_code}
                  onChange={(e) => setPlaylistForm(prev => ({ ...prev, color_code: e.target.value }))}
                  className="w-full h-12 border-2 border-teal-300 rounded-lg"
                />
              </div>

              {playlistForm.playlist_type === 'shuffle' && (
                <div className="mb-4">
                  <label className="flex items-center">
                    <input
                      type="checkbox"
                      checked={playlistForm.shuffle_include_new_uploads}
                      onChange={(e) => setPlaylistForm(prev => ({ 
                        ...prev, 
                        shuffle_include_new_uploads: e.target.checked 
                      }))}
                      className="mr-3"
                    />
                    <span className="font-bold text-gray-700">Include new uploads automatically</span>
                  </label>
                </div>
              )}

              <div className="flex space-x-3">
                <button
                  type="button"
                  onClick={() => setShowCreatePlaylist(false)}
                  className="flex-1 bg-white border-2 border-gray-400 text-gray-700 font-bold py-3 px-4 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 bg-teal-500 text-white font-bold py-3 px-4 rounded-lg hover:bg-teal-600 transition-colors"
                >
                  Create
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default PlaylistManager;