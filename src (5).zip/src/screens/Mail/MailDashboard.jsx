// screens/Mail/MailDashboard.jsx
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { FiMail, FiUsers, FiSend, FiSettings, FiBarChart2, FiFileText, FiShield, FiDollarSign, FiActivity, FiAlertTriangle } from 'react-icons/fi';

const MailDashboard = () => {
  const navigate = useNavigate();
  const [stats, setStats] = useState({
    totalContacts: 0,
    totalCampaigns: 0,
    emailsSentThisMonth: 0,
    currentMonthCost: 0.00
  });

  // Load dashboard statistics
  useEffect(() => {
    loadDashboardStats();
  }, []);

  const loadDashboardStats = async () => {
    try {
      // TODO: Replace with actual Supabase calls
      // For now, mock data
      setStats({
        totalContacts: 1247,
        totalCampaigns: 23,
        emailsSentThisMonth: 8950,
        currentMonthCost: 12.38
      });
    } catch (error) {
      console.error('Error loading dashboard stats:', error);
    }
  };

  const navigateTo = (path) => {
    navigate(path);
  };

  return (
    <div style={styles.container}>
      {/* Header */}
      <div style={styles.header}>
        <h1 style={styles.title}>Tavari Mail Dashboard</h1>
        <p style={styles.subtitle}>Pay-per-email marketing with unlimited contacts</p>
      </div>

      {/* Stats Cards */}
      <div style={styles.statsGrid}>
        <div style={styles.statCard}>
          <div style={styles.statIcon}><FiUsers /></div>
          <div style={styles.statContent}>
            <div style={styles.statNumber}>{stats.totalContacts.toLocaleString()}</div>
            <div style={styles.statLabel}>Total Contacts</div>
          </div>
        </div>
        
        <div style={styles.statCard}>
          <div style={styles.statIcon}><FiMail /></div>
          <div style={styles.statContent}>
            <div style={styles.statNumber}>{stats.totalCampaigns}</div>
            <div style={styles.statLabel}>Total Campaigns</div>
          </div>
        </div>
        
        <div style={styles.statCard}>
          <div style={styles.statIcon}><FiSend /></div>
          <div style={styles.statContent}>
            <div style={styles.statNumber}>{stats.emailsSentThisMonth.toLocaleString()}</div>
            <div style={styles.statLabel}>Emails This Month</div>
          </div>
        </div>
        
        <div style={styles.statCard}>
          <div style={styles.statIcon}><FiDollarSign /></div>
          <div style={styles.statContent}>
            <div style={styles.statNumber}>${stats.currentMonthCost.toFixed(2)}</div>
            <div style={styles.statLabel}>This Month's Cost</div>
          </div>
        </div>
      </div>

      {/* Quick Actions - 3x Grid Layout per Tavari Standards */}
      <div style={styles.quickActionsHeader}>
        <h2 style={styles.sectionTitle}>Quick Actions</h2>
      </div>
      
      <div style={styles.buttonGrid}>
        <button 
          style={styles.gridButton} 
          onClick={() => navigateTo('mail/builder')}
        >
          <FiMail style={styles.buttonIcon} />
          <span style={styles.buttonText}>Create Campaign</span>
        </button>
        
        <button 
          style={styles.gridButton}
          onClick={() => navigateTo('mail/contacts')}
        >
          <FiUsers style={styles.buttonIcon} />
          <span style={styles.buttonText}>Manage Contacts</span>
        </button>
        
        <button 
          style={styles.gridButton}
          onClick={() => navigateTo('mail/campaigns')}
        >
          <FiFileText style={styles.buttonIcon} />
          <span style={styles.buttonText}>View Campaigns</span>
        </button>
        
        <button 
          style={styles.gridButton}
          onClick={() => navigateTo('mail/logs')}
        >
          <FiFileText style={styles.buttonIcon} />
          <span style={styles.buttonText}>Send Logs</span>
        </button>
        
        <button 
          style={styles.gridButton}
          onClick={() => navigateTo('mail/performance')}
        >
          <FiActivity style={styles.buttonIcon} />
          <span style={styles.buttonText}>Performance Monitor</span>
        </button>
        
        <button 
          style={styles.gridButton}
          onClick={() => navigateTo('mail/settings')}
        >
          <FiSettings style={styles.buttonIcon} />
          <span style={styles.buttonText}>Mail Settings</span>
        </button>
        
        <button 
          style={styles.gridButton}
          onClick={() => navigateTo('mail/templates')}
        >
          <FiFileText style={styles.buttonIcon} />
          <span style={styles.buttonText}>Email Templates</span>
        </button>
        
        <button 
          style={styles.gridButton}
          onClick={() => navigateTo('mail/billing')}
        >
          <FiBarChart2 style={styles.buttonIcon} />
          <span style={styles.buttonText}>Usage & Billing</span>
        </button>
        
        <button 
          style={styles.gridButton}
          onClick={() => navigateTo('mail/compliance')}
        >
          <FiShield style={styles.buttonIcon} />
          <span style={styles.buttonText}>Compliance Center</span>
        </button>
      </div>

      {/* Module Visibility for Upselling */}
      <div style={styles.modulesSection}>
        <h3 style={styles.sectionTitle}>Other Tavari Modules</h3>
        <div style={styles.moduleButtons}>
          <button 
            style={styles.moduleButton}
            onClick={() => navigateTo('pos/register')}
          >
            Tavari POS
          </button>
          <button 
            style={styles.moduleButton}
            onClick={() => navigateTo('music/dashboard')}
          >
            Tavari Music
          </button>
        </div>
      </div>
    </div>
  );
};

const styles = {
  container: {
    padding: '20px',
    maxWidth: '1200px',
    margin: '0 auto',
    backgroundColor: '#f8f8f8',
    minHeight: '100vh',
  },
  header: {
    textAlign: 'center',
    marginBottom: '30px',
  },
  title: {
    fontSize: '28px',
    fontWeight: 'bold',
    color: '#333',
    marginBottom: '8px',
  },
  subtitle: {
    fontSize: '16px',
    color: '#666',
    margin: 0,
  },
  statsGrid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))',
    gap: '20px',
    marginBottom: '40px',
  },
  statCard: {
    backgroundColor: 'white',
    padding: '20px',
    borderRadius: '8px',
    border: '1px solid #ddd',
    display: 'flex',
    alignItems: 'center',
    gap: '15px',
  },
  statIcon: {
    fontSize: '24px',
    color: 'teal',
    width: '40px',
    textAlign: 'center',
  },
  statContent: {
    flex: 1,
  },
  statNumber: {
    fontSize: '24px',
    fontWeight: 'bold',
    color: '#333',
  },
  statLabel: {
    fontSize: '14px',
    color: '#666',
    marginTop: '4px',
  },
  quickActionsHeader: {
    marginBottom: '20px',
  },
  sectionTitle: {
    fontSize: '20px',
    fontWeight: 'bold',
    color: '#333',
    marginBottom: '10px',
  },
  buttonGrid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(3, 1fr)',
    gap: '20px',
    marginBottom: '40px',
  },
  gridButton: {
    backgroundColor: 'white',
    border: '2px solid teal',
    borderRadius: '8px',
    padding: '30px 20px',
    cursor: 'pointer',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    gap: '10px',
    transition: 'all 0.2s ease',
    minHeight: '120px',
  },
  buttonIcon: {
    fontSize: '32px',
    color: 'teal',
  },
  buttonText: {
    fontSize: '16px',
    fontWeight: 'bold',
    color: '#333',
    textAlign: 'center',
  },
  modulesSection: {
    marginTop: '40px',
    textAlign: 'center',
  },
  moduleButtons: {
    display: 'flex',
    gap: '20px',
    justifyContent: 'center',
    flexWrap: 'wrap',
  },
  moduleButton: {
    backgroundColor: 'teal',
    color: 'white',
    border: 'none',
    borderRadius: '8px',
    padding: '12px 24px',
    fontSize: '16px',
    fontWeight: 'bold',
    cursor: 'pointer',
    transition: 'all 0.2s ease',
  },
  // Mobile responsiveness
  '@media (max-width: 768px)': {
    buttonGrid: {
      gridTemplateColumns: '1fr',
    },
    statsGrid: {
      gridTemplateColumns: '1fr',
    },
  },
};

export default MailDashboard;