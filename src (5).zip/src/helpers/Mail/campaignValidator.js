// helpers/Mail/campaignValidator.js

export const validateCampaign = (campaign) => {
  const errors = [];
  
  if (!campaign.name.trim()) {
    errors.push('Campaign name is required');
  }
  
  if (!campaign.subject_line.trim()) {
    errors.push('Subject line is required');
  }
  
  if (campaign.content_blocks.length === 0) {
    errors.push('Campaign must have at least one content block');
  }
  
  // Check if unsubscribe link exists
  const hasUnsubscribe = campaign.content_blocks.some(block => 
    (block.type === 'text' && block.content.includes('{UnsubscribeLink}')) ||
    (block.type === 'button' && block.content.url && block.content.url.includes('unsubscribe'))
  );
  
  if (!hasUnsubscribe) {
    errors.push('Campaign must include an unsubscribe link for compliance');
  }
  
  return errors;
};