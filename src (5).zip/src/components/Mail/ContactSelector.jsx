// components/Mail/ContactSelector.jsx
import React, { useState, useEffect } from 'react';
import { styles } from '../../styles/Mail/CampaignBuilder.styles';
import { 
  FiX, FiUsers, FiUserCheck, FiUserX, FiSearch, FiFilter, 
  FiSend, FiMail, FiCheckCircle, FiAlertTriangle
} from 'react-icons/fi';

const ContactSelector = ({ 
  isOpen, 
  onClose, 
  campaign, 
  contacts, 
  selectedContacts, 
  customContactIds, 
  onSelectedContactsChange, 
  onCustomContactIdsChange, 
  onSend 
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filter, setFilter] = useState('all');
  const [testEmails, setTestEmails] = useState('');
  const [sendingTest, setSendingTest] = useState(false);

  // Filter and search contacts
  const filteredContacts = contacts.filter(contact => {
    // Apply subscription filter
    if (filter === 'subscribed' && !contact.subscribed) return false;
    if (filter === 'unsubscribed' && contact.subscribed) return false;
    
    // Apply search filter
    if (searchTerm) {
      const search = searchTerm.toLowerCase();
      return (
        contact.email.toLowerCase().includes(search) ||
        contact.first_name?.toLowerCase().includes(search) ||
        contact.last_name?.toLowerCase().includes(search)
      );
    }
    
    return true;
  });

  // Calculate recipient counts
  const getRecipientCount = () => {
    if (selectedContacts === 'all') {
      return contacts.filter(c => c.subscribed).length;
    } else if (selectedContacts === 'custom') {
      return customContactIds.length;
    }
    return 0;
  };

  const handleContactToggle = (contactId) => {
    if (customContactIds.includes(contactId)) {
      onCustomContactIdsChange(customContactIds.filter(id => id !== contactId));
    } else {
      onCustomContactIdsChange([...customContactIds, contactId]);
    }
  };

  const handleSelectAll = () => {
    const allFilteredIds = filteredContacts
      .filter(c => c.subscribed)
      .map(c => c.id);
    onCustomContactIdsChange(allFilteredIds);
  };

  const handleDeselectAll = () => {
    onCustomContactIdsChange([]);
  };

  const handleSendTest = async () => {
    if (!testEmails.trim()) {
      alert('Please enter at least one email address for testing.');
      return;
    }

    const emails = testEmails.split(',').map(email => email.trim()).filter(email => email);
    const invalidEmails = emails.filter(email => !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email));
    
    if (invalidEmails.length > 0) {
      alert(`Invalid email addresses: ${invalidEmails.join(', ')}`);
      return;
    }

    setSendingTest(true);
    try {
      // This would normally send test emails
      console.log('Sending test emails to:', emails);
      console.log('Campaign:', campaign);
      
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      alert(`Test emails sent successfully to ${emails.length} recipient(s)!`);
      setTestEmails('');
    } catch (error) {
      console.error('Error sending test emails:', error);
      alert('Failed to send test emails. Please try again.');
    } finally {
      setSendingTest(false);
    }
  };

  const handleSendCampaign = () => {
    const recipientCount = getRecipientCount();
    
    if (recipientCount === 0) {
      alert('Please select at least one contact to send to.');
      return;
    }

    // Validation checks
    const errors = [];
    if (!campaign.name.trim()) errors.push('Campaign name is required');
    if (!campaign.subject_line.trim()) errors.push('Subject line is required');
    if (!campaign.content_blocks || campaign.content_blocks.length === 0) {
      errors.push('Campaign must have at least one content block');
    }

    if (errors.length > 0) {
      alert('Please fix these issues before sending:\n' + errors.join('\n'));
      return;
    }

    const confirmMessage = `Send "${campaign.name}" to ${recipientCount} contact(s)?`;
    if (window.confirm(confirmMessage)) {
      onSend(recipientCount);
    }
  };

  if (!isOpen) return null;

  return (
    <div style={styles.modalOverlay}>
      <div style={styles.modal}>
        <div style={styles.modalHeader}>
          <h2 style={styles.modalTitle}>Send Campaign</h2>
          <button style={styles.modalClose} onClick={onClose}>
            <FiX />
          </button>
        </div>

        <div style={styles.modalContent}>
          {/* Campaign Summary */}
          <div style={styles.campaignSummary}>
            <h3 style={styles.summaryTitle}>Campaign: {campaign.name}</h3>
            <div style={styles.summaryDetails}>
              <div style={styles.summaryItem}>
                <strong>Subject:</strong> {campaign.subject_line}
              </div>
              {campaign.preheader_text && (
                <div style={styles.summaryItem}>
                  <strong>Preheader:</strong> {campaign.preheader_text}
                </div>
              )}
              <div style={styles.summaryItem}>
                <strong>Content Blocks:</strong> {campaign.content_blocks?.length || 0}
              </div>
            </div>
          </div>

          {/* Test Email Section */}
          <div style={styles.testSection}>
            <h4 style={styles.testTitle}>
              <FiMail style={styles.testIcon} />
              Send Test Email
            </h4>
            <div style={styles.testControls}>
              <input
                type="text"
                style={styles.testInput}
                value={testEmails}
                onChange={(e) => setTestEmails(e.target.value)}
                placeholder="Enter test email addresses (comma-separated)"
              />
              <button
                style={styles.testButton}
                onClick={handleSendTest}
                disabled={sendingTest || !testEmails.trim()}
              >
                {sendingTest ? 'Sending...' : 'Send Test'}
              </button>
            </div>
            <div style={styles.testHint}>
              Send a test email to verify your campaign looks correct before sending to all contacts.
            </div>
          </div>

          {/* Recipient Selection */}
          <div style={styles.recipientSection}>
            <h4 style={styles.recipientTitle}>
              <FiUsers style={styles.recipientIcon} />
              Select Recipients
            </h4>

            <div style={styles.recipientOptions}>
              <label style={styles.recipientOption}>
                <input
                  type="radio"
                  name="recipients"
                  value="all"
                  checked={selectedContacts === 'all'}
                  onChange={(e) => onSelectedContactsChange(e.target.value)}
                />
                <div style={styles.optionContent}>
                  <div style={styles.optionTitle}>All Subscribed Contacts</div>
                  <div style={styles.optionDescription}>
                    Send to all {contacts.filter(c => c.subscribed).length} subscribed contacts
                  </div>
                </div>
              </label>

              <label style={styles.recipientOption}>
                <input
                  type="radio"
                  name="recipients"
                  value="custom"
                  checked={selectedContacts === 'custom'}
                  onChange={(e) => onSelectedContactsChange(e.target.value)}
                />
                <div style={styles.optionContent}>
                  <div style={styles.optionTitle}>Custom Selection</div>
                  <div style={styles.optionDescription}>
                    Choose specific contacts ({customContactIds.length} selected)
                  </div>
                </div>
              </label>
            </div>

            {/* Custom Contact Selection */}
            {selectedContacts === 'custom' && (
              <div style={styles.customSelection}>
                <div style={styles.selectionControls}>
                  <div style={styles.searchContainer}>
                    <FiSearch style={styles.searchIcon} />
                    <input
                      type="text"
                      style={styles.searchInput}
                      placeholder="Search contacts..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                    />
                  </div>
                  
                  <select
                    style={styles.filterSelect}
                    value={filter}
                    onChange={(e) => setFilter(e.target.value)}
                  >
                    <option value="all">All Contacts</option>
                    <option value="subscribed">Subscribed Only</option>
                    <option value="unsubscribed">Unsubscribed Only</option>
                  </select>
                </div>

                <div style={styles.bulkActions}>
                  <button
                    style={styles.bulkButton}
                    onClick={handleSelectAll}
                  >
                    Select All Filtered
                  </button>
                  <button
                    style={styles.bulkButton}
                    onClick={handleDeselectAll}
                  >
                    Deselect All
                  </button>
                </div>

                <div style={styles.contactsList}>
                  {filteredContacts.length === 0 ? (
                    <div style={styles.noContacts}>
                      No contacts match your search criteria.
                    </div>
                  ) : (
                    filteredContacts.map(contact => (
                      <label key={contact.id} style={styles.contactItem}>
                        <input
                          type="checkbox"
                          checked={customContactIds.includes(contact.id)}
                          onChange={() => handleContactToggle(contact.id)}
                          disabled={!contact.subscribed}
                        />
                        <div style={styles.contactInfo}>
                          <div style={styles.contactName}>
                            {contact.first_name} {contact.last_name}
                          </div>
                          <div style={styles.contactEmail}>
                            {contact.email}
                          </div>
                        </div>
                        <div style={styles.contactStatus}>
                          {contact.subscribed ? (
                            <FiUserCheck style={styles.subscribedIcon} />
                          ) : (
                            <FiUserX style={styles.unsubscribedIcon} />
                          )}
                        </div>
                      </label>
                    ))
                  )}
                </div>
              </div>
            )}
          </div>

          {/* Send Summary */}
          <div style={styles.sendSummary}>
            <div style={styles.summaryStats}>
              <div style={styles.statItem}>
                <FiUsers style={styles.statIcon} />
                <span style={styles.statLabel}>Recipients:</span>
                <span style={styles.statValue}>{getRecipientCount()}</span>
              </div>
              <div style={styles.statItem}>
                <FiMail style={styles.statIcon} />
                <span style={styles.statLabel}>Estimated Cost:</span>
                <span style={styles.statValue}>
                  ${(getRecipientCount() * 0.0025).toFixed(4)}
                </span>
              </div>
            </div>

            {getRecipientCount() > 0 && (
              <div style={styles.sendWarning}>
                <FiAlertTriangle style={styles.warningIcon} />
                <span>This action cannot be undone. The campaign will be sent immediately.</span>
              </div>
            )}
          </div>
        </div>

        <div style={styles.modalActions}>
          <button style={styles.modalCancel} onClick={onClose}>
            Cancel
          </button>
          <button
            style={styles.modalSend}
            onClick={handleSendCampaign}
            disabled={getRecipientCount() === 0}
          >
            <FiSend style={styles.buttonIcon} />
            Send to {getRecipientCount()} Contact{getRecipientCount() !== 1 ? 's' : ''}
          </button>
        </div>
      </div>
    </div>
  );
};

// Additional styles for ContactSelector
const additionalStyles = {
  campaignSummary: {
    backgroundColor: '#f8f8f8',
    border: '1px solid #ddd',
    borderRadius: '8px',
    padding: '15px',
    marginBottom: '20px',
  },
  summaryTitle: {
    fontSize: '16px',
    fontWeight: 'bold',
    color: '#333',
    marginBottom: '10px',
  },
  summaryDetails: {
    display: 'flex',
    flexDirection: 'column',
    gap: '5px',
  },
  summaryItem: {
    fontSize: '14px',
    color: '#666',
  },
  testSection: {
    marginBottom: '20px',
    padding: '15px',
    border: '1px solid #ddd',
    borderRadius: '8px',
  },
  testTitle: {
    fontSize: '14px',
    fontWeight: 'bold',
    color: '#333',
    marginBottom: '10px',
    display: 'flex',
    alignItems: 'center',
    gap: '8px',
  },
  testIcon: {
    color: 'teal',
  },
  testControls: {
    display: 'flex',
    gap: '10px',
    marginBottom: '8px',
  },
  testInput: {
    flex: 1,
    padding: '8px 12px',
    fontSize: '14px',
    border: '2px solid #ddd',
    borderRadius: '6px',
  },
  testButton: {
    backgroundColor: 'teal',
    color: 'white',
    border: 'none',
    borderRadius: '6px',
    padding: '8px 16px',
    fontSize: '14px',
    fontWeight: 'bold',
    cursor: 'pointer',
  },
  testHint: {
    fontSize: '12px',
    color: '#666',
    fontStyle: 'italic',
  },
  recipientSection: {
    marginBottom: '20px',
  },
  recipientTitle: {
    fontSize: '14px',
    fontWeight: 'bold',
    color: '#333',
    marginBottom: '10px',
    display: 'flex',
    alignItems: 'center',
    gap: '8px',
  },
  recipientIcon: {
    color: 'teal',
  },
  recipientOptions: {
    display: 'flex',
    flexDirection: 'column',
    gap: '10px',
    marginBottom: '15px',
  },
  recipientOption: {
    display: 'flex',
    alignItems: 'center',
    gap: '12px',
    padding: '12px',
    border: '2px solid #ddd',
    borderRadius: '8px',
    cursor: 'pointer',
  },
  optionContent: {
    flex: 1,
  },
  optionTitle: {
    fontSize: '14px',
    fontWeight: 'bold',
    color: '#333',
    marginBottom: '2px',
  },
  optionDescription: {
    fontSize: '12px',
    color: '#666',
  },
  customSelection: {
    border: '1px solid #ddd',
    borderRadius: '8px',
    padding: '15px',
  },
  selectionControls: {
    display: 'flex',
    gap: '10px',
    marginBottom: '10px',
  },
  searchContainer: {
    position: 'relative',
    flex: 1,
  },
  searchIcon: {
    position: 'absolute',
    left: '12px',
    top: '50%',
    transform: 'translateY(-50%)',
    color: '#666',
    fontSize: '14px',
  },
  searchInput: {
    width: '100%',
    padding: '8px 12px 8px 35px',
    fontSize: '14px',
    border: '2px solid #ddd',
    borderRadius: '6px',
    boxSizing: 'border-box',
  },
  filterSelect: {
    padding: '8px 12px',
    fontSize: '14px',
    border: '2px solid #ddd',
    borderRadius: '6px',
    backgroundColor: 'white',
  },
  bulkActions: {
    display: 'flex',
    gap: '10px',
    marginBottom: '15px',
  },
  bulkButton: {
    backgroundColor: 'white',
    color: 'teal',
    border: '2px solid teal',
    borderRadius: '6px',
    padding: '6px 12px',
    fontSize: '12px',
    fontWeight: 'bold',
    cursor: 'pointer',
  },
  contactsList: {
    maxHeight: '250px',
    overflow: 'auto',
    border: '1px solid #f0f0f0',
    borderRadius: '6px',
  },
  contactItem: {
    display: 'flex',
    alignItems: 'center',
    gap: '12px',
    padding: '10px',
    borderBottom: '1px solid #f0f0f0',
    cursor: 'pointer',
  },
  contactInfo: {
    flex: 1,
  },
  contactName: {
    fontSize: '14px',
    fontWeight: 'bold',
    color: '#333',
    marginBottom: '2px',
  },
  contactEmail: {
    fontSize: '12px',
    color: '#666',
  },
  contactStatus: {
    fontSize: '16px',
  },
  subscribedIcon: {
    color: '#4caf50',
  },
  unsubscribedIcon: {
    color: '#f44336',
  },
  noContacts: {
    textAlign: 'center',
    padding: '40px 20px',
    color: '#666',
    fontStyle: 'italic',
  },
  sendSummary: {
    backgroundColor: '#f8f8f8',
    border: '1px solid #ddd',
    borderRadius: '8px',
    padding: '15px',
  },
  summaryStats: {
    display: 'flex',
    gap: '20px',
    marginBottom: '10px',
  },
  statItem: {
    display: 'flex',
    alignItems: 'center',
    gap: '8px',
    fontSize: '14px',
  },
  statIcon: {
    color: 'teal',
  },
  statLabel: {
    color: '#666',
  },
  statValue: {
    fontWeight: 'bold',
    color: '#333',
  },
  sendWarning: {
    display: 'flex',
    alignItems: 'center',
    gap: '8px',
    fontSize: '12px',
    color: '#e17055',
    fontWeight: 'bold',
  },
  warningIcon: {
    fontSize: '14px',
  },
};

// Merge additional styles with existing styles
Object.assign(styles, additionalStyles);

export default ContactSelector;